# 🎨 UI Components Visual Reference Guide

Quick visual reference and copy-paste code snippets for all components.

---

## 📦 Card Components

### Basic Card
```tsx
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

<Card>
  <CardHeader>
    <CardTitle>Card Title</CardTitle>
  </CardHeader>
  <CardContent>
    Card content goes here
  </CardContent>
</Card>
```

### Glassmorphic Card (Dashboard Style)
```tsx
<Card className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300">
  <CardHeader>
    <CardTitle className="text-white">Title</CardTitle>
  </CardHeader>
  <CardContent className="text-white/80">
    Content
  </CardContent>
</Card>
```

### Colored Card
```tsx
<Card className="bg-green-500/10 border-green-500/20 backdrop-blur-xl hover:bg-green-500/20">
  <CardHeader>
    <CardTitle className="text-green-400">Success</CardTitle>
  </CardHeader>
  <CardContent>Success message here</CardContent>
</Card>
```

---

## 🏷️ Badge Components

### Status Badge
```tsx
import { Badge } from '@/components/ui/badge'

<Badge className="bg-green-500/20 text-green-300 border-green-500/30">
  <CheckCircle className="w-3 h-3 mr-1" />
  Active
</Badge>
```

### Different Variants
```tsx
// Success
<Badge className="bg-green-500/20 text-green-300">Success</Badge>

// Warning
<Badge className="bg-yellow-500/20 text-yellow-300">Warning</Badge>

// Error
<Badge className="bg-red-500/20 text-red-300">Error</Badge>

// Info
<Badge className="bg-blue-500/20 text-blue-300">Info</Badge>

// Demo
<Badge className="bg-yellow-500/30 text-yellow-300 border-yellow-500/40 animate-pulse">
  Demo
</Badge>
```

---

## 🔘 Button Components

### Primary Button
```tsx
import { Button } from '@/components/ui/button'

<Button className="bg-green-500 hover:bg-green-600 text-white">
  Click Me
</Button>
```

### Secondary Button
```tsx
<Button variant="outline" className="text-green-200 border-green-500/30 hover:bg-green-500/10">
  Secondary
</Button>
```

### Icon Button
```tsx
<Button variant="ghost" className="text-green-100 hover:text-red-400 hover:bg-red-500/10">
  <LogOut className="w-5 h-5" />
</Button>
```

### Active/Inactive Toggle
```tsx
<Button
  variant={isActive ? 'default' : 'outline'}
  onClick={() => setActive(!isActive)}
  className={isActive
    ? 'bg-green-500 hover:bg-green-600 text-white border-green-500 shadow-lg shadow-green-500/30 transform scale-105'
    : 'text-green-200 border-green-500/30 hover:bg-green-500/10'
  }
>
  {isActive ? 'Active' : 'Inactive'}
</Button>
```

---

## 📊 Sensor Card Component

### Temperature Card
```tsx
<SensorCard
  icon={<Thermometer className="w-14 h-14" />}
  title="Temperature"
  value={25.5}
  unit="°C"
  color="text-orange-400"
  bgColor="bg-orange-500/10 border-orange-500/20"
  description="Current temperature"
  trend="normal"
/>
```

### Humidity Card
```tsx
<SensorCard
  icon={<Droplets className="w-14 h-14" />}
  title="Humidity"
  value={65}
  unit="%"
  color="text-blue-400"
  bgColor="bg-blue-500/10 border-blue-500/20"
  description="Relative humidity"
  trend="normal"
/>
```

### Light Status Card
```tsx
<SensorCard
  icon={<Sun className="w-14 h-14" />}
  title="Light Status"
  value="DAY"
  unit=""
  color="text-yellow-400"
  bgColor="bg-yellow-500/10 border-yellow-500/20"
  description="Day/Night cycle"
/>
```

### AQI Status Card
```tsx
<SensorCard
  icon={<AlertTriangle className="w-14 h-14" />}
  title="Air Quality"
  value="Moderate"
  unit=""
  color="text-amber-400"
  bgColor="bg-amber-500/10 border-amber-500/20"
  description="AQI Status"
  isStatusCard={true}
/>
```

---

## ⚡ Quick Stat Card Component

### Connection Status
```tsx
<QuickStatCard
  icon={<Wifi className="w-5 h-5" />}
  title="Connection"
  value="Excellent"
  color="text-green-400"
  bgColor="bg-green-500/10 border-green-500/20"
/>
```

### Battery Level
```tsx
<QuickStatCard
  icon={<Battery className="w-5 h-5" />}
  title="Battery"
  value="85%"
  color="text-blue-400"
  bgColor="bg-blue-500/10 border-blue-500/20"
/>
```

### System Uptime
```tsx
<QuickStatCard
  icon={<Clock className="w-5 h-5" />}
  title="Uptime"
  value="12h 45m"
  color="text-purple-400"
  bgColor="bg-purple-500/10 border-purple-500/20"
/>
```

### Data Points
```tsx
<QuickStatCard
  icon={<Activity className="w-5 h-5" />}
  title="Data Points"
  value="1,234"
  color="text-emerald-400"
  bgColor="bg-emerald-500/10 border-emerald-500/20"
/>
```

---

## 💡 Recommendation Card Component

### Success Recommendation
```tsx
<RecommendationCard
  icon={<Sun className="w-8 h-8" />}
  title="Temperature"
  description="Optimal temperature for plants"
  type="success"
/>
```

### Warning Recommendation
```tsx
<RecommendationCard
  icon={<CloudRain className="w-8 h-8" />}
  title="Humidity"
  description="High humidity! Use ventilation to reduce moisture"
  type="warning"
/>
```

### Info Recommendation
```tsx
<RecommendationCard
  icon={<Info className="w-8 h-8" />}
  title="AQI"
  description="Air quality is moderate, ensure adequate ventilation"
  type="info"
/>
```

---

## 📈 Chart Components

### Line Chart Example
```tsx
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { ChartContainer } from '@/components/ui/chart'

const chartConfig = {
  temperature: { label: 'Temperature', color: 'hsl(0, 84%, 60%)' }
}

const data = [
  { name: '00:00', temperature: 20 },
  { name: '06:00', temperature: 18 },
  { name: '12:00', temperature: 25 },
  { name: '18:00', temperature: 23 },
]

<ChartContainer config={chartConfig} className="h-80">
  <ResponsiveContainer width="100%" height="100%">
    <LineChart data={data}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="name" />
      <YAxis />
      <Tooltip />
      <Legend />
      <Line 
        type="monotone" 
        dataKey="temperature" 
        stroke={chartConfig.temperature.color}
        strokeWidth={2}
      />
    </LineChart>
  </ResponsiveContainer>
</ChartContainer>
```

### Bar Chart Example
```tsx
import { BarChart, Bar } from 'recharts'

<ChartContainer config={chartConfig} className="h-80">
  <ResponsiveContainer width="100%" height="100%">
    <BarChart data={data}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="name" />
      <YAxis />
      <Tooltip />
      <Bar dataKey="humidity" fill={chartConfig.humidity.color} />
    </BarChart>
  </ResponsiveContainer>
</ChartContainer>
```

---

## 📐 Grid Layouts

### Single Column (Mobile)
```tsx
<div className="grid grid-cols-1 gap-6">
  {/* Items stack vertically */}
</div>
```

### Two Column (Tablet)
```tsx
<div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
  {/* 1 column on mobile, 2 on tablet */}
</div>
```

### Three Column (Desktop)
```tsx
<div className="grid grid-cols-1 md:grid-cols-3 gap-6">
  {/* 1 column on mobile, 3 on desktop */}
</div>
```

### Four Column (Full Desktop)
```tsx
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
  {/* Responsive: 1 → 2 → 4 columns */}
</div>
```

### Asymmetric Layout
```tsx
<div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
  <div className="lg:col-span-2">
    {/* Takes 2 columns on desktop */}
  </div>
  <div className="lg:col-span-1">
    {/* Takes 1 column on desktop */}
  </div>
</div>
```

---

## 🎯 Common Patterns

### Alert/Warning Box
```tsx
<div className="mb-6 p-4 bg-yellow-500/20 border border-yellow-500/30 rounded-lg flex items-center gap-3">
  <div className="w-8 h-8 bg-yellow-500/30 rounded-full flex items-center justify-center">
    <Shield className="w-4 h-4 text-yellow-300" />
  </div>
  <div>
    <p className="text-sm font-semibold text-yellow-200">Warning Title</p>
    <p className="text-xs text-yellow-300/70">Warning message here...</p>
  </div>
</div>
```

### Success Box
```tsx
<div className="p-4 bg-green-500/20 border border-green-500/30 rounded-lg flex items-center gap-3">
  <div className="w-8 h-8 bg-green-500/30 rounded-full flex items-center justify-center">
    <CheckCircle className="w-4 h-4 text-green-300" />
  </div>
  <div>
    <p className="text-sm font-semibold text-green-200">Success!</p>
    <p className="text-xs text-green-300/70">Operation completed successfully</p>
  </div>
</div>
```

### Error Box
```tsx
<div className="p-4 bg-red-500/20 border border-red-500/30 rounded-lg flex items-center gap-3">
  <div className="w-8 h-8 bg-red-500/30 rounded-full flex items-center justify-center">
    <AlertCircle className="w-4 h-4 text-red-300" />
  </div>
  <div>
    <p className="text-sm font-semibold text-red-200">Error!</p>
    <p className="text-xs text-red-300/70">Something went wrong</p>
  </div>
</div>
```

### Info Box
```tsx
<div className="p-4 bg-blue-500/20 border border-blue-500/30 rounded-lg flex items-center gap-3">
  <div className="w-8 h-8 bg-blue-500/30 rounded-full flex items-center justify-center">
    <Info className="w-4 h-4 text-blue-300" />
  </div>
  <div>
    <p className="text-sm font-semibold text-blue-200">Information</p>
    <p className="text-xs text-blue-300/70">Additional details here</p>
  </div>
</div>
```

---

## 🌈 Color Combinations

### Orange Theme (Temperature)
```tsx
icon: "text-orange-400"
bgColor: "bg-orange-500/10 border-orange-500/20"
hover: "hover:bg-orange-500/20"
```

### Blue Theme (Humidity)
```tsx
icon: "text-blue-400"
bgColor: "bg-blue-500/10 border-blue-500/20"
hover: "hover:bg-blue-500/20"
```

### Cyan Theme (Network/Location)
```tsx
icon: "text-cyan-400"
bgColor: "bg-cyan-500/10 border-cyan-500/20"
hover: "hover:bg-cyan-500/20"
```

### Green Theme (Success/Active)
```tsx
icon: "text-green-400"
bgColor: "bg-green-500/10 border-green-500/20"
hover: "hover:bg-green-500/20"
```

### Red Theme (Error/Critical)
```tsx
icon: "text-red-400"
bgColor: "bg-red-500/10 border-red-500/20"
hover: "hover:bg-red-500/20"
```

### Yellow Theme (Warning)
```tsx
icon: "text-yellow-400"
bgColor: "bg-yellow-500/10 border-yellow-500/20"
hover: "hover:bg-yellow-500/20"
```

### Purple Theme (Special/Premium)
```tsx
icon: "text-purple-400"
bgColor: "bg-purple-500/10 border-purple-500/20"
hover: "hover:bg-purple-500/20"
```

### Emerald Theme (Growth/Positive)
```tsx
icon: "text-emerald-400"
bgColor: "bg-emerald-500/10 border-emerald-500/20"
hover: "hover:bg-emerald-500/20"
```

---

## 🎬 Animation Classes

### Fade In
```tsx
className="animate-in fade-in"
className="animate-in fade-in duration-500"
className="animate-in fade-in duration-700 delay-200"
```

### Slide From Top
```tsx
className="animate-in slide-in-from-top-4"
className="animate-in slide-in-from-top-8 duration-500"
```

### Slide From Bottom
```tsx
className="animate-in slide-in-from-bottom-4"
className="animate-in slide-in-from-bottom-8 duration-500 delay-100"
```

### Hover Scale
```tsx
className="hover:scale-105"
className="hover:scale-110 transition-transform duration-300"
className="hover:scale-105 hover:-translate-y-1"
```

### Hover Translate
```tsx
className="hover:-translate-y-2 transition-all duration-300"
className="hover:translate-x-2"
```

### Pulse Animation
```tsx
className="animate-pulse"
className="group-hover:scale-110 group-hover:rotate-6 transition-all duration-300"
```

---

## 📱 Responsive Text

### Responsive Font Size
```tsx
className="text-sm md:text-base lg:text-lg"
className="text-xs sm:text-sm md:text-base"
```

### Responsive Padding
```tsx
className="p-4 md:p-6 lg:p-8"
className="px-4 md:px-6 lg:px-8"
```

### Responsive Gap
```tsx
className="gap-4 md:gap-6 lg:gap-8"
```

### Responsive Grid
```tsx
className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
```

---

## 🔗 Icon Usage

### Icon Sizes
```tsx
className="w-4 h-4"   // Extra small (16px)
className="w-5 h-5"   // Small (20px)
className="w-6 h-6"   // Medium (24px)
className="w-8 h-8"   // Large (32px)
className="w-12 h-12" // Extra large (48px)
className="w-14 h-14" // Card icon size
className="w-16 h-16" // Hero icon size
```

### Icon Colors
```tsx
className="text-white"
className="text-gray-300"
className="text-green-400"
className="text-orange-400"
```

### Icon Containers
```tsx
// With background
<div className="p-2 rounded-lg bg-black/20 flex items-center justify-center">
  <Icon className="w-5 h-5 text-green-400" />
</div>

// Circular background
<div className="w-12 h-12 bg-green-500/30 rounded-full flex items-center justify-center">
  <Icon className="w-6 h-6 text-green-400" />
</div>
```

---

## ⚡ Performance Tips

### Lazy Load Expensive Components
```tsx
import dynamic from 'next/dynamic'

const DataCharts = dynamic(() => import('@/components/data-charts'), {
  loading: () => <div>Loading charts...</div>
})
```

### Memoize Components
```tsx
import React from 'react'

const SensorCard = React.memo(function SensorCard(props) {
  return (/* component */);
})
```

### Optimize Images
```tsx
import Image from 'next/image'

<Image 
  src="/logo.png" 
  alt="Logo" 
  width={48} 
  height={48}
  priority
/>
```

---

**Last Updated:** February 16, 2026  
**Version:** 1.0  
**All Components Verified:** ✅
