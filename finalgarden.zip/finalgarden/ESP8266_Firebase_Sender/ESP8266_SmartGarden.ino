/****************************************************
 * SMART GARDEN – FINAL CLEAN VERSION
 * ESP8266 NodeMCU
 * LittleFS + Captive Portal + mDNS + Firebase HTTPS
 ****************************************************/

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecureBearSSL.h>
#include <DNSServer.h>
#include <ESP8266mDNS.h>
#include <LittleFS.h>
#include <DHT.h>

/* ================= USER SETTINGS ================= */

#define AP_NAME "SmartGarden-Setup"
#define DHTPIN D2
#define DHTTYPE DHT11
#define LDR_PIN D1
#define MQ135_PIN A0

String firebase_host = "https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app";
String firebase_auth = "9gPXcUYJty4rjU05k1mBDEUUnXEyt9SQKB1nQTRz";   // <-- CHANGE THIS

/* ================= GLOBAL ================= */

ESP8266WebServer server(80);
DNSServer dns;
DHT dht(DHTPIN, DHTTYPE);

String ssid = "";
String password = "";
String device_id = "";

bool apMode = false;

/* =====================================================
   ================= LITTLEFS STORAGE ==================
=====================================================*/

void saveConfig() {

  File file = LittleFS.open("/config.json", "w");
  if (!file) return;

  file.print("{");
  file.print("\"ssid\":\"" + ssid + "\",");
  file.print("\"password\":\"" + password + "\",");
  file.print("\"device_id\":\"" + device_id + "\"");
  file.print("}");

  file.close();
  Serial.println("Config Saved");
}

bool loadConfig() {

  if (!LittleFS.exists("/config.json")) return false;

  File file = LittleFS.open("/config.json", "r");
  if (!file) return false;

  String content = file.readString();
  file.close();

  int s1 = content.indexOf("\"ssid\":\"");
  int s2 = content.indexOf("\"password\":\"");
  int s3 = content.indexOf("\"device_id\":\"");

  if (s1 < 0 || s2 < 0 || s3 < 0) return false;

  ssid = content.substring(s1 + 8, content.indexOf("\"", s1 + 8));
  password = content.substring(s2 + 12, content.indexOf("\"", s2 + 12));
  device_id = content.substring(s3 + 13, content.indexOf("\"", s3 + 13));

  return ssid.length() > 0;
}

/* =====================================================
   ================= WIFI SCAN =========================
=====================================================*/

String getWiFiList() {

  String list = "";
  int n = WiFi.scanNetworks();

  if (n == 0) {
    list += "<option>No Networks Found</option>";
  } else {
    for (int i = 0; i < n; i++) {
      list += "<option value='";
      list += WiFi.SSID(i);
      list += "'>";
      list += WiFi.SSID(i);
      list += " (";
      list += WiFi.RSSI(i);
      list += " dBm)";
      list += "</option>";
    }
  }

  WiFi.scanDelete();
  return list;
}

/* =====================================================
   ================= CAPTIVE PORTAL ====================
=====================================================*/

String portalHTML() {

  String page = "<!DOCTYPE html><html><head>";
  page += "<meta name='viewport' content='width=device-width'>";
  page += "<title>Smart Garden Setup</title>";
  page += "<style>";
  page += "body{font-family:Arial;background:linear-gradient(120deg,#00c6ff,#0072ff);color:#1F331;text-align:center;padding:20px}";
  page += ".card{background:#ffffff20;padding:25px;border-radius:15px}";
  page += "input{width:90%;padding:12px;margin:10px;border:none;border-radius:8px;font-size:16px}";
  page += "button{padding:12px 20px;background:#00ff99;color:#000;border:none;border-radius:8px;font-size:18px}";
  page += "</style></head><body>";
  page += "<div class='card'>";
  page += "<h2>&#127793 Smart Garden Setup</h2>";
  page += "<form action='/save' method='POST'>";
  page += "<label>Select WiFi:</label><br>";
  page += "<select name='ssid'>";
  page += getWiFiList();
  page += "</select><br><br>";
  page += "<input name='password' type='password' placeholder='WiFi Password' required><br>";
  page += "<input name='device' placeholder='Device ID' required><br>";
  page += "<button type='submit'>Save & Connect</button>";
  page += "</form></div></body></html>";

  return page;
}

void startAP() {

  apMode = true;

  WiFi.disconnect(true);
  delay(500);

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_NAME);

  dns.start(53, "*", WiFi.softAPIP());

  server.on("/generate_204", []() { server.send(200, "text/html", portalHTML()); });
  server.on("/fwlink", []() { server.send(200, "text/html", portalHTML()); });
  server.onNotFound([]() { server.send(200, "text/html", portalHTML()); });

  server.on("/save", HTTP_POST, []() {

    ssid = server.arg("ssid");
    password = server.arg("password");
    device_id = server.arg("device");

    saveConfig();

    server.send(200, "text/html", "<h2>Saved! Rebooting...</h2>");
    delay(1500);
    ESP.restart();
  });

  server.begin();

  Serial.println("AP Mode Started");
}

/* =====================================================
   ================= WIFI CONNECT ======================
=====================================================*/

bool connectWiFi() {

  WiFi.mode(WIFI_STA);
  WiFi.hostname("SMART GARDEN");
  WiFi.setSleepMode(WIFI_NONE_SLEEP);

  WiFi.begin(ssid.c_str(), password.c_str());

  Serial.print("Connecting to WiFi");

  int retry = 0;
  while (WiFi.status() != WL_CONNECTED && retry < 20) {
    delay(500);
    Serial.print(".");
    retry++;
  }

  if (WiFi.status() == WL_CONNECTED) {

    Serial.println("\nWiFi Connected");
    Serial.println(WiFi.localIP());

    if (MDNS.begin("smartgarden")) {
      Serial.println("mDNS Ready: http://smartgarden.local");
    }

    return true;
  }

  return false;
}

/* ========= AQI CONVERSION ========= */

int convertMQ135ToAQI(int raw) {
  if (raw <= 150) return map(raw, 0, 150, 0, 50);
  if (raw <= 300) return map(raw, 151, 300, 51, 100);
  if (raw <= 450) return map(raw, 301, 450, 101, 200);
  if (raw <= 600) return map(raw, 451, 600, 201, 300);
  if (raw <= 800) return map(raw, 601, 800, 301, 400);
  return map(raw, 801, 1023, 401, 500);
}

String getAQIStatus(int aqi) {
  if (aqi <= 50) return "GOOD";
  if (aqi <= 100) return "SATISFACTORY";
  if (aqi <= 200) return "MODERATE";
  if (aqi <= 300) return "POOR";
  if (aqi <= 400) return "VERY_POOR";
  return "SEVERE";
}

/* ========= FIREBASE SEND ========= */

void sendToFirebase() {

  if (WiFi.status() != WL_CONNECTED) return;

  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();
  int gasRaw = analogRead(MQ135_PIN);
  int aqi = convertMQ135ToAQI(gasRaw);

  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("Sensor Error");
    return;
  }

  String gasStatus = getAQIStatus(aqi);
  String lightStatus = digitalRead(LDR_PIN) ? "NIGHT" : "DAY";

  String url = firebase_host + "/garden/live/" + device_id + ".json?auth=" + firebase_auth;

  std::unique_ptr<BearSSL::WiFiClientSecure> client(new BearSSL::WiFiClientSecure);
  client->setInsecure();

  HTTPClient https;
  https.begin(*client, url);
  https.addHeader("Content-Type", "application/json");

  // ===== EXACT REQUIRED FORMAT =====
  String json = "{";
  json += "\"aqi\":" + String(aqi) + ",";
  json += "\"gasRaw\":" + String(gasRaw) + ",";
  json += "\"gasStatus\":\"" + gasStatus + "\",";
  json += "\"humidity\":" + String(humidity,1) + ",";
  json += "\"lightStatus\":\"" + lightStatus + "\",";
  json += "\"temperature\":" + String(temperature,1) + ",";
  json += "\"ip\":\"" + WiFi.localIP().toString() + "\",";
  json += "\"device_id\":\"" + device_id + "\"";
  json += "}";

  int httpCode = https.PUT(json);

  Serial.print("Firebase HTTP: ");
  Serial.println(httpCode);

  if (httpCode <= 0) {
    Serial.println("Firebase Error → Starting AP");
    startAP();
  }

  https.end();
}

/* =====================================================
   ===================== SETUP =========================
=====================================================*/

void setup() {

  Serial.begin(115200);
  delay(1000);

  if (!LittleFS.begin()) {
    Serial.println("LittleFS Mount Failed");
  }

  pinMode(LDR_PIN, INPUT);
  dht.begin();

  if (!loadConfig()) {
    Serial.println("No Config → Starting AP");
    startAP();
    return;
  }

  if (!connectWiFi()) {
    Serial.println("WiFi Failed → Starting AP");
    startAP();
    return;
  }

  sendToFirebase();
}

/* =====================================================
   ====================== LOOP =========================
=====================================================*/

void loop() {

  if (apMode) {
    dns.processNextRequest();
    server.handleClient();
    return;
  }

  static unsigned long lastSend = 0;

  if (millis() - lastSend > 1000) {
    sendToFirebase();
    lastSend = millis();
  }
}
