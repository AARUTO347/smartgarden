# ESP8266 Firebase Sender - Smart Garden

Complete ESP8266 code to send sensor data to Firebase Realtime Database for Smart Garden Dashboard.

## Hardware Required

- ESP8266 microcontroller (NodeMCU, Wemos D1 Mini, etc.)
- Temperature & Humidity Sensor (AHT10, DHT11/22, or similar)
- Gas Sensor (MQ-2, MQ-5, or analog gas sensor)
- Light Sensor (LDR or photodiode)
- USB cable for programming
- Power supply

---

## Software Required

- Arduino IDE (version 1.8.x or higher)
- ESP8266 board package in Arduino IDE
- Required libraries (install via Library Manager):
  - FirebaseESP8266
  - ESP8266WiFi
  - Adafruit AHTX0 (if using AHT sensor)

---

## Installation Steps

### 1. Install ESP8266 Board Support

1. Open Arduino IDE
2. Go to **File → Preferences**
3. Add this URL to "Additional Board Manager URLs":
   ```
   http://arduino.esp8266.com/stable/package_esp8266com_index.json
   ```
4. Go to **Tools → Board → Board Manager**
5. Search for "esp8266"
6. Install "esp8266 by ESP8266 Community"

### 2. Install Required Libraries

Go to **Sketch → Include Library → Manage Libraries** and install:

1. **FirebaseESP8266** (by mobizt)
2. **ESP8266WiFi** (usually included with ESP8266 boards)
3. **Adafruit AHTX0** (if using AHT sensor)

Or download manually:
- FirebaseESP8266: https://github.com/mobizt/FirebaseESP8266

### 3. Configure WiFi Credentials

In `ESP8266_SmartGarden.ino`, update:

```cpp
const char* ssid = "YOUR_WIFI_SSID";         // Your WiFi name
const char* password = "YOUR_WIFI_PASSWORD";   // Your WiFi password
```

### 4. Get Firebase Secret

1. Go to Firebase Console: https://console.firebase.google.com/project/rfid-aaruto/settings/serviceaccounts
2. Click "Generate New Private Key"
3. Download JSON file
4. Copy the "database_secret" value
5. Update in code:

```cpp
#define FIREBASE_AUTH "YOUR_FIREBASE_SECRET"
```

### 5. Connect ESP8266

1. Connect ESP8266 to computer via USB
2. In Arduino IDE: **Tools → Board**
3. Select: "NodeMCU 1.0 (ESP-12E Module)" or your board
3. Select correct COM port: **Tools → Port**

### 6. Upload Code

1. Click "Upload" button in Arduino IDE
2. Wait for upload to complete
3. Open Serial Monitor (115200 baud rate)
4. Watch for connection messages

---

## Firebase Database Setup

### Step 1: Create Database Structure

Go to Firebase Console: https://console.firebase.google.com/project/rfid-aaruto/database

Create the following structure:

```json
{
  "garden": {
    "live": {
      "temperature": 0,
      "humidity": 0,
      "gasLevel": 0,
      "gasStatus": "SAFE",
      "lightStatus": "DAY",
      "gardenLight": "ON",
      "timestamp": 0
    }
  }
}
```

### Step 2: Set Database Rules

In Firebase Console → Database → Rules tab, set:

```json
{
  "rules": {
    "garden": {
      "live": {
        ".read": true,
        ".write": true,
        ".validate": "newData.hasChildren(['temperature', 'humidity', 'gasLevel', 'gasStatus', 'lightStatus', 'gardenLight', 'timestamp'])"
      }
    }
  }
}
```

### Step 3: Set Indexes (Optional but Recommended)

```json
{
  "rules": {
    "garden": {
      "live": {
        ".read": true,
        ".write": true,
        ".indexOn": ["timestamp"]
      }
    }
  }
}
```

---

## Dashboard Connection

The dashboard is already configured to read from Firebase:

**Path**: `garden/live`
**Database**: `rfid-aaruto-default-rtdb`
**Region**: Asia Southeast 1

Dashboard will automatically:
- Connect to Firebase when page loads
- Read data from `garden/live`
- Update in real-time when ESP8266 sends data
- Display values in cards and charts

---

## Data Flow

```
ESP8266
   ↓
  readSensors()
   ↓
  - Temperature (AHT sensor)
  - Humidity (AHT sensor)
  - Gas Level (analog pin)
  - Light Status (analog pin)
   ↓
  determineStatus()
   ↓
  - Gas Status (SAFE/WARNING/DANGER)
  - Light Status (DAY/NIGHT)
  ↓
  sendToFirebase()
   ↓
  Firebase Realtime Database
   ↓
  /garden/live
   ↓
  Dashboard (http://localhost:3000)
   ↓
  - Real-time display
  - Charts update automatically
```

---

## Serial Monitor Output

When ESP8266 is running, you'll see:

```
=== Smart Garden IoT ESP8266 ===

Connecting to WiFi...
......
WiFi connected!
IP address: 192.168.1.100
Firebase initialized!
System ready!

=== Sensor Readings ===
Temperature: 27.50 °C
Humidity: 65.20 %
Gas Level: 150
Light Status: DAY
Garden Light: ON
Timestamp: 450123
Gas Status: SAFE

=== Sending to Firebase ===
Temperature sent successfully
Humidity sent successfully
Gas level sent successfully
Gas status sent successfully
Light status sent successfully
Garden light status sent successfully
Timestamp sent successfully
=== Firebase update complete ===
```

---

## Dashboard Viewing

### Access Dashboard:
1. Open: http://localhost:3000
2. Login (VIPIN/VIPIN123 or your account)
3. See real-time data from ESP8266

### What You'll See:

#### Dashboard View:
- **Temperature Card**: Live temperature in °C
- **Humidity Card**: Live humidity in %
- **Light Status Card**: DAY/NIGHT indicator
- **Garden Light Card**: ON/OFF status
- **Gas Status Card**: SAFE/WARNING/DANGER with color coding

#### Charts View:
- **Temperature & Humidity Trend**: Area chart with 8 Y-axis numbers
- **AQI HISTORY**: Bar chart with 10 Y-axis numbers

---

## Troubleshooting

### ESP8266 won't connect to WiFi:
- Check WiFi credentials in code
- Check WiFi signal strength
- Try 2.4GHz instead of 5GHz
- Check if router blocks ESP8266

### Firebase connection fails:
- Verify FIREBASE_HOST is correct
- Check FIREBASE_AUTH is valid
- Ensure database rules allow write access
- Check if Firebase database is in test mode

### Dashboard shows "--":
- ESP8266 must be running and sending data
- Check Serial Monitor for Firebase errors
- Verify database path is `garden/live`
- Check internet connection

### Dashboard not updating:
- Open browser DevTools (F12)
- Check Console for Firebase errors
- Verify Firebase rules allow read access
- Refresh page

### Charts not showing data:
- Need at least 2 data points
- Wait for ESP8266 to send multiple readings
- Historical data accumulates (last 50 readings)

---

## Configuration Options

### Change Update Frequency:

```cpp
#define SENSOR_UPDATE_INTERVAL 5000  // 5 seconds (default)
// Try other values:
// 1000  = 1 second (very frequent)
// 30000 = 30 seconds (power saving)
```

### Modify Gas Sensor Pin:

```cpp
sensorData.gasLevel = analogRead(A0);  // Change A0 to your pin
```

### Modify Light Sensor Pin:

```cpp
int lightValue = analogRead(A1);  // Change A1 to your pin
```

### Control Garden Light via Relay:

Add relay control:
```cpp
// Define relay pin
#define RELAY_PIN D1

void setup() {
  pinMode(RELAY_PIN, OUTPUT);
  // ... rest of setup
}

void loop() {
  // Turn on based on light level
  if (lightValue > 512) {
    digitalWrite(RELAY_PIN, HIGH);  // Turn ON
    sensorData.gardenLight = "ON";
  } else {
    digitalWrite(RELAY_PIN, LOW);   // Turn OFF
    sensorData.gardenLight = "OFF";
  }
  // ... rest of loop
}
```

---

## Firebase Console Links

- **Dashboard**: https://console.firebase.google.com/project/rfid-aaruto/overview
- **Database**: https://console.firebase.google.com/project/rfid-aaruto/database
- **Settings**: https://console.firebase.google.com/project/rfid-aaruto/settings
- **Service Accounts**: https://console.firebase.google.com/project/rfid-aaruto/settings/serviceaccounts

---

## Dashboard Links

- **Local**: http://localhost:3000
- **View**: Dashboard → Login → Real-time data
- **Charts**: Click "Charts" button → View graphs
- **Export**: Click "Export CSV" → Download data

---

## Testing Complete System

### Test 1: ESP8266 Connection
```
1. Open Serial Monitor (115200 baud)
2. Upload code to ESP8266
3. ✅ Should see WiFi connected
4. ✅ Should see Firebase initialized
5. ✅ Should see sensor readings
6. ✅ Should see "sent successfully" messages
```

### Test 2: Firebase Database
```
1. Open Firebase Console → Database
2. Check garden/live path
3. ✅ Should see data appearing
4. ✅ Should update every ~5 seconds
```

### Test 3: Dashboard
```
1. Open http://localhost:3000
2. Login to dashboard
3. ✅ Should see real sensor values
4. ✅ Values should update automatically
5. ✅ No "--" placeholder values
```

---

## Complete System Architecture

```
┌─────────────────────────────────┐
│         ESP8266          │
│  - AHT Temp/Hum Sensor  │
│  - Gas Sensor (MQ-2)     │
│  - Light Sensor (LDR)      │
│  - Relay (optional)        │
└───────────┬───────────────┘
            │ WiFi
            ↓
┌─────────────────────────────┐
│   Firebase Realtime DB      │
│   Path: garden/live       │
│   Project: rfid-aaruto    │
└───────────┬───────────────┘
            │ Real-time
            ↓
┌─────────────────────────────┐
│   Next.js Dashboard       │
│   Port: localhost:3000    │
└─────────────────────────────┘
```

---

## Performance Tips

### For Better Battery Life:
1. Increase update interval to 30+ seconds
2. Use deep sleep mode between readings
3. Optimize sensor readings

### For Faster Updates:
1. Set interval to 1-2 seconds
2. Use reliable WiFi connection
3. Optimize Firebase connection

### For Data Accuracy:
1. Calibrate sensors before use
2. Average multiple readings
3. Filter out outliers
4. Validate sensor ranges

---

## Security Notes

### WiFi Security:
- Use WPA2/WPA3 encryption
- Use strong WiFi password
- Don't hardcode production credentials

### Firebase Security:
- Use database secret (not API key)
- Set appropriate database rules
- Don't share private keys
- Use read/write only where needed

### Dashboard Security:
- Keep VIPIN/VIPIN123 credentials private
- Change default password in production
- Use HTTPS in production

---

## Production Deployment

### Before Deploying:
1. ✅ Change default passwords
2. ✅ Use production Firebase secrets
3. ✅ Set appropriate database rules
4. ✅ Test all sensors thoroughly
5. ✅ Verify data accuracy

### Deploy Dashboard:
- Update Firebase config with production values
- Deploy to Netlify/Vercel
- Test real ESP8266 connection
- Monitor for errors

---

## Quick Reference

### Firebase Path: `/garden/live`
### Update Interval: `5 seconds` (configurable)
### Dashboard: `http://localhost:3000`
### Serial Baud: `115200`
### WiFi Mode: `Station`

---

## Support

### Dashboard Issues:
- Check browser console (F12)
- Verify Firebase connection
- Check database rules
- Refresh page

### ESP8266 Issues:
- Check Serial Monitor output
- Verify WiFi connection
- Check Firebase credentials
- Verify sensor wiring

---

**Ready to connect your Smart Garden!**

🌿 **MADE BY AARUTO** | **POWERED BY CHRONOBOTICS** 🌿
