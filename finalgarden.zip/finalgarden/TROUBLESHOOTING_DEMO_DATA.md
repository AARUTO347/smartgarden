# 🔍 Troubleshooting: Why Dashboard Shows Demo Data

## Overview

When the dashboard shows "Showing Demo Data" instead of live ESP8266 data, it means one of these issues:

1. **ESP8266 not sending data to Firebase** ❌
2. **Firebase rules blocking read access** ❌
3. **Firebase connection failed** ❌
4. **Data not at expected path** ❌
5. **Network/Firewall blocking** ❌

---

## 🔧 Step-by-Step Debugging

### Step 1: Check Browser Console (F12)

#### 1. Open Dashboard in Browser
1. Go to your dashboard URL
2. Press **F12** to open Developer Tools
3. Go to **Console** tab
4. Look for these messages:

#### 2. Expected SUCCESS Messages:

```javascript
🔥 Firebase initialized
🔥 Database URL: https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app
🔥 Data Path: /garden/live
🔥 Full Reference: https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app/garden/live

📡 Subscribing to Firebase path: /garden/live
📡 Reference: https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app/garden/live

📡 Firebase data received: {aqi: 126, gasLevel: 402, gasStatus: "UNHEALTHY", ...}
📡 Snapshot exists: true
📡 Snapshot key: live
📡 Data keys: ["aqi", "gasLevel", "gasStatus", "humidity", "lightStatus", "temperature", "timestamp"]
✅ Valid data received from /garden/live
```

#### 3. Error Messages to Look For:

**Firebase Initialization Error:**
```javascript
❌ Firebase: Error: Firebase: Firebase App named '[DEFAULT]' already exists
```
→ Solution: Refresh the page

**Firebase Connection Error:**
```javascript
❌ Firebase data error: permission_denied
❌ Error code: PERMISSION_DENIED
```
→ Solution: Check Firebase Rules (see Step 2)

**No Data Error:**
```javascript
⚠️ Firebase path /garden/live is empty - showing demo data
📡 Snapshot exists: false
```
→ Solution: ESP8266 not sending data (see Step 3)

---

### Step 2: Check Firebase Console

#### 1. Go to Firebase Console
1. Visit: https://console.firebase.google.com/
2. Select project: **rfid-aaruto**
3. Go to **Realtime Database**

#### 2. Navigate to Data Path
```
garden
  └─ live
```

#### 3. What You Should See:

```json
{
  "aqi": 126,
  "gasLevel": 402,
  "gasStatus": "UNHEALTHY",
  "humidity": 51.8,
  "lightStatus": "NIGHT",
  "temperature": 29.2,
  "timestamp": 9
}
```

#### 4. If Path is Empty:

**Problem**: ESP8266 not sending data to Firebase

**Solution**: Check ESP8266 (see Step 3)

#### 5. If Path Has Data but Dashboard Still Shows Demo:

**Problem**: Firebase Rules blocking read access

**Solution**: Update Firebase Rules (see Step 4)

---

### Step 3: Check ESP8266 Serial Monitor

#### 1. Connect ESP8266 to Computer
- Connect via USB cable
- Open Arduino IDE
- Go to **Tools** → **Serial Monitor**
- Set baud rate to **115200** (your code setting)

#### 2. Expected Output (SUCCESS):

```text
SMART GARDEN SYSTEM STARTED
Indian AQI Standard (CPCB)
--------------------------------
Connecting to WiFi.................
WiFi Connected
IP Address: 192.168.1.100
Firebase Connected
--------------------------------

LIVE SENSOR DATA
Temperature : 29.2 °C
Humidity    : 51.8 %
MQ-135 Raw  : 402
AQI (India) : 126
AQI Status  : UNHEALTHY
Light       : NIGHT
--------------------------------
Sending to Firebase...Firebase Update SUCCESS
================================
```

#### 3. Error Messages:

**WiFi Connection Failed:**
```text
❌ WiFi Connection Failed!
```
→ Solution: Check WiFi credentials in code
→ Verify WiFi is available
→ Check router settings

**DHT Sensor Error:**
```text
❌ DHT11 Sensor Error
```
→ Solution: Check DHT11 wiring
→ Verify DHTPIN = D2
→ Try replacing DHT11 sensor

**Firebase Update Failed:**
```text
❌ Firebase ERROR: Permission denied
```
→ Solution: Check Firebase AUTH token
→ Verify Firebase project settings

```text
❌ Firebase ERROR: disconnected
```
→ Solution: Check internet connection
→ Verify Firebase credentials

---

### Step 4: Check Firebase Rules

#### 1. Go to Firebase Console Rules

1. Firebase Console → Realtime Database
2. Click **Rules** tab

#### 2. Current Rules Check

Rules should look like this:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

#### 3. If Rules Block Read:

**Problem**: Dashboard can't read data

**Example of blocking rules:**
```json
{
  "rules": {
    ".read": "auth != null",  // ❌ Requires authentication
    ".write": true
  }
}
```

**Solution**: Update rules to allow public read:
```json
{
  "rules": {
    ".read": true,  // ✅ Allow public read
    ".write": true  // ✅ Allow public write
  }
}
```

**How to update:**
1. Delete old rules
2. Paste new rules
3. Click **Publish**

---

### Step 5: Verify Firebase Data Flow

#### Complete Data Flow Check:

```
ESP8266
  ├─ Reads sensors (DHT11, LDR, MQ135)
  ├─ Calculates Indian AQI
  ├─ Creates JSON object
  └─ Sends to Firebase
         ↓
Firebase Realtime Database
  ├─ Path: /garden/live
  ├─ Should have your data
  └─ Check in Firebase Console
         ↓
Dashboard (Next.js)
  ├─ Subscribes to: database.ref('garden/live')
  ├─ Receives real-time updates
  └─ Displays on screen
```

---

## 🎯 Most Common Issues & Solutions

### Issue 1: ESP8266 WiFi Not Connected

**Symptoms:**
- Serial Monitor: "WiFi Connection Failed" or keeps showing dots
- Dashboard: Shows "Showing Demo Data"

**Solutions:**
1. Check WiFi credentials in code:
   ```cpp
   #define WIFI_SSID     "VIPIN"
   #define WIFI_PASSWORD "@@@@@@@@"
   ```
2. Verify WiFi password is correct (8 @ signs)
3. Check WiFi router is on
4. Verify ESP8266 is in WiFi range
5. Try connecting phone hotspot for testing

---

### Issue 2: ESP8266 Not Sending Data

**Symptoms:**
- Serial Monitor shows sensor readings but no "Firebase Update SUCCESS"
- Firebase Console has no data at `/garden/live`
- Dashboard shows demo data

**Solutions:**
1. Check Firebase credentials:
   ```cpp
   #define FIREBASE_HOST "rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
   #define FIREBASE_AUTH "9gPXcUYJty4rjU05k1mBDEUUnXEyt9SQKB1nQTRz"
   ```
2. Verify Firebase project exists
3. Check Firebase Console → Project Settings → Service Accounts
4. Ensure Database is enabled (Realtime Database, not Firestore)

---

### Issue 3: Firebase Rules Blocking Read

**Symptoms:**
- Firebase Console has data
- Browser Console shows: `❌ Firebase data error: permission_denied`
- Dashboard shows demo data

**Solutions:**
1. Go to Firebase Console → Realtime Database → Rules
2. Set rules to:
   ```json
   {
     "rules": {
       ".read": true,
       ".write": true
     }
   }
   ```
3. Click **Publish**

---

### Issue 4: Network Blocking Firebase

**Symptoms:**
- Serial Monitor: "Firebase Update FAILED" or timeout
- Browser Console: Connection errors
- Dashboard shows demo data

**Solutions:**
1. Check internet connection on ESP8266 network
2. Verify firewall doesn't block Firebase domains
3. Check DNS settings
4. Try different network (phone hotspot)

---

### Issue 5: Wrong Firebase Database URL

**Symptoms:**
- ESP8266: "Firebase Update FAILED"
- Serial Monitor shows authentication errors

**Solutions:**
1. Verify database URL in code:
   ```cpp
   "rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
   ```
2. Check for typos
3. Ensure correct region: asia-southeast1
4. Copy URL from Firebase Console → Project Settings

---

## ✅ Quick Checklist

### ESP8266
- [ ] WiFi connected successfully
- [ ] Serial Monitor shows IP address
- [ ] DHT11 readings appear
- [ ] MQ135 readings appear
- [ ] LDR readings appear
- [ ] Shows "Firebase Update SUCCESS"
- [ ] Firebase ERROR doesn't appear

### Firebase
- [ ] Can access Firebase Console
- [ ] Realtime Database is enabled
- [ ] Data appears at `/garden/live`
- [ ] Rules allow read access
- [ ] Rules allow write access

### Dashboard
- [ ] Opens in browser without errors
- [ ] Browser Console shows "Firebase initialized"
- [ ] Browser Console shows "/garden/live" path
- [ ] No "permission_denied" errors
- [ ] Shows live data (not demo)

---

## 🔧 Advanced Debugging

### Enable More Serial Output

Add this to your ESP8266 code:

```cpp
void loop() {
  // ... sensor readings ...

  // Debug output
  Serial.println("========== DEBUG INFO ==========");
  Serial.print("WiFi Status: ");
  Serial.println(WiFi.status() == WL_CONNECTED ? "Connected" : "Not Connected");
  Serial.print("Firebase Ready: ");
  Serial.println(Firebase.ready() ? "Yes" : "No");
  Serial.print("RSSI (Signal): ");
  Serial.println(WiFi.RSSI());
  Serial.println("====================================");

  // ... rest of code ...
}
```

### Test Firebase Connection Manually

Use Firebase Console to test:
1. Go to Firebase Console → Realtime Database
2. Navigate to `/garden/live`
3. Click **Add Value** (plus button)
4. Add test data:
   ```json
   {
     "aqi": 100,
     "gasStatus": "SATISFACTORY",
     "temperature": 25.0,
     "humidity": 60.0,
     "lightStatus": "DAY",
     "timestamp": 1234
   }
   ```
5. Check if dashboard updates

---

## 📱 What to Tell Me

To help you better, please provide:

1. **Browser Console Output (F12)**:
   - Copy all Firebase messages
   - Any error messages?

2. **ESP8266 Serial Monitor Output**:
   - Does it show "Firebase Update SUCCESS"?
   - Any error messages?

3. **Firebase Console Screenshot**:
   - Is data at `/garden/live`?
   - What do you see?

4. **Network Info**:
   - Same network for ESP8266 and browser?
   - Any firewall settings?

---

## 🎯 Expected Behavior When Fixed

When everything works correctly:

### Browser Console:
```javascript
🔥 Firebase initialized
🔥 Data Path: /garden/live
📡 Subscribing to Firebase path: /garden/live
📡 Firebase data received: {aqi: 126, ...}
✅ Valid data received from /garden/live
```

### ESP8266 Serial Monitor:
```text
LIVE SENSOR DATA
Temperature : 29.2 °C
Humidity    : 51.8 %
AQI (India) : 126
AQI Status  : UNHEALTHY
--------------------------------
Sending to Firebase...Firebase Update SUCCESS
```

### Dashboard:
```
✅ NO "Showing Demo Data" warning
✅ AQI: 126 (UNHEALTHY) - Orange
✅ Temperature: 29.2°C
✅ Humidity: 51.8%
✅ Light Status: NIGHT
✅ Charts showing live data
```

---

## 📚 Summary

### Most Common Issues:
1. **ESP8266 not sending to Firebase** (80% of cases)
2. **Firebase rules blocking read** (15% of cases)
3. **Network issues** (5% of cases)

### First Steps:
1. Check ESP8266 Serial Monitor → "Firebase Update SUCCESS"?
2. Check Firebase Console → Data at `/garden/live`?
3. Check Browser Console → Any errors?
4. Check Firebase Rules → Allow read/write?

---

**Please run through these steps and tell me what you find!** 🔍

The most common issue is ESP8266 not sending data. Check the Serial Monitor first! 📱
