# 🔌 ESP8266 Pin Configuration Guide

## ✅ Pin-Specific Configuration

### Your Sensor Pins:

| Sensor | Pin on Board | ESP8266 Pin | Library |
|--------|---------------|--------------|----------|
| MQ135 Gas Sensor | A0 | A0 (ADC0) | Analog Read |
| LDR Light Sensor | D1 | A1 (ADC1) | Analog Read |
| DHT11 Temp/Hum | D2 | D2 (Digital) | DHT library |

---

## 🔌 Important Pin Notes

### ESP8266 Analog Pins
ESP8266 has only **ONE** analog pin: **A0**

| Board Label | Analog Channel | Usage |
|-------------|----------------|--------|
| A0 | ADC0 | MQ135 Gas Sensor |
| A1 | ADC1 | LDR Light Sensor (D1) |

### ESP8266 Digital Pins
D2 is a digital GPIO pin for DHT11 communication

---

## 📱 Code File: `ESP8266_Garden_PinConfigured.ino`

### Pin Definitions Used:

```cpp
#define MQ135_PIN A0              // Gas sensor on A0
#define LDR_PIN A1               // LDR on A1 (D1)
#define DHT11_PIN D2             // DHT11 on D2
#define DHTTYPE DHT11             // DHT11 sensor type
```

---

## 🔌 Wiring Diagram

### Complete Circuit Connections

```
          ESP8266
         ┌─────┐
3.3V ──┤ 1  ├─┬─────────────────┐
         │ 2  │ │
GND ──────┤ 3  ├─┴─────────────────┘
         │    │
         │    │
    ┌────┴────────┐
    │
  MQ135    DHT11      LDR
  (Gas)   (Temp)     (Light)
    │        │          │
    │        │          │
  A0       D2         A1
    │        │          │
    ├────────┤          ├──────┤
```

### Pin-by-Pin Connections

#### 1. MQ135 Gas Sensor (A0)

| MQ135 Pin | ESP8266 Pin | Description |
|-----------|---------------|-------------|
| VCC | 3.3V | Power (or 5V with appropriate resistor) |
| GND | GND | Ground |
| AOUT | A0 | Analog output |

#### 2. DHT11 Temp/Humidity (D2)

| DHT11 Pin | ESP8266 Pin | Description |
|-----------|---------------|-------------|
| VCC | 3.3V | Power |
| DATA | D2 | Data pin |
| NC | NC | Not connected |
| GND | GND | Ground |

**Note**: Add 10KΩ resistor between VCC and DATA pin

#### 3. LDR Light Sensor (A1/D1)

| LDR Pin | ESP8266 Pin | Description |
|----------|---------------|-------------|
| One Leg | 3.3V | Power (through LDR) |
| Other Leg | GND | Ground |
| Junction | A1 | Analog input to ESP8266 |

**Optional**: Add 10KΩ resistor to A1 pin for better sensitivity

---

## 📋 Required Libraries

### 1. Install DHT Library

```
Arduino IDE → Tools → Manage Libraries...
Search: "DHT sensor library"
Install: DHT sensor library for ESPx (by Mark Ruysdonk)
```

### 2. Other Libraries (Already Installed)

```
✅ ESP8266WiFi (pre-installed)
✅ FirebaseESP8266 by Mobizt (install if not present)
✅ Wire (pre-installed)
```

---

## 🚀 Setup Steps

### Step 1: Wire Sensors

#### MQ135 Gas Sensor (A0):
1. Connect MQ135 VCC to ESP8266 3.3V (or 5V)
2. Connect MQ135 GND to ESP8266 GND
3. Connect MQ135 AOUT to ESP8266 A0
4. Power on ESP8266

#### DHT11 Temp/Humidity (D2):
1. Connect DHT11 VCC to ESP8266 3.3V
2. Connect DHT11 DATA to ESP8266 D2 (with 10KΩ resistor)
3. Connect DHT11 GND to ESP8266 GND
4. Connect NC pin - leave unconnected

#### LDR Light Sensor (A1):
1. Connect one LDR leg to ESP8266 3.3V
2. Connect other LDR leg to ESP8266 GND
3. Connect LDR junction to ESP8266 A1
4. Optional: Add 10KΩ pull-up resistor to A1

### Step 2: Configure Code

1. Open: `ESP8266_Garden_PinConfigured.ino`
2. Update WiFi credentials:
   ```cpp
   const char* WIFI_SSID = "Your_Network_Name";
   const char* WIFI_PASSWORD = "Your_Network_Password";
   ```

3. Get Firebase database secret
   - Go to Firebase Console
   - Project Settings → Service Accounts
   - Database Secrets
   - Copy and paste in code

### Step 3: Upload Code

1. Select Board: ESP8266
2. Select Port: COMx
3. Click: Upload (→)

### Step 4: Open Serial Monitor

1. Baud rate: **115200**
2. You should see:
   ```
   ========================================
    SMART GARDEN ESP8266
    Pin Configuration:
     A0 = MQ135 Gas Sensor
     A1 = LDR Light Sensor (D1)
     D2 = DHT11 Temp/Hum Sensor
   ========================================
   ```

---

## 📊 Serial Monitor Output

### What You'll See:

```
Initializing DHT11 sensor...
✅ DHT11 sensor initialized successfully!
 Initial Temp: 24.50 °C
 Initial Hum: 65.00 %

Connecting to WiFi...
....
✅ WiFi connected!
IP Address: 192.168.1.100
SSID: Your_Network_Name

Initializing Firebase...
Firebase initialized!
Firebase Host: rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app
Database Path: /garden/live
========================================

Reading Sensors...
 LDR Value (D1/A1): 345
 Light detected: DAY (LDR: 345)
 Garden Light: OFF (light detected)

Sensor Readings Summary:
  Temperature: 24.50 °C
  Humidity: 65.00 %
  Gas Level (MQ135): 245 (PPM)
  Gas Status: SAFE
  LDR Value: 345 (DAY)
  Garden Light: OFF
  Timestamp: 1704148800000
----------------------------------------

Sending to Firebase...
✅ Temperature sent successfully
✅ Humidity sent successfully
✅ Gas level sent successfully
✅ Gas status sent successfully
✅ Light status sent successfully
✅ Garden light status sent successfully
✅ Timestamp sent successfully
✅ Firebase HTTP response: 200 OK
----------------------------------------
```

---

## 🎯 Sensor Behavior

### MQ135 Gas Sensor (A0)
- **Reads**: Analog value (0-1023)
- **Returns**: PPM level
- **Status Logic**:
  - <200 PPM = SAFE
  - 200-399 PPM = WARNING
  - ≥400 PPM = DANGER

### DHT11 Temp/Humidity (D2)
- **Reads**: Digital data
- **Returns**: Temperature (°C) and Humidity (%)
- **Update**: Every 5 seconds
- **Error Handling**: Falls back to demo values if sensor fails

### LDR Light Sensor (A1/D1)
- **Reads**: Analog value (0-1023)
- **Returns**: Light intensity
- **Status Logic**:
  - >512 = DAY
  - ≤512 = NIGHT
- **Garden Light**:
  - NIGHT = ON
  - DAY = OFF

---

## 🔧 Calibration

### MQ135 Gas Sensor

**Initial Use**: Gas levels will vary
**Calibration**:
1. Let sensor warm up (24-48 hours)
2. Note baseline readings in clean air
3. Adjust thresholds in code if needed:
   ```cpp
   if (sensorData.gasLevel < 200) {
     sensorData.gasStatus = "SAFE";
   } else if (sensorData.gasLevel < 300) {  // Adjust threshold
     sensorData.gasStatus = "WARNING";
   } else {
     sensorData.gasStatus = "DANGER";
   }
   ```

### LDR Light Sensor

**Find Your Threshold**:
1. Cover LDR with hand
2. Note Serial Monitor value (should be low, 50-200)
3. Uncover LDR and expose to room light
4. Note Serial Monitor value (should be high, 700-900)
5. Set threshold between these values

**In Code**:
```cpp
#define LIGHT_THRESHOLD 650  // Set based on your readings
```

### DHT11 Temp/Humidity

**Calibration Tips**:
1. Sensor takes ~1-2 seconds to stabilize
2. Check readings against known temperature
3. Humidity should be 30-70% indoors
4. Temperature should be 20-30°C indoors

---

## 🔍 Troubleshooting

### Problem 1: DHT11 Not Responding

**Symptoms**:
```
⚠️  DHT11 sensor not responding!
⚠️  Check DHT11 on D2 pin
```

**Solutions**:
1. Check DHT11 wiring (VCC, GND, DATA, NC)
2. Verify 10KΩ resistor is installed
3. Check D2 pin connection
4. Try replacing DHT11 sensor
5. Ensure 3.3V power supply is stable

### Problem 2: MQ135 Not Reading

**Symptoms**:
```
Gas Level (MQ135): 0
Gas Status: SAFE (constant)
```

**Solutions**:
1. Check MQ135 wiring (VCC, GND, AOUT)
2. Verify A0 pin connection
3. Check power supply (needs stable voltage)
4. Allow sensor to warm up (24-48 hours)
5. Verify A0 is working (read known voltage)

### Problem 3: LDR Not Reading

**Symptoms**:
```
LDR Value (D1/A1): 0
Light detected: NIGHT (constant)
```

**Solutions**:
1. Check LDR wiring (power and A1 pin)
2. Test A1 pin with multimeter
3. Check if 3.3V is applied to LDR
4. Add pull-up resistor if LDR value is erratic
5. Check if LDR is defective (try replacing)

### Problem 4: Compilation Error - DHT Library

**Symptoms**:
```
error: 'DHT' was not declared
```

**Solutions**:
1. Install: DHT sensor library for ESPx (by Mark Ruysdonk)
2. Library Manager → Search: "DHT sensor"
3. Install and try again

### Problem 5: No Data in Firebase

**Symptoms**:
- Serial shows "sent successfully"
- Firebase Console is empty
- Dashboard shows demo data

**Solutions**:
1. Check Firebase rules (must allow read/write)
2. Verify Firebase database secret is correct
3. Check Firebase host URL is correct
4. Refresh Firebase Console

---

## 📋 Wiring Checklist

### MQ135 Gas Sensor (A0):
- [ ] VCC connected to 3.3V or 5V
- [ ] GND connected to ESP8266 GND
- [ ] AOUT connected to ESP8266 A0
- [ ] Power applied

### DHT11 Temp/Humidity (D2):
- [ ] VCC connected to 3.3V
- [ ] DATA connected to ESP8266 D2
- [ ] 10KΩ resistor between VCC and DATA
- [ ] GND connected to ESP8266 GND
- [ ] NC pin not connected
- [ ] Power applied

### LDR Light Sensor (A1):
- [ ] One leg to 3.3V
- [ ] Other leg to GND
- [ ] Junction to A1 (D1)
- [ ] Optional: 10KΩ pull-up to A1
- [ ] Power applied

### Common:
- [ ] ESP8266 powered on
- [ ] All sensors powered
- [ ] All connections secure
- [ ] No loose wires
- [ ] Code uploaded successfully
- [ ] Serial Monitor open (115200 baud)

---

## 🎯 Expected Dashboard Behavior

### Daytime (Bright):
- ✅ **Temperature**: Real from DHT11
- ✅ **Humidity**: Real from DHT11
- ✅ **Gas Level**: From MQ135
- ✅ **Light Status**: DAY (sun icon ☀️)
- ✅ **Garden Light**: OFF (gray badge)
- ✅ **Gas Status**: SAFE/WARNING/DANGER
- ✅ **Updates**: Every 5 seconds

### Nighttime (Dark):
- ✅ **Temperature**: Real from DHT11
- ✅ **Humidity**: Real from DHT11
- ✅ **Gas Level**: From MQ135
- ✅ **Light Status**: NIGHT (moon icon 🌙)
- ✅ **Garden Light**: ON (green badge)
- ✅ **Gas Status**: SAFE/WARNING/DANGER
- ✅ **Updates**: Every 5 seconds

---

## 📁 File Reference

### Code File:
**`ESP8266_Garden_PinConfigured.ino`**
- Pin: A0 = MQ135 Gas
- Pin: A1 = LDR Light (D1)
- Pin: D2 = DHT11 Temp/Hum
- Path: `/garden/live`
- Update: Every 5 seconds

### Library Dependencies:
- ESP8266WiFi (pre-installed)
- FirebaseESP8266 by Mobizt
- DHT sensor library for ESPx
- Wire (pre-installed)

---

## ✅ Final Verification

### Before Upload:
- [ ] DHT11 sensor library installed
- [ ] All sensors wired correctly
- [ ] WiFi credentials configured
- [ ] Firebase database secret added
- [ ] Pins: A0=MQ135, A1=LDR, D2=DHT11

### After Upload:
- [ ] Serial Monitor opens (115200 baud)
- [ ] WiFi connects successfully
- [ ] DHT11 initialized
- [ ] Sensors read successfully
- [ ] Firebase updates successfully
- [ ] Dashboard shows live data

### Firebase Console:
- [ ] Data at `/garden/live`
- [ ] All 7 fields present
- [ ] Values updating every 5 seconds

### Dashboard:
- [ ] Yellow banner: GONE
- [ ] Real temperature from DHT11
- [ ] Real humidity from DHT11
- [ ] Real gas level from MQ135
- [ ] Light status from LDR
- [ ] Auto garden light control
- [ ] All status badges correct

---

## 🎉 Summary

**Pin Configuration**:
- ✅ A0: MQ135 Gas Sensor
- ✅ A1: LDR Light Sensor (D1)
- ✅ D2: DHT11 Temp/Humidity Sensor

**Complete Setup Provided**:
- ✅ Pin-specific code
- ✅ Wiring diagrams
- ✅ Library requirements
- ✅ Calibration guides
- ✅ Troubleshooting steps

**Your ESP8266 smart garden with all three sensors is ready to use!** 🚀

Just wire the sensors and upload the code to ESP8266!

---

**Important Notes**:
- ESP8266 A1 is the correct pin for D1 analog functionality
- DHT11 requires DHT sensor library for ESPx
- Add 10KΩ resistor to DHT11 data line
- Adjust thresholds based on your environment calibration

**Everything is configured for your specific pins!** 🔌
