# 🔧 ESP8266 Complete Setup Guide

## ✅ What This Guide Covers

1. ✅ Complete ESP8266 code that works with dashboard
2. ✅ Firebase database rules configuration
3. ✅ Testing and troubleshooting steps
4. ✅ How to verify data is sending correctly

---

## 📱 ESP8266 Code

### File Location
`ESP8266_Garden_Dashboard.ino`

### What It Does

Sends **all 7 required fields** to Firebase every 5 seconds:
1. `temperature` (number, °C)
2. `humidity` (number, %)
3. `gasLevel` (number, PPM)
4. `gasStatus` (string: "SAFE", "WARNING", "DANGER")
5. `lightStatus` (string: "DAY", "NIGHT")
6. `gardenLight` (string: "ON", "OFF")
7. `timestamp` (number, milliseconds)

### Firebase Path
`/garden/live` - **MUST match exactly!**

---

## 🚀 Quick Setup Steps

### Step 1: Install Required Libraries

Open Arduino IDE, go to:
```
Tools → Manage Libraries...
```

Install these libraries:

1. **Firebase ESP8266** by Mobizt
   - Search: "firebase esp8266"
   - Version: Latest (4.0.0 or later)

2. **ESP8266WiFi** (usually pre-installed)
   - Search: "esp8266wifi"

### Step 2: Configure WiFi Credentials

Open `ESP8266_Garden_Dashboard.ino` and find these lines:

```cpp
const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
```

**Replace with your WiFi:**

```cpp
const char* WIFI_SSID = "Your_Network_Name";
const char* WIFI_PASSWORD = "Your_Network_Password";
```

### Step 3: Get Firebase Database Secret

**IMPORTANT**: This is NOT the same as API key!

#### How to Get Firebase Secret:

1. Go to Firebase Console: https://console.firebase.google.com/
2. Select project: **rfid-aaruto**
3. Click **⚙️ Settings** (gear icon)
4. Select **Project Settings**
5. Go to **Service Accounts** tab
6. Scroll to **Realtime Database Secrets**
7. Click **Show** next to database secret
8. **Copy the secret** (long string)

#### Paste into Code:

Find this line in `ESP8266_Garden_Dashboard.ino`:

```cpp
#define FIREBASE_AUTH "YOUR_FIREBASE_DATABASE_SECRET"
```

Replace with your secret:

```cpp
#define FIREBASE_AUTH "AIzaSyClHyEygOT1Qh87x01vnG4LxtFCXLSP1FA"
```

**Note**: The secret above is just an example. Use your actual secret from Firebase Console.

### Step 4: Upload to ESP8266

1. Connect ESP8266 to computer via USB
2. Open Arduino IDE
3. Open `ESP8266_Garden_Dashboard.ino`
4. Select Board:
   ```
   Tools → Board → ESP8266 Boards → Generic ESP8266 Module
   ```
5. Select COM Port:
   ```
   Tools → Port → COMx (your ESP8266 port)
   ```
6. Click **Upload** button (→)
7. Wait for upload to complete

### Step 5: Open Serial Monitor

1. Click **Serial Monitor** icon (magnifying glass)
2. Set baud rate: **115200**
3. You should see:

```
========================================
  SMART GARDEN ESP8266
========================================

Connecting to WiFi...
....
✅ WiFi connected!
IP Address: 192.168.1.100
SSID: Your_Network

Initializing Firebase...
Firebase initialized!
Firebase Host: rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app
Database Path: /garden/live
========================================

Reading Sensors...
Sensor Readings:
  Temperature: 24.5 °C
  Humidity: 68 %
  Gas Level: 120 PPM
  Gas Status: SAFE
  Light Status: DAY
  Garden Light: ON
  Timestamp: 1704148800000
Sending to Firebase...
✅ Data sent successfully!
✅ Firebase HTTP response: 200 OK
----------------------------------------
```

---

## 🔥 CRITICAL: Firebase Database Rules

**This is the #1 reason data doesn't show!**

### Step 1: Go to Firebase Console

1. Visit: https://console.firebase.google.com/
2. Select project: **rfid-aaruto**
3. Navigate to: **Realtime Database**
4. Click: **Rules** tab

### Step 2: Update Rules

**Replace current rules with this:**

```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

### Step 3: Publish Rules

1. Click **Publish** button
2. Wait for success message

### Step 4: Verify Rules

You should see:
```
✅ Published successfully
```

---

## ✅ Verification Steps

### Step 1: Check ESP8266 Serial Monitor

You should see every 5 seconds:

```
Sending to Firebase...
✅ Data sent successfully!
✅ Firebase HTTP response: 200 OK
```

**If you see errors:**
```
❌ Failed to send data!
Error code: 401
→ FIREBASE_AUTH is wrong. Check your secret.

❌ Failed to send data!
Error code: 404
→ FIREBASE_HOST is wrong or database doesn't exist.

❌ Failed to send data!
Error reason: connection refused
→ WiFi not connected or no internet.
```

### Step 2: Check Firebase Console

1. Go to Realtime Database
2. You should see data appearing at `garden/live`:

```json
{
  "temperature": 24.5,
  "humidity": 68,
  "gasLevel": 120,
  "gasStatus": "SAFE",
  "lightStatus": "DAY",
  "gardenLight": "ON",
  "timestamp": 1704148800000
}
```

**Data should update every 5 seconds!**

### Step 3: Check Dashboard

1. Open: http://localhost:3000
2. Login: **VIPIN** / **VIPIN123**
3. Yellow banner should **disappear**
4. Data source should say: **"Firebase Realtime Database"**
5. Values should update in real-time!

---

## 🎨 Data Format Reference

### What Dashboard Expects

```json
{
  "temperature": 24.5,      // Required: number (Celsius)
  "humidity": 68,            // Required: number (percentage)
  "gasLevel": 120,           // Required: number (PPM)
  "gasStatus": "SAFE",        // Required: string
  "lightStatus": "DAY",       // Required: string
  "gardenLight": "ON",        // Required: string
  "timestamp": 1704148800000  // Required: number (milliseconds)
}
```

### Status Values

#### Gas Status (gasStatus)
| Value | Condition | Color |
|-------|-----------|-------|
| "SAFE" | gasLevel < 200 PPM | Green |
| "WARNING" | 200 ≤ gasLevel < 400 PPM | Yellow |
| "DANGER" | gasLevel ≥ 400 PPM | Red |

#### Light Status (lightStatus)
| Value | Condition | Icon |
|-------|-----------|------|
| "DAY" | Light sensor > 512 | Sun ☀️ |
| "NIGHT" | Light sensor ≤ 512 | Moon 🌙 |

#### Garden Light (gardenLight)
| Value | Meaning | Color |
|-------|---------|-------|
| "ON" | Garden light is ON | Green |
| "OFF" | Garden light is OFF | Gray |

---

## 🔧 Troubleshooting

### Problem 1: WiFi Not Connecting

**Serial Monitor Shows:**
```
❌ WiFi connection failed!
```

**Solutions:**
1. Check WiFi SSID and password are correct
2. Make sure ESP8266 is close to router
3. Try 2.4GHz WiFi network (not 5GHz)
4. Restart ESP8266

### Problem 2: Firebase Not Sending

**Serial Monitor Shows:**
```
❌ Failed to send data!
Error code: 401
```

**Solutions:**
1. Firebase secret is wrong
2. Get fresh secret from Firebase Console
3. Update code and re-upload

**Serial Monitor Shows:**
```
❌ Failed to send data!
Error code: 404
```

**Solutions:**
1. Firebase host URL is wrong
2. Verify: `rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app`
3. Check project exists in Firebase Console

### Problem 3: Dashboard Still Shows Demo Data

**Possible Causes:**

1. **Firebase rules block read access**
   - **Fix**: Update rules to allow read (see above)
   - **Verify**: Rules are published

2. **Wrong Firebase path**
   - ESP8266 sending to: `/gardenData/live`
   - Dashboard expects: `/garden/live`
   - **Fix**: Update ESP8266 to use `/garden/live`

3. **Data format doesn't match**
   - Missing required fields
   - Wrong data types
   - **Fix**: Use provided ESP8266 code

4. **Firebase Console shows data, but dashboard doesn't**
   - Clear browser cache: Ctrl+Shift+Delete
   - Refresh page: F5
   - Check browser console for errors

### Problem 4: Data Not Updating

**Serial Monitor shows "sent successfully" but Firebase doesn't update:**

**Solutions:**
1. Check Firebase rules allow WRITE access
2. Verify Firebase secret is correct
3. Check internet connection
4. Try pressing ESP8266 reset button

---

## 📋 Checklist

### Before Upload
- [ ] WiFi SSID and password configured
- [ ] Firebase database secret obtained
- [ ] Firebase host verified correct
- [ ] FirebaseESP8266 library installed
- [ ] Board set to ESP8266
- [ ] Correct COM port selected

### After Upload
- [ ] Serial Monitor opens at 115200 baud
- [ ] WiFi connects successfully
- [ ] Firebase initializes successfully
- [ ] "Data sent successfully" appears every 5 seconds
- [ ] No error messages in Serial Monitor

### Firebase Console
- [ ] Can see Realtime Database
- [ ] Data appears at `/garden/live` path
- [ ] All 7 fields present
- [ ] Data updates every 5 seconds
- [ ] Database rules allow read and write

### Dashboard
- [ ] Login successful (VIPIN/VIPIN123)
- [ ] Yellow demo banner disappears
- [ ] Data source says "Firebase Realtime Database"
- [ ] Temperature, humidity, gas values display
- [ ] Status badges show correct colors
- [ ] Values update when ESP8266 sends data
- [ ] Charts show live data (not demo)

---

## 🚨 Common Mistakes to Avoid

### ❌ Wrong Firebase Path

```cpp
// WRONG
Firebase.setJSON(firebaseData, "/gardenData/live", json);
Firebase.setJSON(firebaseData, "/sensor/data", json);
Firebase.setJSON(firebaseData, "garden/live", json); // Missing leading slash

// CORRECT
Firebase.setJSON(firebaseData, "/garden/live", json);
```

### ❌ Wrong Data Types

```cpp
// WRONG
json.add("temperature", "24.5");  // String instead of number
json.add("gasStatus", 1);          // Number instead of string

// CORRECT
json.add("temperature", 24.5);     // Number
json.add("gasStatus", "SAFE");      // String
```

### ❌ Missing Fields

```cpp
// WRONG - Only 5 fields
json.add("temperature", 24.5);
json.add("humidity", 68);
json.add("gasLevel", 120);
json.add("gasStatus", "SAFE");
json.add("lightStatus", "DAY");

// CORRECT - All 7 fields
json.add("temperature", 24.5);
json.add("humidity", 68);
json.add("gasLevel", 120);
json.add("gasStatus", "SAFE");
json.add("lightStatus", "DAY");
json.add("gardenLight", "ON");
json.add("timestamp", 1704148800000);
```

### ❌ Not Publishing Firebase Rules

After changing rules:
```
❌ Forgot to click "Publish"
```
Rules don't apply until published!

```
✅ Click "Publish"
✅ Wait for success message
```

---

## 📞 Still Having Issues?

### Collect This Information:

1. **Serial Monitor Output**:
   - Copy all text from Serial Monitor
   - Especially error messages

2. **Firebase Console**:
   - Screenshot of Realtime Database
   - Show what rules you have

3. **Browser Console** (F12):
   - Look for error messages
   - Screenshot console output

### What to Report:

```
✓ Serial Monitor:
[Paste serial output here]

✓ Firebase Console:
[Describe what you see]

✓ Browser Console:
[Paste any errors here]

✓ Firebase Rules:
[Paste your rules here]
```

---

## ✅ Success Indicators

You'll know everything is working when:

### ESP8266 Serial Monitor:
```
✅ WiFi connected!
✅ Firebase initialized!
✅ Data sent successfully!
```

### Firebase Console:
- Data appears at `garden/live`
- All 7 fields present
- Updates every 5 seconds

### Dashboard:
- ✅ No yellow "Demo Data" banner
- ✅ "Firebase Realtime Database" in System Information
- ✅ Real sensor values displayed
- ✅ Values update in real-time
- ✅ Browser console shows data received

---

## 🎉 Summary

1. ✅ Complete ESP8266 code provided
2. ✅ Sends all 7 required fields
3. ✅ Updates every 5 seconds
4. ✅ Correct Firebase path: `/garden/live`
5. ✅ Detailed Serial Monitor output
6. ✅ Error handling and logging
7. ✅ Firebase rules configuration guide

**Use this code with Firebase rules updated and your dashboard will work perfectly!**

---

**Files:**
- `ESP8266_Garden_Dashboard.ino` - Complete ESP8266 code
- `ESP8266_DATA_STRUCTURE.md` - Data format reference

**Next Steps:**
1. Install FirebaseESP8266 library
2. Configure WiFi credentials
3. Get Firebase database secret
4. Update Firebase rules (CRITICAL!)
5. Upload code to ESP8266
6. Watch dashboard update in real-time!
