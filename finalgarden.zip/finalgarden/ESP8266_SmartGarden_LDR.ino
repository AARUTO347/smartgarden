/*
 * ESP8266 Smart Garden Firebase Sender - With LDR Sensor
 * LDR (Light Dependent Resistor) on D1 pin (A0)
 *
 * Sends all 7 required fields to Firebase at /garden/live
 */

#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>

// ===== WIFI CREDENTIALS =====
// CHANGE THESE TO YOUR WIFI NETWORK
const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ===== FIREBASE CREDENTIALS =====
#define FIREBASE_HOST "rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
#define FIREBASE_AUTH "YOUR_FIREBASE_DATABASE_SECRET"

// Firebase Database Secret (Get from Firebase Console)
// Steps:
// 1. Go to https://console.firebase.google.com/
// 2. Select project: rfid-aaruto
// 3. Go to Project Settings
// 4. Service Accounts
// 5. Database Secrets
// 6. Copy of database secret
// 7. Paste it below in quotes: "your-secret-here"

// ===== SENSOR CONFIGURATION =====
#define UPDATE_INTERVAL 5000  // Update every 5 seconds (5000 ms)
#define LDR_PIN A0             // LDR connected to A0 (same as D1)
#define LIGHT_THRESHOLD 512   // Threshold: >512 = DAY, <=512 = NIGHT

// ===== OBJECTS =====
WiFiClient wifiClient;
FirebaseData firebaseData;
Adafruit_AHTX0 aht;

// ===== SENSOR DATA STRUCTURE =====
struct SensorData {
  float temperature;      // Celsius
  float humidity;        // Percentage (0-100)
  int gasLevel;          // PPM (0-1023)
  String gasStatus;       // "SAFE", "WARNING", "DANGER"
  String lightStatus;     // "DAY", "NIGHT"
  String gardenLight;     // "ON", "OFF"
  unsigned long timestamp; // Milliseconds since epoch
};

SensorData sensorData;

// ===== FUNCTION PROTOTYPES =====
void setupWiFi();
void readSensors();
void determineGasStatus();
void determineLightStatus();
void determineGardenLight();
void sendToFirebase();
unsigned long getCurrentTimestamp();

// ===== SETUP =====
void setup() {
  // Initialize Serial
  Serial.begin(115200);
  Serial.println("\n");
  Serial.println("========================================");
  Serial.println("  SMART GARDEN ESP8266");
  Serial.println("  With LDR Light Sensor");
  Serial.println("========================================\n");

  // Initialize I2C for AHT sensor
  Wire.begin();

  // Initialize AHT sensor
  if (!aht.begin()) {
    Serial.println("⚠️  Could not find AHT sensor!");
    Serial.println("⚠️  Using demo sensor values instead.");
  } else {
    Serial.println("✅ AHT sensor initialized successfully!");
  }

  // Setup WiFi
  setupWiFi();

  // Initialize Firebase
  Serial.println("Initializing Firebase...");
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);

  Serial.println("Firebase initialized!");
  Serial.print("Firebase Host: ");
  Serial.println(FIREBASE_HOST);
  Serial.print("Database Path: /garden/live");
  Serial.print("LDR Pin: A0 (D1)");
  Serial.println("\n========================================\n");

  // Initial sensor reading
  readSensors();
  sendToFirebase();
}

// ===== MAIN LOOP =====
void loop() {
  // Read all sensors
  readSensors();

  // Send to Firebase
  sendToFirebase();

  // Wait before next reading
  delay(UPDATE_INTERVAL);
}

// ===== SETUP WIFI =====
void setupWiFi() {
  Serial.println("Connecting to WiFi...");

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  // Wait for connection
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✅ WiFi connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
    Serial.print("SSID: ");
    Serial.println(WiFi.SSID());
  } else {
    Serial.println("\n❌ WiFi connection failed!");
    Serial.println("Please check your WiFi credentials");
  }

  Serial.println("");
}

// ===== READ SENSORS =====
void readSensors() {
  Serial.println("----------------------------------------");
  Serial.println("Reading Sensors...");

  // 1. READ TEMPERATURE AND HUMIDITY from AHT
  if (aht.begin()) {
    sensors_event_t humidityEvent = aht.getHumiditySensorData();
    sensors_event_t tempEvent = aht.getTemperatureSensorData();

    // Access to temperature directly from event
    if (!isnan(tempEvent.temperature)) {
      sensorData.temperature = tempEvent.temperature;
    } else {
      sensorData.temperature = 20.0 + (rand() % 15); // Fallback: 20-35°C
    }

    // Access to humidity directly
    if (!isnan(humidityEvent.relative_humidity)) {
      sensorData.humidity = humidityEvent.relative_humidity;
    } else {
      sensorData.humidity = 40.0 + (rand() % 40); // Fallback: 40-80%
    }
  } else {
    // Fallback if sensor not available
    sensorData.temperature = 20.0 + (rand() % 15);
    sensorData.humidity = 40.0 + (rand() % 40);
  }

  // 2. READ GAS LEVEL
  // Replace with actual gas sensor reading on analog pin
  // int gasValue = analogRead(A0);
  sensorData.gasLevel = 50 + (rand() % 300); // 50-350 PPM (demo)

  // 3. READ LDR (LIGHT SENSOR)
  // LDR on A0 pin (same as D1 on ESP8266)
  int ldrValue = analogRead(LDR_PIN);
  Serial.print("  LDR Raw Value: ");
  Serial.println(ldrValue);
  
  // Determine light status based on LDR value
  determineLightStatus(ldrValue);

  // 4. DETERMINE GAS STATUS
  determineGasStatus();

  // 5. DETERMINE GARDEN LIGHT STATUS
  determineGardenLight();

  // 6. GET CURRENT TIMESTAMP
  sensorData.timestamp = getCurrentTimestamp();

  // Print sensor readings
  Serial.println("Sensor Readings:");
  Serial.print("  Temperature: ");
  Serial.print(sensorData.temperature);
  Serial.println(" °C");
  Serial.print("  Humidity: ");
  Serial.print(sensorData.humidity);
  Serial.println(" %");
  Serial.print("  Gas Level: ");
  Serial.print(sensorData.gasLevel);
  Serial.println(" PPM");
  Serial.print("  Gas Status: ");
  Serial.println(sensorData.gasStatus);
  Serial.print("  LDR Value: ");
  Serial.print(ldrValue);
  Serial.print(" (");
  Serial.print(sensorData.lightStatus);
  Serial.println(")");
  Serial.print("  Garden Light: ");
  Serial.println(sensorData.gardenLight);
  Serial.print("  Timestamp: ");
  Serial.println(sensorData.timestamp);
}

// ===== DETERMINE GAS STATUS =====
void determineGasStatus() {
  if (sensorData.gasLevel < 200) {
    sensorData.gasStatus = "SAFE";
  } else if (sensorData.gasLevel < 400) {
    sensorData.gasStatus = "WARNING";
  } else {
    sensorData.gasStatus = "DANGER";
  }
}

// ===== DETERMINE LIGHT STATUS =====
void determineLightStatus(int ldrValue) {
  // LDR threshold: 512 (midpoint of 0-1023)
  // LDR on A0 (same as D1 pin on ESP8266)
  // Higher LDR value = more light = DAY
  // Lower LDR value = less light = NIGHT
  
  if (ldrValue > LIGHT_THRESHOLD) {
    sensorData.lightStatus = "DAY";
    Serial.print("  Light detected: DAY (LDR: ");
    Serial.print(ldrValue);
    Serial.println(")");
  } else {
    sensorData.lightStatus = "NIGHT";
    Serial.print("  Light detected: NIGHT (LDR: ");
    Serial.print(ldrValue);
    Serial.println(")");
  }
}

// ===== DETERMINE GARDEN LIGHT STATUS =====
void determineGardenLight() {
  // Simple logic: Turn garden light ON at night, OFF during day
  if (sensorData.lightStatus == "NIGHT") {
    sensorData.gardenLight = "ON";
  } else {
    sensorData.gardenLight = "OFF";
  }

  // Add random variation for demo
  if (rand() % 10 == 0) {
    sensorData.gardenLight = (sensorData.gardenLight == "ON") ? "OFF" : "ON";
  }
}

// ===== GET CURRENT TIMESTAMP =====
unsigned long getCurrentTimestamp() {
  // Return timestamp in milliseconds since epoch
  // January 1, 2024 in milliseconds
  unsigned long baseTimestamp = 1704067200000UL;
  unsigned long elapsed = millis();

  return baseTimestamp + elapsed;
}

// ===== SEND TO FIREBASE =====
void sendToFirebase() {
  Serial.println("Sending to Firebase...");

  // Send each field individually
  bool allSuccess = true;

  // Send temperature
  if (Firebase.setFloat(firebaseData, "/garden/live/temperature", sensorData.temperature)) {
    Serial.println("✅ Temperature sent successfully");
  } else {
    Serial.println("❌ Temperature failed to send");
    allSuccess = false;
  }

  // Send humidity
  if (Firebase.setFloat(firebaseData, "/garden/live/humidity", sensorData.humidity)) {
    Serial.println("✅ Humidity sent successfully");
  } else {
    Serial.println("❌ Humidity failed to send");
    allSuccess = false;
  }

  // Send gas level
  if (Firebase.setInt(firebaseData, "/garden/live/gasLevel", sensorData.gasLevel)) {
    Serial.println("✅ Gas level sent successfully");
  } else {
    Serial.println("❌ Gas level failed to send");
    allSuccess = false;
  }

  // Send gas status
  if (Firebase.setString(firebaseData, "/garden/live/gasStatus", sensorData.gasStatus)) {
    Serial.println("✅ Gas status sent successfully");
  } else {
    Serial.println("❌ Gas status failed to send");
    allSuccess = false;
  }

  // Send light status
  if (Firebase.setString(firebaseData, "/garden/live/lightStatus", sensorData.lightStatus)) {
    Serial.println("✅ Light status sent successfully");
  } else {
    Serial.println("❌ Light status failed to send");
    allSuccess = false;
  }

  // Send garden light status
  if (Firebase.setString(firebaseData, "/garden/live/gardenLight", sensorData.gardenLight)) {
    Serial.println("✅ Garden light status sent successfully");
  } else {
    Serial.println("❌ Garden light status failed to send");
    allSuccess = false;
  }

  // Send timestamp
  if (Firebase.setLong(firebaseData, "/garden/live/timestamp", sensorData.timestamp)) {
    Serial.println("✅ Timestamp sent successfully");
  } else {
    Serial.println("❌ Timestamp failed to send");
    allSuccess = false;
  }

  // Check HTTP response code
  if (firebaseData.httpCode() == 200) {
    Serial.println("✅ Firebase HTTP response: 200 OK");
  } else if (firebaseData.httpCode() != 0) {
    Serial.print("⚠️  Firebase HTTP response: ");
    Serial.println(firebaseData.httpCode());
  }

  Serial.println("----------------------------------------\n");
}
