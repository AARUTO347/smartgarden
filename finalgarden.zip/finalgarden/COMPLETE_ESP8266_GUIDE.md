# Smart Garden Dashboard - Complete Setup Guide

## Overview

This Smart Garden Dashboard is a real-time monitoring system for garden sensors including temperature, humidity, gas levels, and light control. It uses Firebase Realtime Database for live data updates.

## Features

### 1. **Dashboard View**
- Real-time sensor cards displaying:
  - **Temperature** (°C) - Current temperature reading
  - **Humidity** (%) - Relative humidity percentage
  - **Light Status** (DAY/NIGHT) - Day/night cycle detection
  - **Garden Light** (ON/OFF) - Garden light control status
  - **Gas Status** (SAFE/WARNING/DANGER) - Gas sensor safety status with PPM level

### 2. **Charts View**
- **Temperature & Humidity Area Chart** - Visualizes temperature and humidity trends over time
- **AQI History Bar Chart** - Displays gas level history

### 3. **Raw Data View**
- Complete JSON data structure display
- Individual data field breakdown
- Formatted timestamp display

## Firebase Data Structure

### JSON Format

```json
{
  "temperature": 24.5,
  "humidity": 68,
  "gasLevel": 120,
  "gasStatus": "SAFE",
  "lightStatus": "DAY",
  "gardenLight": "ON",
  "timestamp": 1704148800000
}
```

### Field Specifications

| Field | Type | Range/Values | Description |
|-------|------|--------------|-------------|
| `temperature` | number | -40 to 85 | Temperature in Celsius |
| `humidity` | number | 0 to 100 | Relative humidity percentage |
| `gasLevel` | integer | 0 to 1023 | Gas sensor PPM level |
| `gasStatus` | string | "SAFE", "WARNING", "DANGER" | Gas safety status |
| `lightStatus` | string | "DAY", "NIGHT" | Day/night cycle |
| `gardenLight` | string | "ON", "OFF" | Garden light status |
| `timestamp` | number | Unix timestamp (ms) | Milliseconds since epoch |

### Firebase Configuration

- **Database URL**: `https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app`
- **Path**: `garden/live`
- **API Key**: `AIzaSyClHyEygOT1Qh87x01vnG4LxtFCXLSP1FA`
- **Project ID**: `rfid-aaruto`

## ESP8266 Data Sending

### Required Data Fields

Your ESP8266 must send ALL the following fields to Firebase:

```json
{
  "temperature": <float>,
  "humidity": <float>,
  "gasLevel": <integer>,
  "gasStatus": <string>,
  "lightStatus": <string>,
  "gardenLight": <string>,
  "timestamp": <number>
}
```

### Arduino/C++ Data Structure

```cpp
struct SensorData {
  float temperature;      // Temperature in Celsius
  float humidity;        // Humidity percentage (0-100)
  int gasLevel;          // Gas sensor PPM (0-1023)
  String gasStatus;      // "SAFE", "WARNING", "DANGER"
  String lightStatus;    // "DAY", "NIGHT"
  String gardenLight;    // "ON", "OFF"
  unsigned long timestamp; // Unix timestamp in milliseconds
};
```

### Status Logic Implementation

#### Gas Status Logic

```cpp
String determineGasStatus(int gasLevel) {
  if (gasLevel < 200) {
    return "SAFE";
  } else if (gasLevel < 400) {
    return "WARNING";
  } else {
    return "DANGER";
  }
}
```

#### Light Status Logic

```cpp
String determineLightStatus(int lightSensorValue) {
  // lightSensorValue is 0-1023 from analog read
  return (lightSensorValue > 512) ? "DAY" : "NIGHT";
}
```

#### Garden Light Logic

```cpp
String determineGardenLight(String lightStatus) {
  // Example: Turn ON garden light at night
  return (lightStatus == "NIGHT") ? "ON" : "OFF";
}
```

### Firebase Upload Example

```cpp
#include <FirebaseESP8266.h>

void sendToFirebase(SensorData data) {
  FirebaseJson json;
  json.add("temperature", data.temperature);
  json.add("humidity", data.humidity);
  json.add("gasLevel", data.gasLevel);
  json.add("gasStatus", data.gasStatus);
  json.add("lightStatus", data.lightStatus);
  json.add("gardenLight", data.gardenLight);
  json.add("timestamp", data.timestamp);

  if (Firebase.setJSON(firebaseData, "/garden/live", json)) {
    Serial.println("Data sent successfully");
  } else {
    Serial.println("Failed to send data");
    Serial.println(firebaseData.errorReason());
  }
}
```

### Complete ESP8266 Example

See `ESP8266_Firebase_Sender/ESP8266_SmartGarden.ino` for the complete implementation.

## Dashboard Data Display

### Dashboard Cards

Each sensor card displays:
- **Icon** - Visual indicator of sensor type
- **Value** - Current reading with unit
- **Description** - Brief description of the metric
- **Status Badge** (for status cards) - Active state indicator

### Color Coding

#### Gas Status Colors
- **SAFE**: Green
- **WARNING**: Yellow
- **DANGER**: Red

#### Light Status Colors
- **DAY**: Yellow (Sun icon)
- **NIGHT**: Blue (Moon icon)

#### Garden Light Colors
- **ON**: Green
- **OFF**: Gray

### Chart Display

#### Temperature & Humidity Chart
- **Temperature**: Orange area chart
- **Humidity**: Blue area chart
- **X-Axis**: Time (HH:MM format)
- **Y-Axis**: Temperature (°C) and Humidity (%)

#### AQI History Chart
- **AQI Level**: Yellow bar chart
- **X-Axis**: Time (HH:MM format)
- **Y-Axis**: Gas level (PPM)

### Raw Data Display

The Raw Data view shows:
1. **Complete JSON** - Formatted JSON of all sensor data
2. **Data Fields** - Individual numeric values
3. **Status Fields** - All status indicators with badges
4. **Timestamp** - Human-readable date and time

## Example Data Sets

### Example 1: Normal Day Conditions
```json
{
  "temperature": 26.5,
  "humidity": 65,
  "gasLevel": 95,
  "gasStatus": "SAFE",
  "lightStatus": "DAY",
  "gardenLight": "OFF",
  "timestamp": 1704148800000
}
```

### Example 2: Night with Garden Light ON
```json
{
  "temperature": 22.3,
  "humidity": 78,
  "gasLevel": 110,
  "gasStatus": "SAFE",
  "lightStatus": "NIGHT",
  "gardenLight": "ON",
  "timestamp": 1704152400000
}
```

### Example 3: Warning Level Gas
```json
{
  "temperature": 25.8,
  "humidity": 70,
  "gasLevel": 315,
  "gasStatus": "WARNING",
  "lightStatus": "DAY",
  "gardenLight": "OFF",
  "timestamp": 1704156000000
}
```

### Example 4: Danger Level Gas
```json
{
  "temperature": 27.2,
  "humidity": 62,
  "gasLevel": 485,
  "gasStatus": "DANGER",
  "lightStatus": "DAY",
  "gardenLight": "OFF",
  "timestamp": 1704159600000
}
```

## Testing Data

You can test the dashboard by manually adding data to Firebase:

1. Go to Firebase Console: https://console.firebase.google.com/
2. Select project: `rfid-aaruto`
3. Navigate to Realtime Database
4. Find path: `garden/live`
5. Add the example JSON data above

## Default Credentials

- **Username**: `VIPIN`
- **Password**: `VIPIN123`

## CSV Export

The dashboard supports CSV export of current sensor data:
1. Go to Dashboard view
2. Click "Export CSV" button
3. CSV file will download with all sensor fields

## Technical Stack

- **Framework**: Next.js 15 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4
- **UI Components**: shadcn/ui (New York style)
- **Database**: Firebase Realtime Database
- **Charts**: Recharts
- **Icons**: Lucide React

## File Structure

```
src/
├── app/
│   ├── page.tsx              # Main application page
│   ├── layout.tsx            # Root layout
│   └── globals.css           # Global styles
├── components/
│   ├── dashboard.tsx         # Dashboard component (main)
│   ├── data-charts.tsx       # Charts component
│   ├── login.tsx             # Login component
│   ├── signup.tsx            # Signup component
│   └── ui/                   # shadcn/ui components
├── hooks/
│   └── use-session.ts        # Session management hook
└── lib/
    ├── firebase.ts           # Firebase configuration
    ├── app-logic.ts          # Application logic and hooks
    └── csv-export.ts         # CSV export utility
```

## Branding

All pages display:
```
MADE BY AARUTO
POWERED BY CHRONOBOTICS
```

## Troubleshooting

### No Data Showing

1. Check Firebase credentials in `src/lib/firebase.ts`
2. Verify Firebase database rules allow read/write access
3. Check ESP8266 is sending data to correct path: `garden/live`
4. Check browser console for Firebase errors

### Data Not Updating

1. Verify ESP8266 is connected to WiFi
2. Check ESP8266 is sending data every 5 seconds
3. Verify Firebase connection is active
4. Check network connectivity

### Charts Not Showing

1. Ensure historical data is being collected
2. Check that timestamps are valid
3. Verify data format is correct
4. Clear browser cache and refresh

## Additional Resources

- **ESP8266 Code**: `ESP8266_Firebase_Sender/ESP8266_SmartGarden.ino`
- **Data Structure**: `ESP8266_DATA_STRUCTURE.md`
- **Example Data**: `firebase-data-examples.json`
- **Firebase Console**: https://console.firebase.google.com/

## Support

For issues or questions:
1. Check Firebase Console for database status
2. Review ESP8266 Serial Monitor for errors
3. Check browser console for client-side errors
4. Verify all data fields are being sent correctly

---

**Last Updated**: January 2024
**Version**: 1.0.0
