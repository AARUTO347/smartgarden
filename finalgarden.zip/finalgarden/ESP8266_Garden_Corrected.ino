/****************************************************
 * Smart Garden Monitoring System - CORRECTED VERSION
 * Firebase Project : rfid-aaruto
 *
 * Updates:
 * - Added debug output
 * - Fixed LDR logic (test both versions)
 * - Extended AQI scale to 500
 * - Added error handling
 ****************************************************/

#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <DHT.h>

/* ========== PIN CONFIG ========== */
#define DHTPIN D2
#define DHTTYPE DHT11
#define LDR_PIN D1
#define MQ135_PIN A0

/* ========== WIFI DETAILS ========== */
#define WIFI_SSID     "VIPIN"
#define WIFI_PASSWORD "@@@@@@@@"

/* ========== FIREBASE DETAILS ========== */
#define FIREBASE_HOST "rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
#define FIREBASE_AUTH "9gPXcUYJty4rjU05k1mBDEUUnXEyt9SQKB1nQTRz"

/* ========== OBJECTS ========== */
FirebaseData fbdo;
FirebaseAuth auth;
FirebaseConfig config;
DHT dht(DHTPIN, DHTTYPE);

/* ========== AQI CONVERSION (Extended to 500) ========== */
int convertMQ135ToAQI(int raw) {
  if (raw <= 150) return map(raw, 0, 150, 0, 50);
  if (raw <= 300) return map(raw, 151, 300, 51, 100);
  if (raw <= 500) return map(raw, 301, 500, 101, 200);
  if (raw <= 700) return map(raw, 501, 700, 201, 300);
  if (raw <= 900) return map(raw, 701, 900, 301, 400);
  return map(raw, 901, 1023, 401, 500);  // Full 500 scale
}

/* ========== GAS STATUS ========== */
String getAQIStatus(int aqi) {
  if (aqi <= 50) return "GOOD";
  if (aqi <= 100) return "MODERATE";
  if (aqi <= 150) return "UNHEALTHY";
  if (aqi <= 200) return "VERY_UNHEALTHY";
  return "HAZARDOUS";
}

/* ========== SETUP ========== */
void setup() {
  Serial.begin(9600);
  delay(100);

  Serial.println("\n========================================");
  Serial.println("  SMART GARDEN MONITORING SYSTEM");
  Serial.println("========================================");

  pinMode(LDR_PIN, INPUT);
  dht.begin();

  Serial.println("Connecting to WiFi...");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✅ WiFi Connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\n❌ WiFi Connection Failed!");
    while(1) delay(1000);
  }

  Serial.println("\nInitializing Firebase...");
  config.host = FIREBASE_HOST;
  config.signer.tokens.legacy_token = FIREBASE_AUTH;

  Firebase.begin(&config, &auth);
  Firebase.reconnectWiFi(true);

  Serial.println("✅ Firebase Ready!");
  Serial.print("Firebase Host: ");
  Serial.println(FIREBASE_HOST);
  Serial.print("Database Path: garden/live\n");

  Serial.println("========================================\n");
}

/* ========== MAIN LOOP ========== */
void loop() {

  // Read DHT sensor
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("❌ Failed to read from DHT sensor!");
    delay(2000);
    return;
  }

  // Read MQ135 gas sensor
  int mqRaw = analogRead(MQ135_PIN);
  int aqi = convertMQ135ToAQI(mqRaw);
  String gasStatus = getAQIStatus(aqi);

  // Read LDR light sensor
  int ldrValue = digitalRead(LDR_PIN);
  // NOTE: Test this logic - swap HIGH/LOW if backwards
  String lightStatus = (ldrValue == LOW) ? "DAY" : "NIGHT";

  // Get timestamp
  unsigned long timestamp = millis() / 1000;

  // Debug output
  Serial.println("========== SENSOR READINGS ==========");
  Serial.print("Temperature: "); Serial.print(temperature); Serial.println(" °C");
  Serial.print("Humidity: "); Serial.print(humidity); Serial.println(" %");
  Serial.print("MQ135 Raw: "); Serial.println(mqRaw);
  Serial.print("AQI: "); Serial.println(aqi);
  Serial.print("Gas Status: "); Serial.println(gasStatus);
  Serial.print("LDR Value: "); Serial.println(ldrValue);
  Serial.print("Light Status: "); Serial.println(lightStatus);
  Serial.print("Timestamp: "); Serial.println(timestamp);
  Serial.println("=====================================");

  // Create Firebase JSON object
  FirebaseJson json;
  json.set("garden/live/gasLevel", mqRaw);
  json.set("garden/live/aqi", aqi);
  json.set("garden/live/gasStatus", gasStatus);
  json.set("garden/live/humidity", humidity);
  json.set("garden/live/temperature", temperature);
  json.set("garden/live/lightStatus", lightStatus);
  json.set("garden/live/timestamp", timestamp);

  // Send to Firebase
  Serial.print("Sending to Firebase...");
  if (Firebase.updateNode(fbdo, "/", json)) {
    Serial.println("✅ Firebase Updated Successfully");
  } else {
    Serial.print("❌ Firebase Update Failed: ");
    Serial.println(fbdo.errorReason());
  }

  Serial.println(); // Empty line for readability

  // Wait before next reading
  delay(5000);
}
