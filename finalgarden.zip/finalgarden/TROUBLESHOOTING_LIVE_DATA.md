# 🔧 Why Live Data Isn't Showing - Troubleshooting Guide

## ❌ Problem: Dashboard Shows "Showing Demo Data"

You're sending data from ESP8266 but dashboard still shows demo data.

## 🔍 Debug Steps - Check Browser Console

### Step 1: Open Browser Console
1. **Right-click** anywhere on the page
2. **Select** "Inspect" or "Inspect Element"
3. **Click** "Console" tab

### Step 2: Look for These Messages

#### ✅ Expected Messages (Normal Operation)
```
🚀 Loading Firebase module...
✅ Firebase reference created successfully
🔥 Firebase initialized
🔥 Database URL: https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app
🔥 Path: garden/live
🔌 useGardenData effect triggered
🔌 dataRef: DatabaseReference {...}
📡 Subscribing to Firebase data...
📡 Firebase data received: { temperature: 24.5, ... }
📡 Snapshot exists: true
📡 Snapshot key: live
✅ Valid data received, keys: ["temperature", "humidity", ...]
📡 Callback received data: { temperature: 24.5, ... }
✅ Data updated in state, connected: true
📊 Garden data updated: { temperature: 24.5, ... }
📊 Is valid data: true
📊 Connected: true
```

#### ⚠️ Common Issues

**Issue 1: Firebase Path is Empty**
```
⚠️ Firebase path is empty - showing demo data
```
**Solution**: ESP8266 is not sending data to `/garden/live` path

**Issue 2: Permission Denied**
```
❌ Firebase data error: Error: Permission denied
Error code: PERMISSION_DENIED
```
**Solution**: Firebase database rules are blocking read access

**Issue 3: Data Ref is Null**
```
⚠️ dataRef is null, not subscribing
```
**Solution**: Firebase initialization failed

**Issue 4: Invalid Data Received**
```
📡 Firebase data received: null
📊 Is valid data: false
```
**Solution**: Data structure doesn't match expected format

## 🎯 Common Causes & Solutions

### Cause 1: Wrong Firebase Path

**Problem**: ESP8266 sending to different path than dashboard expects

**ESP8266 Might Be Using**:
```cpp
Firebase.setFloat(firebaseData, "/gardenData/live/temperature", sensorData.temperature);
// OR
Firebase.setJSON(firebaseData, "/sensor/data", json);
```

**Dashboard Expects**:
```cpp
Firebase.setJSON(firebaseData, "/garden/live", json);
```

**Solution**: Update ESP8266 to use `/garden/live`

### Cause 2: Firebase Database Rules

**Problem**: Database rules block read access

**Check Rules**:
1. Go to Firebase Console: https://console.firebase.google.com/
2. Select project: `rfid-aaruto`
3. Navigate to **Realtime Database**
4. Click **Rules** tab

**Current Rules (if restrictive)**:
```json
{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null"
  }
}
```

**Solution - Allow Public Access (for testing)**:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

**Better Solution (Allow reads only)**:
```json
{
  "rules": {
    ".read": true,
    ".write": false
  }
}
```

Click **Publish** after changing rules!

### Cause 3: Firebase URL Mismatch

**Problem**: ESP8266 using wrong Firebase URL

**Check ESP8266 Code**:
```cpp
#define FIREBASE_HOST "rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
```

**Must Match Dashboard Config**:
```typescript
databaseURL: "https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
```

**Solution**: Ensure exact same URL!

### Cause 4: Missing Data Fields

**Problem**: ESP8266 not sending all required fields

**Required Fields**:
- ✅ temperature (number)
- ✅ humidity (number)
- ✅ gasLevel (number)
- ✅ gasStatus (string)
- ✅ lightStatus (string)
- ✅ gardenLight (string)
- ✅ timestamp (number)

**ESP8266 Must Send**:
```cpp
FirebaseJson json;
json.add("temperature", 24.5);    // REQUIRED
json.add("humidity", 68);          // REQUIRED
json.add("gasLevel", 120);         // REQUIRED
json.add("gasStatus", "SAFE");     // REQUIRED
json.add("lightStatus", "DAY");     // REQUIRED
json.add("gardenLight", "ON");     // REQUIRED
json.add("timestamp", 1704148800000); // REQUIRED

Firebase.setJSON(firebaseData, "/garden/live", json);
```

### Cause 5: Data Type Mismatch

**Problem**: Sending wrong data types

**Incorrect**:
```cpp
json.add("temperature", "24.5");  // WRONG - should be number
json.add("gasStatus", 1);        // WRONG - should be string
```

**Correct**:
```cpp
json.add("temperature", 24.5);     // CORRECT - number
json.add("gasStatus", "SAFE");      // CORRECT - string
```

### Cause 6: ESP8266 Not Connected

**Problem**: ESP8266 not actually sending data

**Check Serial Monitor**:
1. Open Arduino IDE
2. Upload code to ESP8266
3. Open Serial Monitor (115200 baud)
4. Look for errors:

**Expected Output**:
```
WiFi connected!
IP address: 192.168.1.100
Firebase initialized!
Temperature sent successfully
Humidity sent successfully
Gas level sent successfully
Gas status sent successfully
Light status sent successfully
Garden light status sent successfully
Timestamp sent successfully
=== Firebase update complete ===
```

**If You See Errors**:
```
Connection failed
Firebase initialization failed!
Data failed to send
```
**Solution**: Check WiFi credentials and Firebase config

## ✅ How to Fix - Step by Step

### Step 1: Verify Firebase Database

1. **Go to Firebase Console**
   ```
   https://console.firebase.google.com/
   ```

2. **Select Project**: `rfid-aaruto`

3. **Navigate to Realtime Database**

4. **Check if data exists**:
   - Expand `garden` folder
   - Expand `live` folder
   - You should see all 7 fields

5. **If no data**: ESP8266 not sending
   - Check ESP8266 Serial Monitor
   - Verify WiFi connection
   - Verify Firebase credentials

6. **If data exists**: Dashboard should show it
   - Refresh browser page (F5)
   - Check browser console for errors

### Step 2: Update Firebase Rules

1. **Go to** Realtime Database → **Rules** tab

2. **Replace rules with**:
   ```json
   {
     "rules": {
       ".read": true,
       ".write": true
     }
   }
   ```

3. **Click "Publish"**

4. **Refresh** dashboard page

### Step 3: Verify ESP8266 Path

**Check ESP8266 Code**:
```cpp
// Find this line and verify it's EXACTLY this:
Firebase.setJSON(firebaseData, "/garden/live", json);
```

**Common Mistakes**:
```cpp
❌ Firebase.setJSON(firebaseData, "/gardenData/live", json);
❌ Firebase.setJSON(firebaseData, "/garden/live/data", json);
❌ Firebase.setJSON(firebaseData, "/sensor/data", json);
❌ Firebase.setJSON(firebaseData, "garden/live", json); // Missing leading slash
```

**Correct**:
```cpp
✅ Firebase.setJSON(firebaseData, "/garden/live", json);
```

### Step 4: Test with Manual Data

**Quick Test - Add Data Directly**:

1. Open Firebase Console → Realtime Database
2. Navigate to `garden/live`
3. Click **"+"** button next to `live`
4. Add this JSON:
   ```json
   {
     "temperature": 26.8,
     "humidity": 72,
     "gasLevel": 135,
     "gasStatus": "SAFE",
     "lightStatus": "DAY",
     "gardenLight": "ON",
     "timestamp": 1704148800000
   }
   ```
5. Click **"Save"**

6. **Go to Dashboard** - It should update instantly!
   - Demo banner should disappear
   - Real values should show

**If this works**: ESP8266 path or code issue
**If this doesn't work**: Firebase rules or config issue

### Step 5: Check Browser Console Errors

**Open Console** (F12) and look for:

**Firebase Errors**:
```
❌ Firebase data error: Error: Permission denied
→ Fix database rules

❌ Firebase data error: Error: network error
→ Check internet connection
```

**Firebase Warnings**:
```
⚠️ Firebase path is empty - showing demo data
→ ESP8266 not sending to correct path

⚠️ dataRef is null, not subscribing
→ Firebase initialization failed
```

## 📋 Quick Checklist

Before sending data from ESP8266, verify:

### Firebase Setup
- [ ] Database URL matches: `rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app`
- [ ] Database rules allow read access
- [ ] Path is exactly: `/garden/live`
- [ ] All fields present in Firebase Console

### ESP8266 Code
- [ ] Sending all 7 required fields
- [ ] Using correct path: `/garden/live`
- [ ] Data types correct (number for numbers, string for strings)
- [ ] timestamp is milliseconds since epoch
- [ ] Status values match exactly: "SAFE", "WARNING", "DANGER", "DAY", "NIGHT", "ON", "OFF"

### ESP8266 Connection
- [ ] WiFi connected successfully
- [ ] Firebase initialized successfully
- [ ] Serial Monitor shows "Data sent successfully"
- [ ] No errors in Serial Monitor

### Dashboard
- [ ] Browser console shows "Firebase initialized"
- [ ] Browser console shows "Subscribing to Firebase data"
- [ ] Browser console shows data received
- [ ] No errors in console

## 🚀 Most Common Fix

**90% of cases**: Wrong Firebase path or database rules

### Try This First:

1. **Go to Firebase Console** → Realtime Database → **Rules**
2. **Set to**:
   ```json
   {
     "rules": {
       ".read": true,
       ".write": true
     }
   }
   ```
3. **Click "Publish"**

4. **Refresh** dashboard page

5. **If still showing demo**: Check ESP8266 path is `/garden/live`

## 📞 Still Not Working?

### Collect This Information:

1. **Browser Console Messages**:
   - Copy all console messages (especially ones with 🔥, 📡, ❌, ⚠️)
   - Screenshot the console if possible

2. **ESP8266 Serial Monitor**:
   - What does it show?
   - Any errors?
   - Does it say "Data sent successfully"?

3. **Firebase Console**:
   - Do you see data in Realtime Database?
   - What path is it in?
   - Are the 7 fields present?

4. **Firebase Rules**:
   - What are your current rules?
   - Are they published?

## 📞 How to Get Help

### Post This Information:

```
✓ Browser console: [paste console messages here]
✓ ESP8266 Serial: [paste serial output here]
✓ Firebase Console: [screenshot or describe what you see]
✓ Firebase Rules: [paste current rules here]
✓ ESP8266 Path: [paste the Firebase.setJSON line]
```

## 💡 Pro Tips

1. **Always check browser console first** - It tells you exactly what's wrong
2. **Verify path with leading slash** - `/garden/live` not `garden/live`
3. **Test with manual data first** - Rules out Firebase issues
4. **Check rules are published** - Rules don't apply until published
5. **Verify data types** - Numbers as numbers, strings as strings

---

## ✅ Success Indicators

You'll know it's working when you see:

**In Browser Console**:
```
✅ Firebase reference created successfully
📡 Firebase data received: { temperature: 24.5, ... }
✅ Valid data received, keys: ["temperature", "humidity", ...]
✅ Data updated in state, connected: true
```

**In Dashboard**:
```
❌ Yellow "Showing Demo Data" banner: DISAPPEARED
✅ "Firebase Realtime Database" in System Information
✅ Real sensor values displayed
✅ Values update every time ESP8266 sends data
```

**Start debugging with the browser console - it will tell you exactly what's happening!** 🔍
