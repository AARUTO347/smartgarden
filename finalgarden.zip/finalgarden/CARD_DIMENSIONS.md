# 📐 Card Dimensions - Sensor Cards Dashboard

## Overview

This document shows all the current dimensions and sizing for the Smart Garden Dashboard sensor cards.

---

## 🎴 Card Container

### Card Component Structure
```tsx
<Card className={`backdrop-blur-xl bg-white/10 border-white/20 
  hover:bg-white/15 transition-all duration-300 
  hover:scale-105 hover:shadow-lg hover:shadow-green-500/10 
  ${isStatusCard ? bgColor : ''}`}>
  <CardContent className="p-6">
    {/* Card content */}
  </CardContent>
</Card>
```

### Card Dimensions

| Element | Tailwind Classes | Computed Size | Notes |
|---------|-----------------|---------------|-------|
| Card Padding | `p-6` | 24px (1.5rem) | Padding on all sides |
| Card Border | `border-white/20` | 1px solid with 20% opacity | Thin white border |
| Card Shadow | `hover:shadow-lg` | 0 1rem blur, 0.2rem offset | Large shadow on hover |
| Card Scale | `hover:scale-105` | 1.05x scale on hover | 5% larger on hover |
| Backdrop Blur | `backdrop-blur-xl` | 24px blur | Heavy background blur |

---

## 🎯 Icon Container

### Icon Container Dimensions

```tsx
<div className={`p-3 rounded-full ${color} bg-black/20 
  min-w-16 min-h-16 flex items-center justify-center`}>
  {icon}
</div>
```

### Icon Size Breakdown

| Element | Tailwind Classes | Computed Size | Notes |
|---------|-----------------|---------------|-------|
| Container Padding | `p-3` | 12px | Padding around icon |
| Container Width | `min-w-16` | 64px (4rem) | **MINIMUM width** |
| Container Height | `min-h-16` | 64px (4rem) | **MINIMUM height** |
| Border Radius | `rounded-full` | 50% (circle) | Circular container |
| Background | `bg-black/20` | 20% opacity black | Dark semi-transparent |

**Total Icon Container Size:**
- **Minimum Size**: 64px × 64px
- **With Content**: Scales larger if icon is bigger
- **Centered**: Icon perfectly centered in container

---

## 📝 Typography Hierarchy

### Title Text
```tsx
<h3 className="text-sm font-medium text-green-200/80">
  {title}
</h3>
```

| Property | Class | Size | Notes |
|----------|-------|------|-------|
| Font Size | `text-sm` | 14px | Small readable size |
| Font Weight | `font-medium` | 500 | Medium weight |
| Color | `text-green-200/80` | Light green | Green with 80% opacity |
| Margin | `space-y-4` | 16px | Vertical spacing from icon |

### Value Text (Big Number)
```tsx
<p className={`text-3xl font-bold ${color} transition-all duration-300`}>
  {value}
  <span className="text-lg ml-1 opacity-80">{unit}</span>
</p>
```

| Property | Class | Size | Notes |
|----------|-------|------|-------|
| Font Size | `text-3xl` | 30px | **LARGE** - Main display |
| Font Weight | `font-bold` | 700 | Bold for emphasis |
| Value | `{value}` | Variable | Actual sensor value |
| Unit | `text-lg` | 18px | Unit text (°C, %, AQI) |
| Unit Margin | `ml-1` | 4px left margin | Space between value and unit |
| Unit Opacity | `opacity-80` | 80% opacity | Unit is subtle |
| Color | `${color}` | Variable | Dynamic based on status |
| Transition | `transition-all duration-300` | Smooth 300ms transitions | Animates on changes |

### Description Text
```tsx
<div className="text-xs text-green-200/60">
  {description}
</div>
```

| Property | Class | Size | Notes |
|----------|-------|------|-------|
| Font Size | `text-xs` | 12px | **EXTRA SMALL** |
| Color | `text-green-200/60` | Light green | Very subtle text |
| Opacity | `60` | 60% opacity | Very light/dim |

---

## 📊 Card Layout & Spacing

### Content Container
```tsx
<div className="flex flex-col items-center text-center space-y-4">
  {/* Icon */}
  {/* Title */}
  {/* Value */}
  {/* Description */}
</div>
```

### Spacing Breakdown

| Element | Class | Computed Spacing | Notes |
|---------|-------|-----------------|-------|
| Vertical Gap | `space-y-4` | 16px | Space between each element |
| Content Padding | `p-6` (CardContent) | 24px | Padding around all content |
| Icon Container Margin | 0 | 0 | No extra margin |

**Total Internal Spacing:**
- Icon to Title: 16px
- Title to Value: 16px
- Value to Description: 16px
- Total Content Height: ~200-250px

---

## 📱 Responsive Grid Layout

### Grid Configuration
```tsx
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
  {/* Cards */}
</div>
```

### Grid Breakdown

| Screen Size | Grid Columns | Gap | Card Width |
|-------------|--------------|-----|------------|
| **Mobile** (< 640px) | `grid-cols-1` | 24px | 100% width (1 card per row) |
| **Tablet** (640px - 1024px) | `grid-cols-2` | 24px | 2 cards per row |
| **Desktop** (1024px - 1280px) | `grid-cols-3` | 24px | 3 cards per row |
| **Large** (1280px - 1536px) | `grid-cols-4` | 24px | 4 cards per row |
| **XL** (> 1536px) | `grid-cols-6` | 24px | 6 cards per row |

**Card Width Calculation (approximate):**
- Mobile: 100% - 48px padding
- Tablet: 50% - 48px padding
- Desktop: 33.33% - 48px padding
- Large: 25% - 48px padding
- XL: 16.66% - 48px padding

---

## 📐 Complete Card Dimensions (Approximate)

### Mobile (< 640px)
```
┌────────────────────┐
│     Container      │
│   100% - 48px     │  ~552px width
│                   │
│   ┌─────────────┐   │
│   │    Icon     │   │
│   │ 64 × 64    │   │  min-w-16 × min-h-16
│   │  (p-3)      │   │
│   └─────────────┘   │
│                   │
│     Title        │   text-sm (14px)
│                   │
│   64 (Value)    │   text-3xl (30px)
│                   │
│     Description   │   text-xs (12px)
│                   │
└─────────────────────┘
```

**Estimated Card Size:**
- Width: ~552px (100% - container padding)
- Height: ~350px (icon + spacing + text)

### Tablet (640px - 1024px)
```
┌────────────┬────────────┐
│   Card 1    │   Card 2     │
│  ~457px     │   ~457px     │
│  (50% - gap)│   (50% - gap)│
└────────────┴────────────┘

Each card contains:
- Icon: 64×64px
- Title: 14px
- Value: 30px
- Unit: 18px
- Description: 12px
- Spacing: 16px × 3
**Estimated Card Height:** ~350px

### Desktop (1024px+)
```
┌─────────┬─────────┬─────────┐
│ Card 1  │ Card 2  │ Card 3  │
└─────────┴─────────┴─────────┘

Each card: ~333px width
**Estimated Card Height:** ~350px

### XL Screens (1536px+)
```
┌───────┬───────┬───────┬───────┬───────┐
│ Card 1│ Card 2│ Card 3│ Card 4│ Card 5│ Card 6│
└───────┴───────┴───────┴───────┴───────┴───────┘

Each card: ~256px width
**Estimated Card Height:** ~350px

---

## 🎨 Status Badge (for status cards)

### Badge Configuration
```tsx
{isStatusCard && (
  <Badge className={`${color} ${bgColor} border-0`}>
    Active
  </Badge>
)}
```

### Badge Dimensions

| Property | Computed Size | Notes |
|----------|---------------|-------|
| Padding | Default | Badge default padding |
| Border | `border-0` | No border |
| Corner Radius | Default | Rounded corners |
| Text | "Active" | Small text |

---

## 🌙 Day/Night Icon (in Light Status Card)

### Icon Sizing
```tsx
<SensorCard
  icon={displayData.lightStatus === 'DAY' ? <Sun className="w-8 h-8" /> : <Moon className="w-8 h-8" />}
  ...
/>
```

| Property | Class | Size |
|----------|-------|------|
| Icon Width | `w-8` | 32px |
| Icon Height | `h-8` | 32px |
| Size Type | Lucide icon | Responsive SVG |

---

## 💡 Lightbulb Icon (in Garden Light Card)

### Icon Sizing
```tsx
<SensorCard
  icon={<Lightbulb className="w-8 h-8" />}
  ...
/>
```

| Property | Class | Size |
|----------|-------|------|
| Icon Width | `w-8` | 32px |
| Icon Height | `h-8` | 32px |

---

## 📏 Card Content Layout

### Vertical Layout (Flex Column)
```tsx
<div className="flex flex-col items-center text-center space-y-4">
  {/* All content centered */}
</div>
```

### Content Order (Top to Bottom)
1. **Icon** (64×64px container)
2. **Title** (text-sm, 14px)
3. **Value** + **Unit** (text-3xl + text-lg, 30px + 18px)
4. **Description** (text-xs, 12px)

### Spacing Distribution
- Icon → Title: 16px
- Title → Value: 16px
- Value → Description: 16px
- **Total vertical spacing:** 48px

---

## 🎯 Hover Effects

### Card Hover State
```tsx
className={`...hover:scale-105 hover:shadow-lg hover:shadow-green-500/10...`}
```

| Effect | Value | Description |
|---------|-------|-------------|
| Scale | `1.05` | 5% larger on hover |
| Shadow | `lg` | Large shadow (0 1rem blur) |
| Shadow Color | `green-500/10` | Green with 10% opacity |
| Duration | `300` | 300ms transition time |

### Value Transition
```tsx
className={`text-3xl font-bold ${color} transition-all duration-300`}
```
- All values animate smoothly when they change
- 300ms transition duration
- Color changes animate smoothly

---

## 📱 Responsive Breakpoints

### Tailwind Default Breakpoints
| Breakpoint | Screen Width | Grid Layout | Card Width |
|------------|--------------|-------------|------------|
| **sm** | 640px | 2 columns | ~457px |
| **lg** | 1024px | 3 columns | ~333px |
| **xl** | 1280px | 6 columns | ~256px |

### Container Width (with 24px padding)
| Screen Size | Available Width | Notes |
|------------|----------------|-------|
| Mobile (375px) | ~327px per card | Single column |
| Tablet (768px) | ~360px per card | Two columns |
| Desktop (1280px) | ~405px per card | Three columns |

---

## 🔍 Accessibility Considerations

### Minimum Touch Targets
| Element | Size | Status |
|---------|------|--------|
| **Icon Container** | 64×64px | ✅ Meets 44px minimum |
| **Card** | ~350×250px+ | ✅ Large touch target |
| **Buttons** | Standard size | ✅ Proper touch targets |

### Readability
| Element | Font Size | Contrast | Status |
|---------|---------|---------|-------|
| Value | 30px | High contrast | ✅ Good readability |
| Title | 14px | Medium contrast | ✅ Readable |
| Description | 12px | Low contrast | ✅ Supplementary only |

---

## 🎨 Color Dimensions

### Status Colors
| Status | Color Class | Use |
|--------|-------------|------|
| Good | `text-green-500` | AQI: 0-50 |
| Satisfactory | `text-yellow-500` | AQI: 51-100 |
| Moderate | `text-yellow-500` | AQI: 101-200 |
| Poor | `text-orange-500` | AQI: 201-300 |
| Very Poor | `text-red-400` | AQI: 301-400 |
| Severe | `text-red-600` | AQI: 401-500 |
| Night | `text-blue-400` | Light status |
| Day | `text-yellow-500` | Light status |

### Background Colors
| Status | BG Class | Use |
|--------|----------|------|
| Good | `bg-green-500/20` | Green 20% opacity |
| Warning | `bg-yellow-500/20` | Yellow 20% opacity |
| Danger | `bg-red-500/20` | Red 20% opacity |
| Night | `bg-purple-500/10` | Purple 10% opacity |

---

## 📐 Total Card Dimensions Summary

### Mobile Portrait (375px × 667px)
```
┌────────────────────┐
│                    │
│       Icon          │ 64×64px
│                    │
│       Title         │ 14px
│                    │
│      64 AQI         │ 30px
│                    │
│      Description    │ 12px
│                    │
└────────────────────┘
```
**Card Size: ~552px width × ~350px height**

### Tablet Portrait (768px × 1024px)
```
┌────────────┬────────────┐
│    Icon    │    Icon    │
│  64×64     │  64×64     │
│   Title     │   Title     │
│    Value    │   Value     │
│ 64 AQI     │  64 AQI     │
│            │            │
└────────────┴────────────┘
```
**Card Size: ~457px width × ~350px height**

### Desktop (1920px × 1080px)
```
┌─────────┬─────────┬─────────┐
│ Icon    │ Value │ Icon    │ Value │
│64×64    │ 64 AQI│ 64×64   │ 64 AQI│ 64×64   │
│         │       │        │       │        │
└─────────┴─────────┴─────────┴─────────┘
```
**Card Size: ~333px width × ~350px height**

---

## 🎯 Icon Container Fixed Dimensions

### What Was Fixed
**Before:** Icon had no minimum size, could appear too small
**After:** Icon container has `min-w-16 min-h-16`

### Icon Container Specs
```tsx
<div className="p-3 rounded-full bg-black/20 min-w-16 min-h-16 
  flex items-center justify-center">
  {icon}
</div>
```

| Property | Value | Calculation |
|----------|-------|------------|
| Padding | 12px | `p-3` × 4 sides |
| Min Width | 64px | `min-w-16` = 4rem |
| Min Height | 64px | `min-h-16` = 4rem |
| Border Radius | 50% | `rounded-full` = circle |
| Background | Black 20% | `bg-black/20` |
| Flex Direction | Column | `flex-col` |
| Alignment | Center | `items-center justify-center` |
| **Total Icon Space**: 64px × 64px (minimum) |

---

## 📊 All 6 Cards Layout (Large Screens)

```
┌─────────────┬─────────────┬─────────────┬─────────────┬─────────────┬─────────────┐
│ Temperature │ Humidity  │ Light Status│   AQI Status│ Garden Light│   System Info│
│             │             │             │             │             │
│    Icon     │    Icon    │    Icon      │   Icon      │     Icon     │   Title/Icon │
│  64×64     │  64×64     │  64×64      │  64×64      │  64×64      │             │
│             │             │             │             │             │             │
│   Title      │   Title     │   Title      │   Title      │   Title      │   More Info  │
│   14px       │  14px      │  14px      │  14px      │  14px      │             │
│             │             │             │             │             │             │
│  Value      │  64.5%     │  68.0%      │  126 AQI    │    ON/OFF     │   -          │
│   30px       │  30px      │  30px      │  30px      │  30px      │             │
│             │             │             │             │             │             │
│ Description │    Day/Night │  AQI Status  │  Garden Light │             │             │
│   12px       │   12px      │   12px      │  12px      │  12px      │             │
│             │             │             │             │             │             │
└─────────────┴─────────────┴─────────────┴─────────────┴─────────────┴─────────────┘
```

---

## ✅ Summary

### Icon Container
- **Fixed Size**: 64×64px minimum
- **Centered**: Perfectly centered
- **Proper Spacing**: Covers empty space

### Card Dimensions
- **Mobile**: ~552×350px (1 column)
- **Tablet**: ~457×350px (2 columns)
- **Desktop**: ~333×350px (3 columns)
- **Large**: ~256×350px (6 columns)

### Typography Hierarchy
- **Title**: 14px (text-sm)
- **Value**: 30px (text-3xl)
- **Unit**: 18px (text-lg)
- **Description**: 12px (text-xs)

### Spacing
- **Icon to Title**: 16px
- **Title to Value**: 16px
- **Value to Description**: 16px
- **Total Vertical**: 48px
- **Grid Gap**: 24px

**All cards have consistent, well-proportioned dimensions!** 📏
