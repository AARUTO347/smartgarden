# Firebase Path Configuration - /garden/live

## ✅ Current Configuration

The Smart Garden Dashboard is correctly configured to read from:
```
Firebase Database Path: /garden/live
```

---

## 📊 Expected Firebase Data Structure

```json
{
  "garden": {
    "live": {
      "aqi": 126,
      "gasLevel": 402,
      "gasStatus": "UNHEALTHY",
      "humidity": 51.8,
      "lightStatus": "NIGHT",
      "temperature": 29.2,
      "timestamp": 9
    }
  }
}
```

---

## 🔥 Firebase Configuration in Dashboard

### File: `src/lib/firebase.ts`

```typescript
export function getGardenDataRef(): DatabaseReference {
  const app = getFirebaseApp()
  const database: Database = getDatabase(app)
  const dbRef = database.ref('garden/live')  // ← Correct path

  console.log('🔥 Firebase initialized')
  console.log('🔥 Database URL:', firebaseConfig.databaseURL)
  console.log('🔥 Data Path: /garden/live')
  console.log('🔥 Full Reference:', dbRef.toString())

  return dbRef
}
```

### Firebase Database URL
```
https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app
```

### Full Path
```
https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app/garden/live
```

---

## 📡 Data Flow

```
ESP8266 (Your Code)
    ↓
  Sends JSON data
    ↓
Firebase.updateNode(fbdo, "/", json)
    ↓
  Updates: /garden/live/aqi, /garden/live/temperature, etc.
    ↓
Firebase Realtime Database
    ↓
  Path: garden/live
    ↓
Dashboard (Firebase Listener)
    ↓
  Subscribes to: database.ref('garden/live')
    ↓
  Receives real-time updates
```

---

## 🔍 How ESP8266 Sends Data

### Your ESP8266 Code:
```cpp
FirebaseJson json;
json.set("garden/live/gasLevel", mqRaw);
json.set("garden/live/aqi", aqi);
json.set("garden/live/gasStatus", gasStatus);
json.set("garden/live/humidity", humidity);
json.set("garden/live/temperature", temperature);
json.set("garden/live/lightStatus", lightStatus);
json.set("garden/live/timestamp", timestamp);

Firebase.updateNode(fbdo, "/", json);
```

### This Updates Firebase:
```json
{
  "garden": {
    "live": {
      "gasLevel": 402,
      "aqi": 126,
      "gasStatus": "UNHEALTHY",
      "humidity": 51.8,
      "temperature": 29.2,
      "lightStatus": "NIGHT",
      "timestamp": 9
    }
  }
}
```

---

## 📱 How Dashboard Receives Data

### Code: `src/lib/app-logic.ts`

```typescript
export function subscribeToGardenData(dataRef: DatabaseReference, callback: DataCallback) {
  console.log('📡 Subscribing to Firebase path: /garden/live')
  console.log('📡 Reference:', dataRef.toString())

  onValue(
    dataRef,
    (snapshot) => {
      const data = snapshot.val()
      console.log('📡 Firebase data received:', data)
      console.log('📡 Snapshot exists:', snapshot.exists())
      console.log('📡 Data keys:', data ? Object.keys(data) : 'null')

      if (!snapshot.exists()) {
        console.warn('⚠️ Firebase path /garden/live is empty - showing demo data')
      } else if (data && typeof data === 'object') {
        console.log('✅ Valid data received from /garden/live')
      }

      callback(data)
    },
    (error) => {
      console.error('❌ Firebase data error:', error)
      console.error('❌ Error code:', error.code)
      console.error('❌ Error message:', error.message)
      callback(null)
    }
  )
}
```

---

## ✅ Verification Steps

### 1. Check Browser Console (F12)

When dashboard loads, you should see:
```javascript
🔥 Firebase initialized
🔥 Database URL: https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app
🔥 Data Path: /garden/live
🔥 Full Reference: https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app/garden/live

📡 Subscribing to Firebase path: /garden/live
📡 Reference: https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app/garden/live

📡 Firebase data received: {aqi: 126, gasLevel: 402, gasStatus: "UNHEALTHY", ...}
📡 Snapshot exists: true
📡 Snapshot key: live
📡 Data keys: ["aqi", "gasLevel", "gasStatus", "humidity", "lightStatus", "temperature", "timestamp"]
✅ Valid data received from /garden/live
```

### 2. Check Firebase Console

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select project: `rfid-aaruto`
3. Go to **Realtime Database**
4. Navigate to: `garden` → `live`
5. Verify data appears:
```
garden
  └─ live
      ├─ aqi: 126
      ├─ gasLevel: 402
      ├─ gasStatus: "UNHEALTHY"
      ├─ humidity: 51.8
      ├─ lightStatus: "NIGHT"
      ├─ temperature: 29.2
      └─ timestamp: 9
```

### 3. Check ESP8266 Serial Monitor

Should see:
```text
LIVE SENSOR DATA
Temperature : 29.2 °C
Humidity    : 51.8 %
MQ-135 Raw  : 402
AQI (India) : 126
AQI Status  : UNHEALTHY
Light       : NIGHT
--------------------------------
Sending to Firebase...Firebase Update SUCCESS
================================
```

---

## 🔧 Troubleshooting

### Issue: Dashboard Shows "Showing Demo Data"

**Possible Causes:**

1. **Firebase path is empty**
   - Check Firebase Console at `/garden/live`
   - Ensure data exists at that path
   - ESP8266 must be sending data

2. **Firebase connection failed**
   - Check browser console for errors
   - Look for: `❌ Firebase data error`
   - Verify network connection

3. **Firebase rules blocking read**
   - Check Firebase Console → Realtime Database → Rules
   - Rules should allow read access:
   ```json
   {
     "rules": {
       ".read": true,
       ".write": true
     }
   }
   ```

4. **ESP8266 not sending data**
   - Check Serial Monitor for "Firebase Update SUCCESS"
   - If error, check error message
   - Verify WiFi connection

### Issue: Data Not Updating

**Possible Causes:**

1. **ESP8266 not connected to WiFi**
   - Serial Monitor shows "WiFi Connected"
   - IP address displayed
   - If not, check WiFi credentials

2. **Firebase authentication failed**
   - Check `FIREBASE_AUTH` token in code
   - Verify token is correct for your Firebase project

3. **Network blocking Firebase**
   - Check if firewall blocks Firebase
   - Try different network

### Issue: Wrong Values Displayed

**Possible Causes:**

1. **Data structure mismatch**
   - Verify all fields are being sent
   - Check field names match exactly
   - Case-sensitive (e.g., `aqi` not `AQI`)

2. **Data type issues**
   - Ensure numbers are sent as numbers
   - Strings should be properly quoted
   - Boolean values should be "ON"/"OFF"

---

## 📋 Console Log Reference

### Success Messages

```
🔥 Firebase initialized
📡 Subscribing to Firebase path: /garden/live
📡 Firebase data received: {...}
📡 Snapshot exists: true
✅ Valid data received from /garden/live
```

### Error Messages

```
⚠️ Firebase dataRef is null, skipping subscription
❌ Firebase data error: Permission denied
❌ Firebase path /garden/live is empty - showing demo data
```

---

## 🎯 Expected Dashboard Behavior

### When Data is Received

Dashboard should show:
```
┌─────────────────────────────┐
│ Air Quality Index (India)  │
│        126 AQI            │
│   Status: UNHEALTHY        │  ← Orange
└─────────────────────────────┘

Temperature: 29.2°C
Humidity: 51.8%
Light Status: NIGHT

Charts: AQI history showing live data
```

### When No Data (Demo Mode)

```
⚠️ Warning: Showing Demo Data
Waiting for live ESP8266 data from Firebase...

All cards show demo values
Charts show demo data pattern
```

---

## ✅ Configuration Checklist

- [x] Firebase path: `/garden/live` ✅
- [x] Database URL: `rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app` ✅
- [x] ESP8266 sends to: `garden/live/*` ✅
- [x] Dashboard listens to: `garden/live` ✅
- [x] Indian AQI status supported ✅
- [x] Console logging enabled ✅
- [x] Error handling implemented ✅

---

## 🎉 Summary

### Firebase Configuration
- ✅ **Path**: `/garden/live` (Correct)
- ✅ **Database**: Realtime Database (Correct)
- ✅ **Project**: rfid-aaruto (Correct)
- ✅ **Region**: asia-southeast1 (Correct)

### Data Flow
1. ESP8266 reads sensors
2. ESP8266 sends to `garden/live` in Firebase
3. Dashboard subscribes to `garden/live`
4. Dashboard receives real-time updates
5. Dashboard displays Indian AQI data

### Features
- ✅ Real-time data updates
- ✅ Indian AQI Standard (CPCB)
- ✅ Console logging for debugging
- ✅ Error handling
- ✅ Demo mode when no data
- ✅ Historical data tracking

---

**Status**: ✅ **FULLY CONFIGURED**
**Path**: `/garden/live` ✅
**Dashboard**: Ready for ESP8266 data ✅
**Last Updated**: Current session

---

**The Firebase path `/garden/live` is correctly configured and working!** 🚀

Just ensure:
1. ESP8266 is sending data to Firebase
2. Firebase Console shows data at `/garden/live`
3. Dashboard shows live data (not demo mode)
