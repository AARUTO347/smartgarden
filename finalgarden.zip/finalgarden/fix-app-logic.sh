#!/usr/bin/env node

// Fix script to add device_id to GardenData interface
const fs = require('fs');
const path = '/home/z/my-project/src/lib/app-logic.ts';

console.log('🔧 Fixing app-logic.ts to add device_id to GardenData interface...');

// Read current file
let content = fs.readFileSync(path, 'utf-8');

// Add device_id to GardenData interface
const gardenDataInterfaceMatch = /export interface GardenData {[\s\S\n]*temperature:[\s\S\n]*humidity:[\s\S\n]*gasLevel:[\s\S\n]*gasAQI:[\s\S\n]*aqi:[\s\S\n]*gasStatus:[\s\S\n]*lightStatus:[\s\S\n]*gardenLight:[\s\S\n]*device_id:[\s\S\n]*timestamp:[\s\S\n]}/;

// Check if device_id is already in interface
if (gardenDataInterfaceMatch.test(content)) {
  console.log('✅ device_id already found in GardenData interface');
} else {
  console.log('❌ device_id not found in GardenData interface');
  console.log('🔧 Adding device_id field...');
  
  // Add device_id after timestamp (at the end of the interface)
  const interfaceEndRegex = /export interface GardenData \{([^}]*)*\n/gasStatus:/g\n*timestamp:/g\n/gard
  const lines = content.split('\n');
  let newContent = [];
  let foundInterface = false;
  let foundTimestamp = false;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    if (!foundInterface && line.includes('export interface GardenData')) {
      foundInterface = true;
    continue;
    }
    
    if (foundInterface && line.includes('gasStatus')) {
      newContent.push(line + '\n');
    } else if (foundInterface && line.includes('timestamp')) {
      foundTimestamp = true;
      newContent.push('  device_id?: string     // NEW: Device ID from Firebase\n');
      foundTimestamp = false;
    } else if (foundTimestamp) {
      newContent.push(line + '\n');
    }
  }
  
  // Write back to file
  fs.writeFileSync(path, newContent);
  console.log('✅ app-logic.ts updated successfully');
}

console.log('🔧 Done! device_id added to GardenData interface');
