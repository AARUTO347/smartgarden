# ESP8266 Firebase Data Structure (AQI Version)

## Firebase Path
```
garden/live
```

## JSON Data Structure

```json
{
  "temperature": 24.5,
  "humidity": 68,
  "gasPPM": 150,
  "gasLevel": 150,
  "gasAQI": 75,
  "gasStatus": "GOOD",
  "lightStatus": "DAY",
  "gardenLight": "ON",
  "timestamp": 1704148800000
}
```

## Field Descriptions

| Field | Type | Range/Values | Description |
|-------|------|--------------|-------------|
| `temperature` | float | -40 to 85°C | Temperature in Celsius |
| `humidity` | float | 0 to 100% | Relative humidity percentage |
| `gasPPM` | float | 0 to 1000 | Raw gas sensor PPM value |
| `gasLevel` | integer | 0 to 1000 | Gas PPM level (for backward compatibility) |
| `gasAQI` | integer | 0 to 500 | **Air Quality Index** - PRIMARY FIELD |
| `gasStatus` | string | "GOOD", "MODERATE", "POOR", "DANGEROUS" | Air quality status based on AQI |
| `lightStatus` | string | "DAY", "NIGHT" | Day/Night cycle status |
| `gardenLight` | string | "ON", "OFF" | Garden light control status |
| `timestamp` | number | Unix timestamp | Milliseconds since epoch |

## Status Logic

### AQI Calculation (gasAQI)
```cpp
// Calculate AQI from raw PPM (0-500 scale)
float rawPPM = mq135_sensor.getPPM();
sensorData.gasAQI = map(constrain(rawPPM, 0, 1000), 0, 1000, 0, 500);
sensorData.gasPPM = rawPPM;
```

### Gas Status (gasStatus) - Based on AQI
```cpp
// Determine gas status based on AQI thresholds
if (sensorData.gasAQI < 50) {
  sensorData.gasStatus = "GOOD";
} else if (sensorData.gasAQI < 100) {
  sensorData.gasStatus = "MODERATE";
} else if (sensorData.gasAQI < 200) {
  sensorData.gasStatus = "POOR";
} else {
  sensorData.gasStatus = "DANGEROUS";
}
```

### Light Status (lightStatus)
```cpp
// Based on light sensor reading (0-1023)
if (lightSensorValue > 512) {
  lightStatus = "DAY";
} else {
  lightStatus = "NIGHT";
}
```

### Garden Light (gardenLight)
```cpp
// Can be controlled automatically or manually
// Example: Turn ON when lightStatus is "NIGHT"
if (lightStatus == "NIGHT") {
  gardenLight = "ON";
} else {
  gardenLight = "OFF";
}
```

## Example Data Sets

### Example 1: Good Air Quality - Normal Day Conditions
```json
{
  "temperature": 26.5,
  "humidity": 65,
  "gasPPM": 95,
  "gasLevel": 95,
  "gasAQI": 47,
  "gasStatus": "GOOD",
  "lightStatus": "DAY",
  "gardenLight": "OFF",
  "timestamp": 1704148800000
}
```

### Example 2: Moderate Air Quality - Night with Garden Light ON
```json
{
  "temperature": 22.3,
  "humidity": 78,
  "gasPPM": 165,
  "gasLevel": 165,
  "gasAQI": 82,
  "gasStatus": "MODERATE",
  "lightStatus": "NIGHT",
  "gardenLight": "ON",
  "timestamp": 1704152400000
}
```

### Example 3: Poor Air Quality
```json
{
  "temperature": 25.8,
  "humidity": 70,
  "gasPPM": 365,
  "gasLevel": 365,
  "gasAQI": 182,
  "gasStatus": "POOR",
  "lightStatus": "DAY",
  "gardenLight": "OFF",
  "timestamp": 1704156000000
}
```

### Example 4: Dangerous Air Quality
```json
{
  "temperature": 27.2,
  "humidity": 62,
  "gasPPM": 685,
  "gasLevel": 685,
  "gasAQI": 342,
  "gasStatus": "DANGEROUS",
  "lightStatus": "DAY",
  "gardenLight": "OFF",
  "timestamp": 1704159600000
}
```

### Example 5: Excellent Air Quality - High Humidity Night
```json
{
  "temperature": 21.5,
  "humidity": 88,
  "gasPPM": 35,
  "gasLevel": 35,
  "gasAQI": 17,
  "gasStatus": "GOOD",
  "lightStatus": "NIGHT",
  "gardenLight": "ON",
  "timestamp": 1704163200000
}
```

## Arduino/C++ Data Structure

```cpp
struct SensorData {
  float temperature;    // °C
  float humidity;       // % (0-100)
  float gasPPM;         // Raw PPM value
  int gasLevel;         // PPM integer (for compatibility)
  int gasAQI;           // Air Quality Index (0-500)
  String gasStatus;     // "GOOD", "MODERATE", "POOR", "DANGEROUS"
  String lightStatus;   // "DAY", "NIGHT"
  String gardenLight;   // "ON", "OFF"
  unsigned long timestamp;  // Milliseconds since epoch
};
```

## Firebase Update Example (Arduino)

```cpp
// Send all data as a JSON object with AQI
FirebaseJson json;
json.add("temperature", sensorData.temperature);
json.add("humidity", sensorData.humidity);
json.add("gasPPM", sensorData.gasPPM);
json.add("gasLevel", sensorData.gasLevel);
json.add("gasAQI", sensorData.gasAQI);
json.add("gasStatus", sensorData.gasStatus);
json.add("lightStatus", sensorData.lightStatus);
json.add("gardenLight", sensorData.gardenLight);
json.add("timestamp", sensorData.timestamp);

Firebase.setJSON(firebaseData, "/garden/live", json);
```

## AQI Reference Table

| AQI Range | Status | Color | Health Message |
|-----------|--------|-------|----------------|
| 0-50 | GOOD | Green | Air quality is satisfactory |
| 51-100 | MODERATE | Yellow | Acceptable quality for most people |
| 101-200 | POOR | Orange | Sensitive groups may be affected |
| 201-500 | DANGEROUS | Red | Everyone may experience health effects |

## Testing with Firebase Console

1. Go to Firebase Console
2. Navigate to Realtime Database
3. Find the `garden/live` path
4. You can manually add/test data using the JSON structure above

## Notes

- All numeric values should be valid (no NaN or Infinity)
- Timestamp must be in milliseconds for JavaScript compatibility
- String values must exactly match the allowed values
- Update frequency: Recommended every 5 seconds (5000ms)
- Path in Firebase: `rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app/garden/live`
