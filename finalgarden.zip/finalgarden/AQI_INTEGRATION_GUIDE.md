# AQI (Air Quality Index) Integration Guide

## Overview

The Smart Garden Dashboard now supports **AQI (Air Quality Index)** values instead of raw PPM data. This provides a more standardized and understandable metric for air quality monitoring.

## What Changed

### Dashboard Updates
1. **Gas Status Card → AQI Status Card**
   - Card title changed from "Gas Status" to "Air Quality Index"
   - Displays AQI value prominently (0-500 scale)
   - Unit changed from "PPM" to "AQI"
   - Shows air quality status in description

2. **New AQI Status Types**
   - **GOOD** (0-50): Green - Air quality is satisfactory
   - **MODERATE** (51-100): Yellow - Air quality is acceptable
   - **POOR** (101-200): Orange - Members of sensitive groups may experience health effects
   - **DANGEROUS** (201-500): Red - Health alert: everyone may experience more serious health effects

3. **Raw Data View**
   - Changed "Gas Level (PPM)" to "AQI"
   - Changed "Gas Status" to "Air Quality Status"
   - Updated badge colors to match new status types

4. **Charts**
   - Bar chart now displays "AQI Level" instead of "PPM"
   - Demo data uses AQI values (80-180 range)
   - Status colors updated for all 4 AQI categories

5. **CSV Export**
   - Column headers changed to "AQI" and "Air Quality Status"
   - Exports AQI values instead of raw PPM

## Data Structure

The dashboard now accepts the following fields:

```typescript
interface GardenData {
  temperature?: number        // Celsius
  humidity?: number          // Percentage (0-100)
  lightStatus?: 'DAY' | 'NIGHT'
  gardenLight?: 'ON' | 'OFF'
  gasLevel?: number          // Raw PPM (for backward compatibility)
  gasPPM?: number           // PPM value from sensor
  gasAQI?: number           // AQI value (0-500) - PRIMARY FIELD
  gasStatus?: 'GOOD' | 'MODERATE' | 'POOR' | 'DANGEROUS'
  timestamp?: number        // Milliseconds since epoch
}
```

## ESP8266 Data Sending

Your ESP8266 code should send AQI values to Firebase. Here's the expected data format:

```json
{
  "temperature": 24.5,
  "humidity": 68,
  "gasPPM": 150,
  "gasLevel": 150,
  "gasAQI": 75,
  "gasStatus": "GOOD",
  "lightStatus": "DAY",
  "gardenLight": "ON",
  "timestamp": 1234567890000
}
```

### Important Fields for AQI:
- **gasAQI**: The calculated AQI value (0-500)
- **gasStatus**: One of "GOOD", "MODERATE", "POOR", "DANGEROUS"
- **gasPPM**: Raw PPM from MQ135 sensor (optional, for reference)
- **gasLevel**: Legacy field (optional, for backward compatibility)

## AQI Calculation

The ESP8266 should calculate AQI from raw PPM using this formula:

```cpp
// AQI calculation (0-500 scale based on PPM)
sensorData.gasAQI = map(constrain(rawPPM, 0, 1000), 0, 1000, 0, 500);

// Determine gas status based on AQI
void determineGasStatus() {
  if (sensorData.gasAQI < 50) {
    sensorData.gasStatus = "GOOD";
  } else if (sensorData.gasAQI < 100) {
    sensorData.gasStatus = "MODERATE";
  } else if (sensorData.gasAQI < 200) {
    sensorData.gasStatus = "POOR";
  } else {
    sensorData.gasStatus = "DANGEROUS";
  }
}
```

## AQI Thresholds and Colors

| AQI Range | Status | Color | Hex Code |
|-----------|--------|-------|----------|
| 0-50 | GOOD | Green | #22c55e |
| 51-100 | MODERATE | Yellow | #eab308 |
| 101-200 | POOR | Orange | #f97316 |
| 201-500 | DANGEROUS | Red | #ef4444 |

## Backward Compatibility

The dashboard maintains backward compatibility:
- If `gasAQI` is not provided, it falls back to `gasLevel`
- Supports both old status types (SAFE, WARNING, DANGER) and new types (GOOD, MODERATE, POOR, DANGEROUS)
- Automatically maps old status colors to new ones

## Firebase Data Path

Data should be sent to: `/garden/live`

## ESP8266 Example Code

```cpp
void sendToFirebase() {
  FirebaseJson json;

  // Send AQI as primary air quality metric
  json.add("gasAQI", sensorData.gasAQI);
  json.add("gasStatus", sensorData.gasStatus);
  json.add("gasPPM", sensorData.gasPPM);  // Optional raw value
  json.add("gasLevel", (int)sensorData.gasPPM);  // For compatibility
  json.add("temperature", sensorData.temperature);
  json.add("humidity", sensorData.humidity);
  json.add("lightStatus", sensorData.lightStatus);
  json.add("gardenLight", sensorData.gardenLight);
  json.add("timestamp", sensorData.timestamp);

  if (Firebase.setJSON(firebaseData, "/garden/live", json)) {
    Serial.println("Data sent successfully!");
  } else {
    Serial.println("Failed to send data!");
  }
}
```

## Testing with Demo Data

When no live data is available, the dashboard shows demo data:
- AQI: 75 (GOOD status)
- Temperature: 24.5°C
- Humidity: 68%
- Light Status: DAY
- Garden Light: ON

The demo data automatically cycles through different AQI levels to showcase the status colors.

## Benefits of Using AQI

1. **Standardized Scale**: AQI provides a universal 0-500 scale
2. **Easy Understanding**: Clear status categories (GOOD, MODERATE, POOR, DANGEROUS)
3. **Health-Based**: Designed around health impact thresholds
4. **Professional**: Matches international air quality standards
5. **Actionable**: Clear visual indicators help users take action

## Troubleshooting

### AQI Not Displaying
- Verify ESP8266 is sending `gasAQI` field
- Check Firebase console for data structure
- Open browser console to see received data

### Status Not Updating
- Ensure `gasStatus` is one of: "GOOD", "MODERATE", "POOR", "DANGEROUS"
- Check case sensitivity (must be uppercase)
- Verify status calculation logic in ESP8266

### Wrong Colors Displaying
- Status field must match exact values
- Check gasStatus is properly calculated based on AQI thresholds

## Support

For issues or questions:
1. Check the Firebase console at: `/garden/live` path
2. Review browser console logs
3. Verify ESP8266 serial monitor output
4. Ensure all required fields are being sent

---

**Version**: 2.0
**Last Updated**: 2024
**Firebase Path**: `/garden/live`
