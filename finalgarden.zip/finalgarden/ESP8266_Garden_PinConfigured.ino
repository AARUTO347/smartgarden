/*
 * ESP8266 Smart Garden Firebase Sender - Pin-Specific Version
 *
 * PIN CONFIGURATION:
 * - A0: MQ135 Gas Sensor
 * - A1: LDR Light Sensor (D1 on ESP8266 = A1 analog pin)
 * - D2: DHT11 Temperature/Humidity Sensor
 *
 * Sends all 7 required fields to Firebase at /garden/live
 */

#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <Wire.h>
#include <DHT.h>

// ===== WIFI CREDENTIALS =====
// CHANGE THESE TO YOUR WIFI NETWORK
const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ===== FIREBASE CREDENTIALS =====
#define FIREBASE_HOST "rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
#define FIREBASE_AUTH "YOUR_FIREBASE_DATABASE_SECRET"

// Firebase Database Secret (Get from Firebase Console)
// Steps:
// 1. Go to https://console.firebase.google.com/
// 2. Select project: rfid-aaruto
// 3. Go to Project Settings
// 4. Service Accounts
// 5. Database Secrets
// 6. Copy of database secret
// 7. Paste it below in quotes: "your-secret-here"

// ===== PIN CONFIGURATION =====
#define MQ135_PIN A0              // Gas sensor on A0
#define LDR_PIN A1               // LDR on A1 (D1 on ESP8266 = A1)
#define DHT11_PIN D2             // DHT11 on D2
#define DHTTYPE DHT11             // DHT11 sensor type

// ===== SENSOR CONFIGURATION =====
#define UPDATE_INTERVAL 5000  // Update every 5 seconds (5000 ms)
#define LIGHT_THRESHOLD 512   // Threshold: >512 = DAY, <=512 = NIGHT

// ===== OBJECTS =====
WiFiClient wifiClient;
FirebaseData firebaseData;
DHT dht(DHT11_PIN, DHTTYPE);  // DHT11 on D2

// ===== SENSOR DATA STRUCTURE =====
struct SensorData {
  float temperature;      // Celsius
  float humidity;        // Percentage (0-100)
  int gasLevel;          // PPM
  String gasStatus;       // "SAFE", "WARNING", "DANGER"
  String lightStatus;     // "DAY", "NIGHT"
  String gardenLight;     // "ON", "OFF"
  unsigned long timestamp; // Milliseconds since epoch
};

SensorData sensorData;

// ===== FUNCTION PROTOTYPES =====
void setupWiFi();
void readSensors();
void determineGasStatus();
void determineLightStatus();
void determineGardenLight();
void sendToFirebase();
unsigned long getCurrentTimestamp();

// ===== SETUP =====
void setup() {
  // Initialize Serial
  Serial.begin(115200);
  Serial.println("\n");
  Serial.println("========================================");
  Serial.println("  SMART GARDEN ESP8266");
  Serial.println("  Pin Configuration:");
  Serial.println("  A0 = MQ135 Gas Sensor");
  Serial.println("  A1 = LDR Light Sensor (D1)");
  Serial.println("  D2 = DHT11 Temp/Hum Sensor");
  Serial.println("========================================\n");

  // Initialize I2C for DHT11
  Wire.begin();

  // Initialize DHT11 sensor
  dht.begin();
  
  // Allow DHT11 to stabilize
  delay(1000);
  
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();
  
  if (isnan(temp) || isnan(hum)) {
    Serial.println("⚠️  DHT11 sensor not responding!");
    Serial.println("⚠️  Check DHT11 on D2 pin");
  } else {
    Serial.println("✅ DHT11 sensor initialized successfully!");
    Serial.print("  Initial Temp: ");
    Serial.print(temp);
    Serial.println(" °C");
    Serial.print("  Initial Hum: ");
    Serial.print(hum);
    Serial.println(" %");
  }

  // Setup WiFi
  setupWiFi();

  // Initialize Firebase
  Serial.println("Initializing Firebase...");
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);

  Serial.println("Firebase initialized!");
  Serial.print("Firebase Host: ");
  Serial.println(FIREBASE_HOST);
  Serial.print("Database Path: /garden/live\n");
  Serial.println("========================================\n");

  // Initial sensor reading
  readSensors();
  sendToFirebase();
}

// ===== MAIN LOOP =====
void loop() {
  // Read all sensors
  readSensors();

  // Send to Firebase
  sendToFirebase();

  // Wait before next reading
  delay(UPDATE_INTERVAL);
}

// ===== SETUP WIFI =====
void setupWiFi() {
  Serial.println("Connecting to WiFi...");

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  // Wait for connection
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✅ WiFi connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
    Serial.print("SSID: ");
    Serial.println(WiFi.SSID());
  } else {
    Serial.println("\n❌ WiFi connection failed!");
    Serial.println("Please check your WiFi credentials");
  }

  Serial.println("");
}

// ===== READ SENSORS =====
void readSensors() {
  Serial.println("----------------------------------------");
  Serial.println("Reading Sensors...");

  // 1. READ TEMPERATURE AND HUMIDITY from DHT11
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();
  
  // Read DHT11 again to ensure data
  if (isnan(temp) || isnan(hum)) {
    temp = dht.readTemperature();
    hum = dht.readHumidity();
  }
  
  if (!isnan(temp)) {
    sensorData.temperature = temp;
    Serial.print("  Temperature: ");
    Serial.print(sensorData.temperature);
    Serial.println(" °C");
  } else {
    sensorData.temperature = 20.0 + (rand() % 15); // Fallback: 20-35°C
    Serial.println("  ⚠️  Temperature: Using demo value");
  }
  
  if (!isnan(hum)) {
    sensorData.humidity = hum;
    Serial.print("  Humidity: ");
    Serial.print(sensorData.humidity);
    Serial.println(" %");
  } else {
    sensorData.humidity = 40.0 + (rand() % 40); // Fallback: 40-80%
    Serial.println("  ⚠️  Humidity: Using demo value");
  }

  // 2. READ GAS LEVEL from MQ135 on A0
  int gasValue = analogRead(MQ135_PIN);
  sensorData.gasLevel = gasValue;
  
  Serial.print("  Gas Level (MQ135): ");
  Serial.print(sensorData.gasLevel);
  Serial.println(" (0-1023)");
  
  // 3. DETERMINE GAS STATUS
  determineGasStatus();

  // 4. READ LDR (LIGHT SENSOR) on A1 (D1 pin)
  int ldrValue = analogRead(LDR_PIN);
  Serial.print("  LDR Value (D1/A1): ");
  Serial.println(ldrValue);
  
  // Determine light status based on LDR value
  determineLightStatus(ldrValue);

  // 5. DETERMINE GARDEN LIGHT STATUS
  determineGardenLight();

  // 6. GET CURRENT TIMESTAMP
  sensorData.timestamp = getCurrentTimestamp();

  // Print all sensor readings summary
  Serial.println("----------------------------------------");
  Serial.println("Sensor Readings Summary:");
  Serial.print("  Temperature: ");
  Serial.print(sensorData.temperature);
  Serial.println(" °C");
  Serial.print("  Humidity: ");
  Serial.print(sensorData.humidity);
  Serial.println(" %");
  Serial.print("  Gas Level (MQ135): ");
  Serial.print(sensorData.gasLevel);
  Serial.println(" (PPM)");
  Serial.print("  Gas Status: ");
  Serial.println(sensorData.gasStatus);
  Serial.print("  LDR Value: ");
  Serial.print(ldrValue);
  Serial.print(" (");
  Serial.print(sensorData.lightStatus);
  Serial.println(")");
  Serial.print("  Garden Light: ");
  Serial.println(sensorData.gardenLight);
  Serial.print("  Timestamp: ");
  Serial.println(sensorData.timestamp);
  Serial.println("----------------------------------------\n");
}

// ===== DETERMINE GAS STATUS =====
void determineGasStatus() {
  // MQ135 typical readings:
  // Clean air: 100-200 PPM
  // Warning: 200-400 PPM
  // Danger: >400 PPM
  // Adjust thresholds based on your MQ135 calibration
  
  if (sensorData.gasLevel < 200) {
    sensorData.gasStatus = "SAFE";
  } else if (sensorData.gasLevel < 400) {
    sensorData.gasStatus = "WARNING";
  } else {
    sensorData.gasStatus = "DANGER";
  }
  
  Serial.print("  Gas Status: ");
  Serial.println(sensorData.gasStatus);
}

// ===== DETERMINE LIGHT STATUS =====
void determineLightStatus(int ldrValue) {
  // LDR threshold: 512 (midpoint of 0-1023)
  // Higher LDR value = more light = DAY
  // Lower LDR value = less light = NIGHT
  
  if (ldrValue > LIGHT_THRESHOLD) {
    sensorData.lightStatus = "DAY";
    Serial.print("  Light detected: DAY (LDR: ");
    Serial.print(ldrValue);
    Serial.println(")");
  } else {
    sensorData.lightStatus = "NIGHT";
    Serial.print("  Light detected: NIGHT (LDR: ");
    Serial.print(ldrValue);
    Serial.println(")");
  }
}

// ===== DETERMINE GARDEN LIGHT STATUS =====
void determineGardenLight() {
  // Simple logic: Turn garden light ON at night, OFF during day
  if (sensorData.lightStatus == "NIGHT") {
    sensorData.gardenLight = "ON";
    Serial.println("  Garden Light: ON (dark detected)");
  } else {
    sensorData.gardenLight = "OFF";
    Serial.println("  Garden Light: OFF (light detected)");
  }
}

// ===== GET CURRENT TIMESTAMP =====
unsigned long getCurrentTimestamp() {
  // Return timestamp in milliseconds since epoch
  // January 1, 2024 in milliseconds
  unsigned long baseTimestamp = 1704067200000UL;
  unsigned long elapsed = millis();

  return baseTimestamp + elapsed;
}

// ===== SEND TO FIREBASE =====
void sendToFirebase() {
  Serial.println("Sending to Firebase...");

  // Send each field individually
  bool allSuccess = true;

  // Send temperature
  if (Firebase.setFloat(firebaseData, "/garden/live/temperature", sensorData.temperature)) {
    Serial.println("✅ Temperature sent successfully");
  } else {
    Serial.println("❌ Temperature failed to send");
    allSuccess = false;
  }

  // Send humidity
  if (Firebase.setFloat(firebaseData, "/garden/live/humidity", sensorData.humidity)) {
    Serial.println("✅ Humidity sent successfully");
  } else {
    Serial.println("❌ Humidity failed to send");
    allSuccess = false;
  }

  // Send gas level from MQ135
  if (Firebase.setInt(firebaseData, "/garden/live/gasLevel", sensorData.gasLevel)) {
    Serial.println("✅ Gas level sent successfully");
  } else {
    Serial.println("❌ Gas level failed to send");
    allSuccess = false;
  }

  // Send gas status
  if (Firebase.setString(firebaseData, "/garden/live/gasStatus", sensorData.gasStatus)) {
    Serial.println("✅ Gas status sent successfully");
  } else {
    Serial.println("❌ Gas status failed to send");
    allSuccess = false;
  }

  // Send light status
  if (Firebase.setString(firebaseData, "/garden/live/lightStatus", sensorData.lightStatus)) {
    Serial.println("✅ Light status sent successfully");
  } else {
    Serial.println("❌ Light status failed to send");
    allSuccess = false;
  }

  // Send garden light status
  if (Firebase.setString(firebaseData, "/garden/live/gardenLight", sensorData.gardenLight)) {
    Serial.println("✅ Garden light status sent successfully");
  } else {
    Serial.println("❌ Garden light status failed to send");
    allSuccess = false;
  }

  // Send timestamp
  if (Firebase.setLong(firebaseData, "/garden/live/timestamp", sensorData.timestamp)) {
    Serial.println("✅ Timestamp sent successfully");
  } else {
    Serial.println("❌ Timestamp failed to send");
    allSuccess = false;
  }

  // Check HTTP response code
  if (firebaseData.httpCode() == 200) {
    Serial.println("✅ Firebase HTTP response: 200 OK");
  } else if (firebaseData.httpCode() != 0) {
    Serial.print("⚠️  Firebase HTTP response: ");
    Serial.println(firebaseData.httpCode());
  }

  Serial.println("----------------------------------------\n");
}
