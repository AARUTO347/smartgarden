# Smart Garden Lighting & Environment Automation Dashboard

A modern, production-ready IoT dashboard for monitoring and controlling garden lighting and environmental conditions. Built with Next.js 15, TypeScript, Tailwind CSS, and Firebase Realtime Database.

## Features

- **Secure Authentication**: Session-based login with hardcoded credentials
- **Real-time Data**: Live updates from Firebase Realtime Database
- **Eco-Friendly Design**: Green, nature-themed UI with glassmorphism effects
- **Responsive Layout**: Fully responsive design for mobile, tablet, and desktop
- **Animated Sensor Cards**: Beautiful, animated cards displaying:
  - Temperature (°C)
  - Humidity (%)
  - Light Status (DAY / NIGHT)
  - Garden Light (ON / OFF)
  - Gas Status (SAFE / WARNING / DANGER)

## Tech Stack

- **Framework**: Next.js 15 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 with shadcn/ui components
- **Backend**: Firebase Realtime Database
- **State Management**: React Hooks + Session Storage
- **Icons**: Lucide React

## Getting Started

### Quick Start (Demo Mode)

You can run the application immediately without Firebase configuration:

1. Start the development server:
```bash
bun run dev
```

2. Open [http://localhost:3000](http://localhost:3000) in your browser

3. Login with the demo credentials:
   - **Username**: `VIPIN`
   - **Password**: `VIPIN123`

4. The dashboard will load in demo mode with placeholder data (-- values)

### Prerequisites

- Node.js 18+ or Bun
- Firebase project with Realtime Database enabled (for real-time data)

### Installation

1. Clone the repository and install dependencies:
```bash
bun install
```

### Firebase Setup

1. Create a Firebase project at [https://console.firebase.google.com/](https://console.firebase.google.com/)

2. Enable Realtime Database for your project

3. Get your Firebase configuration:
   - Go to Project Settings
   - Scroll to "Your apps" section
   - Copy the configuration values

4. Create a `.env.local` file in the project root and add your Firebase configuration:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project_id.firebaseapp.com
NEXT_PUBLIC_FIREBASE_DATABASE_URL=https://your_project_id.firebaseio.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project_id.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
```

### Firebase Database Structure

Create the following structure in your Firebase Realtime Database:

```
{
  "gardenData": {
    "live": {
      "temperature": 25.5,
      "humidity": 65,
      "lightStatus": "DAY",
      "gardenLight": "ON",
      "gasLevel": 150,
      "gasStatus": "SAFE",
      "timestamp": 1640995200000
    }
  }
}
```

### Running the Application

Start the development server:
```bash
bun run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Login Credentials

- **Username**: `VIPIN`
- **Password**: `VIPIN123`

## Project Structure

```
src/
├── app/
│   ├── page.tsx          # Main page with login/dashboard routing
│   ├── layout.tsx        # Root layout with metadata
│   └── globals.css       # Global styles with eco-friendly theme
├── components/
│   ├── login.tsx         # Login component with glassmorphism
│   └── dashboard.tsx     # Dashboard with sensor cards
├── hooks/
│   └── use-session.ts    # Session management hook
└── lib/
    ├── firebase.ts       # Firebase configuration
    └── app-logic.ts      # Realtime data logic and utilities
```

## Components

### Login Component (`src/components/login.tsx`)
- Centered glassmorphism card
- Garden/nature gradient background
- Input icons and animations
- Hover glow effects on button
- Footer branding

### Dashboard Component (`src/components/dashboard.tsx`)
- Sticky header with project title
- Animated sensor cards grid
- Real-time data updates
- Color-coded status indicators
- Logout functionality
- System information panel

## Styling

The application uses:
- **Glassmorphism**: Translucent cards with backdrop blur
- **Eco-friendly Palette**: Green and nature-inspired colors
- **Soft Glow Animations**: Subtle pulse effects
- **Smooth Transitions**: All interactive elements have transitions
- **Custom Scrollbars**: Styled to match the theme

## Firebase Integration

### Expected Data Format

```typescript
{
  temperature?: number      // Temperature in Celsius
  humidity?: number        // Humidity percentage
  lightStatus?: 'DAY' | 'NIGHT'
  gardenLight?: 'ON' | 'OFF'
  gasLevel?: number        // Gas level in PPM
  gasStatus?: 'SAFE' | 'WARNING' | 'DANGER'
  timestamp?: number       // Unix timestamp
}
```

### Real-time Updates

The dashboard automatically subscribes to Firebase Realtime Database updates at path `gardenData/live`. Changes are reflected immediately in the UI.

## Deployment

### Deploying to Netlify

1. Build the project:
```bash
bun run build
```

2. Deploy to Netlify:
   - Connect your repository to Netlify
   - Set build command: `bun run build`
   - Set publish directory: `.next`
   - Add environment variables for Firebase

3. Configure your Firebase Realtime Database rules for production

### Environment Variables

Make sure to add all Firebase environment variables to your deployment platform.

## Branding

The application includes the required branding in the footer:
- **MADE BY AARUTO**
- **POWERED BY CHRONOBOTICS**

This branding appears in:
- Footer of every page
- Page title metadata
- OpenGraph and Twitter card metadata

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Accessibility

- Semantic HTML elements
- ARIA labels where needed
- Keyboard navigation support
- Screen reader compatible
- Proper color contrast ratios

## License

This project is part of the Smart Garden Lighting & Environment Automation system.

## Support

For issues and questions, please contact the development team.
