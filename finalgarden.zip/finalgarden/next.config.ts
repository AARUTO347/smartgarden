import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  eslint: {
    ignoreDuringBuilds: true,
  },
  // Image optimization
  images: {
    unoptimized: true, // Required for static export on Netlify
  },
  // Compress response bodies
  compress: true,
  // Generate ETags
  generateEtags: true,
  // PoweredByHeader
  poweredByHeader: false,
  // Production source maps
  productionBrowserSourceMaps: false,
};

export default nextConfig;
