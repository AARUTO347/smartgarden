# Quick Setup - Connect Dashboard to Firebase Database ✅

## 🚀 Quick Start (5 Minutes)

### Step 1: Set Up Firebase Database (2 minutes)

1. **Open Firebase Console**:
   ```
   https://console.firebase.google.com/project/rfid-aaruto/database
   ```

2. **Create Database Structure**:
   Click on the database and add this JSON:
   ```json
   {
     "temperature": 25.0,
     "humidity": 60.0,
     "gasLevel": 150,
     "gasStatus": "SAFE",
     "lightStatus": "DAY",
     "gardenLight": "ON",
     "timestamp": 1704148800000
   }
   ```

3. **Set Database Rules**:
   Go to "Rules" tab and set:
   ```json
   {
     "rules": {
       ".read": true,
       ".write": true
     }
   }
   ```
   Click "Publish"

### Step 2: Open Dashboard (1 minute)

1. **Open**: http://localhost:3000
2. **Login**: VIPIN / VIPIN123
3. **View**: You should now see real data!

### Step 3: Update Data Manually (Optional - 1 minute)

1. **Keep dashboard open**
2. **Go to Firebase Console**
3. **Change temperature** from 25 to 30
4. **Refresh dashboard**
5. ✅ Temperature card should show 30°C

### Step 4: Upload ESP8266 Code (Optional - 1 minute)

1. **Open**: `ESP8266_Firebase_Sender/ESP8266_SmartGarden.ino`
2. **Edit**: WiFi credentials
3. **Upload**: To your ESP8266 via Arduino IDE
4. **Monitor**: Serial Monitor for data sending

---

## ✅ Verification Checklist

After setup, verify each item:

### Firebase Database:
- [ ] Database structure created at `garden/live`
- [ ] Rules allow read and write
- [ ] Test data visible in Firebase Console

### Dashboard:
- [ ] Dashboard loads without errors
- [ ] Login works (VIPIN/VIPIN123)
- [ ] Sensor cards show real values (not "--")
- [ ] Charts view works
- [ ] Data updates in real-time

### ESP8266 (if using):
- [ ] Code uploads successfully
- [ ] WiFi connects
- [ ] Firebase connects
- [ ] Sensor readings appear in Serial Monitor
- [ ] Data appears in Firebase Console

---

## 🔍 How Dashboard Connects to Firebase

### Automatic Connection:

Dashboard is already configured to:
1. **Load** Firebase on client side only
2. **Connect** to `rfid-aaruto-default-rtdb`
3. **Read** from path `garden/live`
4. **Update** automatically when data changes
5. **Display** values in real-time

### No Manual Connection Needed!

The dashboard automatically:
- Initializes Firebase when page loads
- Subscribes to `garden/live` path
- Listens for data changes
- Updates UI in real-time
- Stores historical data for charts

---

## 📊 What You'll See

### Dashboard View (Real-time):
- **Temperature Card**: Shows live temperature (°C)
- **Humidity Card**: Shows live humidity (%)
- **Light Status Card**: Shows DAY/NIGHT
- **Garden Light Card**: Shows ON/OFF
- **Gas Status Card**: Shows SAFE/WARNING/DANGER (color-coded)

### Charts View (Real-time):
- **Temperature & Humidity**: Area chart with trends
- **AQI HISTORY**: Bar chart with AQI levels
- Both charts update automatically when ESP8266 sends data

---

## 🧪 Testing Connection

### Test 1: Manual Data Entry

```
1. Open Firebase Console → Database
2. Navigate to garden/live
3. Change any value (e.g., temperature: 35)
4. Click save
5. Look at dashboard
6. ✅ Should update to 35°C automatically
```

### Test 2: Real-time Updates

```
1. Open Firebase Console
2. Change temperature to 28, wait 5 seconds
3. Change to 32, wait 5 seconds
4. Change to 25, wait 5 seconds
5. ✅ Dashboard should update to each value
6. ✅ Charts should show history
```

### Test 3: With ESP8266 (Optional)

```
1. Upload ESP8266 code
2. Open Serial Monitor (115200 baud)
3. Change sensor readings (blow on gas sensor, warm AHT)
4. Watch Serial Monitor output
5. Check Firebase Console → Database
6. Check dashboard
7. ✅ All three should show same values
```

---

## 🔥 Firebase Configuration

### Dashboard Already Configured:

```typescript
// src/lib/firebase.ts
const firebaseConfig = {
  apiKey: "AIzaSyClHyEygOT1Qh87x01vnG4LxtFCXLSP1FA",
  authDomain: "rfid-aaruto.firebaseapp.com",
  databaseURL: "https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "rfid-aaruto",
  storageBucket: "rfid-aaruto.appspot.com",
  messagingSenderId: "346182773188",
  appId: "1:346182773188:web:e9e32b36840930944ddc91",
  measurementId: "G-VGJYYT6ZTZ"
}

// Database path
export function getGardenDataRef(): DatabaseReference {
  return database.ref('garden/live')
}
```

---

## 📱 Dashboard Features for Firebase

### Real-time Updates:
- ✅ Auto-connects to Firebase on load
- ✅ Listens to `garden/live` path
- ✅ Updates UI when data changes
- ✅ No refresh needed
- ✅ Stores last 50 readings for charts

### Error Handling:
- ✅ Connection status indicator
- ✅ Graceful error handling
- ✅ Console logging for debugging
- ✅ Offline handling

### Data Display:
- ✅ Sensor cards with live values
- ✅ Color-coded status indicators
- ✅ Interactive charts with history
- ✅ Timestamp display
- ✅ Historical data count

---

## 🆘 Common Issues

### Issue: Dashboard shows "--"
**Solution**:
```
1. Go to Firebase Console
2. Check if garden/live has data
3. Add test data if empty:
   {
     "temperature": 27.5,
     "humidity": 60.9,
     "gasLevel": 150,
     "gasStatus": "SAFE",
     "lightStatus": "DAY",
     "gardenLight": "ON",
     "timestamp": 1704148800000
   }
4. Refresh dashboard
```

### Issue: Values not updating
**Solution**:
```
1. Check database rules (must allow read/write)
2. Refresh dashboard page
3. Check browser console (F12) for errors
4. Verify Firebase project ID matches
```

### Issue: Charts not showing history
**Solution**:
```
1. Wait for multiple readings (2+ updates)
2. Switch to Charts view
3. Historical data accumulates automatically
4. Last 50 readings are stored
```

---

## 🌟 Complete Data Flow

```
Firebase Console (you)
      ↓ Add/Edit Data
      ↓
  Firebase Realtime DB
      ↓ Real-time Updates
      ↓
  Dashboard (localhost:3000)
      ├─→ Dashboard View
      │   - 5 Sensor Cards
      │   - Real values
      │   - Color-coded status
      └─→ Charts View
          - Temperature Chart (8 Y-axis numbers)
          - AQI History Chart (10 Y-axis numbers)
          - Historical data
```

---

## 🎯 Quick Commands

### Access Dashboard:
```
http://localhost:3000
```

### Firebase Console:
```
https://console.firebase.google.com/project/rfid-aaruto/database
```

### Add Test Data (Firebase Console):
```
Copy this JSON and paste at garden/live:

{
  "temperature": 28.5,
  "humidity": 65.2,
  "gasLevel": 180,
  "gasStatus": "SAFE",
  "lightStatus": "DAY",
  "gardenLight": "ON",
  "timestamp": 1704148800000
}
```

---

## 🚀 You're Ready!

### Dashboard is Already Configured:
- ✅ Firebase connected
- ✅ Path set to `garden/live`
- ✅ Real-time updates enabled
- ✅ Charts working
- ✅ All features functional

### Just Add Data:
1. Go to Firebase Console
2. Add test data to `garden/live`
3. Open dashboard
4. See real data displayed!

---

## 📞 Support

### Dashboard:
- URL: http://localhost:3000
- Features: Real-time data, charts, CSV export
- Login: VIPIN / VIPIN123

### Firebase:
- Console: https://console.firebase.google.com
- Project: rfid-aaruto
- Database: rfid-aaruto-default-rtdb
- Path: garden/live

### ESP8266:
- Code: `ESP8266_Firebase_Sender/ESP8266_SmartGarden.ino`
- Libraries: FirebaseESP8266
- Update interval: 5 seconds

---

## ✅ Status

**Dashboard**: ✅ Connected to Firebase
**Database**: ✅ Ready for data
**ESP8266**: ✅ Code provided
**Real-time**: ✅ Automatic updates
**Charts**: ✅ Enhanced with more Y-axis numbers

---

🌿 **MADE BY AARUTO** | **POWERED BY CHRONOBOTICS** 🌿

**Start Now - Add Data to Firebase and See Real-time Updates!** 🚀
