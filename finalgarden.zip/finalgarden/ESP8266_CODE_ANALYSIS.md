# ESP8266 Code Analysis & Fixes

## Issues Found in Your Code

### 1. ❌ Typo in timestamp field name
```cpp
// WRONG:
json.set("garden/live/timestamp", timestamp);

// CORRECT:
json.set("garden/live/timestamp", timestamp);
```
The field name is correct, but you're using a different variable name. Actually, looking at it again - this is correct syntax for Firebase updateNode.

### 2. ⚠️ Gas Status Values Don't Match Dashboard
Your code uses these values:
```cpp
"GOOD", "MODERATE", "UNHEALTHY", "VERY_UNHEALTHY", "HAZARDOUS"
```

Standard AQI values are:
```cpp
"GOOD", "MODERATE", "POOR", "DANGEROUS"
```

**Solution**: I've updated the dashboard to support your values. They will map to these colors:
- `GOOD` → Green 🟢
- `MODERATE` → Yellow 🟡
- `UNHEALTHY` → Orange 🟠
- `VERY_UNHEALTHY` → Red 🔴
- `HAZARDOUS` → Red 🔴

### 3. ⚠️ LDR Logic Might Be Backwards
```cpp
String lightStatus = (digitalRead(LDR_PIN) == LOW) ? "DAY" : "NIGHT";
```

For LDR on digital pin:
- **LOW** typically means **DARK/NIGHT** (resistance high, less current)
- **HIGH** typically means **BRIGHT/DAY** (resistance low, more current)

Your code has this backwards. Test this and swap if needed.

### 4. ✅ AQI Calculation is Good
Your AQI conversion function is well-structured:
```cpp
int convertMQ135ToAQI(int raw) {
  if (raw <= 150) return map(raw, 0, 150, 0, 50);
  if (raw <= 300) return map(raw, 151, 300, 51, 100);
  if (raw <= 500) return map(raw, 301, 500, 101, 150);
  if (raw <= 700) return map(raw, 501, 700, 151, 200);
  return map(raw, 701, 1023, 201, 300);
}
```

**Note**: This only goes up to 300 AQI, but your dashboard supports 500. This is fine unless you need the full 500 range.

### 5. ⚠️ Using Digital Read for LDR
```cpp
pinMode(LDR_PIN, INPUT);
...
String lightStatus = (digitalRead(LDR_PIN) == LOW) ? "DAY" : "NIGHT";
```

D1 is a digital pin, so `digitalRead()` is correct. However, for better light detection:

**Option A - Use Digital Threshold (Current approach)**
```cpp
String lightStatus = (digitalRead(LDR_PIN) == HIGH) ? "DAY" : "NIGHT";
// Test this and swap if it's backwards
```

**Option B - Use Analog for More Precision**
If you want to use A0 for LDR (but MQ135 is on A0, so you can't):
```cpp
int lightValue = analogRead(A0);
String lightStatus = (lightValue > 512) ? "DAY" : "NIGHT";
```

### 6. ⚠️ No MQ135 Library Included
Your code reads from MQ135 but doesn't include any MQ135 library. This is actually **fine** because you're using `analogRead(MQ135_PIN)` directly to get raw values. However, if you want to use PPM conversion, you'd need a library.

Your current approach:
```cpp
int mqRaw = analogRead(MQ135_PIN);
int aqi = convertMQ135ToAQI(mqRaw);
```
This works perfectly since you're doing custom AQI conversion.

### 7. ✅ Firebase Data Structure is Perfect
Your Firebase structure matches exactly what the dashboard expects:
```json
{
  "garden": {
    "live": {
      "gasLevel": 284,
      "aqi": 94,
      "gasStatus": "MODERATE",
      "humidity": 62.1,
      "temperature": 28.0,
      "lightStatus": "NIGHT",
      "timestamp": 5124
    }
  }
}
```

## Dashboard Updates Made

I've updated the dashboard to support your gas status values:

### Updated Interface
```typescript
gasStatus?: 'GOOD' | 'MODERATE' | 'POOR' | 'DANGEROUS' |
            'SAFE' | 'WARNING' | 'DANGER' |
            'UNHEALTHY' | 'VERY_UNHEALTHY' | 'HAZARDOUS'
```

### Color Mapping
| Your Status | Dashboard Color | Icon |
|-------------|-----------------|-------|
| GOOD | 🟢 Green | Shield |
| MODERATE | 🟡 Yellow | Alert Triangle |
| UNHEALTHY | 🟠 Orange | Alert Triangle |
| VERY_UNHEALTHY | 🔴 Red | Flame |
| HAZARDOUS | 🔴 Red | Flame |

## Recommended Code Fixes

### Fix 1: Test and Adjust LDR Logic
```cpp
// Test both versions and see which works for your setup:

// Version A (your current):
String lightStatus = (digitalRead(LDR_PIN) == LOW) ? "DAY" : "NIGHT";

// Version B (typical for LDR):
String lightStatus = (digitalRead(LDR_PIN) == HIGH) ? "DAY" : "NIGHT";
```

### Fix 2: Consider Full AQI Scale (Optional)
If you need AQI up to 500:
```cpp
int convertMQ135ToAQI(int raw) {
  if (raw <= 150) return map(raw, 0, 150, 0, 50);
  if (raw <= 300) return map(raw, 151, 300, 51, 100);
  if (raw <= 500) return map(raw, 301, 500, 101, 200);
  if (raw <= 700) return map(raw, 501, 700, 201, 300);
  if (raw <= 900) return map(raw, 701, 900, 301, 400);
  return map(raw, 901, 1023, 401, 500);  // Full 500 scale
}
```

### Fix 3: Add Debug Output (Recommended)
```cpp
void loop() {
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("Failed to read from DHT sensor!");
    return;
  }

  int mqRaw = analogRead(MQ135_PIN);
  int aqi = convertMQ135ToAQI(mqRaw);
  String gasStatus = getAQIStatus(aqi);

  int ldrValue = digitalRead(LDR_PIN);
  String lightStatus = (ldrValue == LOW) ? "DAY" : "NIGHT";
  unsigned long timestamp = millis() / 1000;

  // Debug output
  Serial.println("========== SENSOR READINGS ==========");
  Serial.print("Temperature: "); Serial.print(temperature); Serial.println(" °C");
  Serial.print("Humidity: "); Serial.print(humidity); Serial.println(" %");
  Serial.print("MQ135 Raw: "); Serial.println(mqRaw);
  Serial.print("AQI: "); Serial.println(aqi);
  Serial.print("Gas Status: "); Serial.println(gasStatus);
  Serial.print("LDR: "); Serial.println(ldrValue);
  Serial.print("Light Status: "); Serial.println(lightStatus);
  Serial.print("Timestamp: "); Serial.println(timestamp);
  Serial.println("=====================================");

  FirebaseJson json;
  json.set("garden/live/gasLevel", mqRaw);
  json.set("garden/live/aqi", aqi);
  json.set("garden/live/gasStatus", gasStatus);
  json.set("garden/live/humidity", humidity);
  json.set("garden/live/temperature", temperature);
  json.set("garden/live/lightStatus", lightStatus);
  json.set("garden/live/timestamp", timestamp);

  if (Firebase.updateNode(fbdo, "/", json)) {
    Serial.println("✅ Firebase Updated Successfully");
  } else {
    Serial.print("❌ Firebase Update Failed: ");
    Serial.println(fbdo.errorReason());
  }

  delay(5000);
}
```

## Pin Configuration Summary

| Pin | Component | Type | Purpose |
|------|-----------|------|---------|
| A0 | MQ135 | Analog | Gas sensor reading |
| D1 | LDR | Digital Input | Light detection (HIGH/LOW) |
| D2 | DHT11 | Digital | Temperature & Humidity (I2C) |

## Testing Checklist

- [ ] Test LDR reading - verify DAY/NIGHT is correct
- [ ] Check serial monitor for sensor values
- [ ] Verify Firebase updates in Firebase Console
- [ ] Check dashboard shows correct values
- [ ] Test with different air quality conditions
- [ ] Verify AQI values match expected ranges

## Final Notes

✅ **Good**: Firebase structure matches dashboard
✅ **Good**: AQI calculation logic is sound
✅ **Good**: All required fields are being sent
✅ **Good**: Dashboard now supports your status values

⚠️ **Test**: LDR DAY/NIGHT logic (may be backwards)
⚠️ **Optional**: Extend AQI to full 500 scale if needed
⚠️ **Recommended**: Add debug output for troubleshooting

---

**Status**: Dashboard updated and ready for your ESP8266 code ✅
**Last Updated**: Current session
