# ESP8266 Firebase Integration Guide

## Quick Setup Guide for ESP8266 with Firebase

---

## 🔧 Required Libraries (PlatformIO)

### Library Manager - Add these libraries:

```
Firebase ESP8266 Client by Mobizt
```

### Required Libraries:

```
WiFi.h
FirebaseESP8266.h
DHT.h (if using DHT22 sensor)
Wire.h (if using I2C sensors)
```

---

## 📋 Arduino Code Template

```cpp
#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <DHT.h>

// WiFi Credentials
#define WIFI_SSID "Your_WiFi_Name"
#define WIFI_PASSWORD "Your_WiFi_Password"

// Firebase Configuration
#define FIREBASE_HOST "your-project.firebaseio.com"
#define FIREBASE_AUTH "your-firebase-auth-token"
#define DATABASE_PATH "/garden/live"

// Initialize Firebase objects
FirebaseData firebaseData;
FirebaseArduino firebase;

// DHT22 Sensor (if using)
#define DHTPIN 4     // Update to your pin
#define DHTTYPE DHT22   // or DHT11
DHT dht(DHTPIN, DHTTYPE);

// Variables
unsigned long lastSendTime = 0;
const unsigned long sendInterval = 2500;  // Send data every 2.5 seconds

void setup() {
  Serial.begin(115200);
  
  // Initialize WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to WiFi...");
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  Serial.println("");
  Serial.print("WiFi connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  
  // Initialize Firebase
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
  
  // Initialize DHT22
  dht.begin();
  
  Serial.println("Firebase and DHT22 initialized!");
  Serial.println("--------------------------------");
}

void loop() {
  unsigned long currentTime = millis();
  
  // Send data at specified interval
  if (currentTime - lastSendTime >= sendInterval) {
    lastSendTime = currentTime;
    
    // Read sensors
    float temperature = dht.readTemperature();
    float humidity = dht.readHumidity();
    int gasLevel = analogRead(A0);  // Gas sensor on A0
    int lightLevel = analogRead(A1);  // LDR sensor on A1
    
    // Convert light to DAY/NIGHT
    String lightStatus = lightLevel > 500 ? "DAY" : "NIGHT";
    
    // Calculate AQI from gas level
    String gasStatus;
    if (gasLevel <= 50) {
      gasStatus = "GOOD";
    } else if (gasLevel <= 100) {
      gasStatus = "SATISFACTORY";
    } else if (gasLevel <= 200) {
      gasStatus = "MODERATE";
    } else if (gasLevel <= 300) {
      gasStatus = "POOR";
    } else if (gasLevel <= 400) {
      gasStatus = "VERY_POOR";
    } else {
      gasStatus = "SEVERE";
    }
    
    // Set Firebase data
    firebaseData.timestamp = currentTime;
    firebaseData.temperature = temperature;
    firebaseData.humidity = humidity;
    firebaseData.gasLevel = gasLevel;
    firebaseData.gasAQI = gasLevel;
    firebaseData.aqi = gasLevel;
    firebaseData.gasStatus = gasStatus;
    firebaseData.lightStatus = lightStatus;
    
    // Send to Firebase
    if (Firebase.setJSON(firebaseData, DATABASE_PATH)) {
      Serial.println("Data sent to Firebase!");
      Serial.print("Temp: "); Serial.print(temperature);
      Serial.print("°C, Humidity: "); Serial.print(humidity);
      Serial.print("%, Gas AQI: "); Serial.print(gasLevel);
      Serial.print(", Status: "); Serial.println(gasStatus);
    } else {
      Serial.println("Firebase send failed!");
    }
  }
  
  delay(100);
}
```

---

## 🔥 Alternative: Without DHT22 (Simple Sensors)

```cpp
// Replace sensor reading section with:

void loop() {
  unsigned long currentTime = millis();
  
  if (currentTime - lastSendTime >= sendInterval) {
    lastSendTime = currentTime;
    
    // Simple analog sensors
    int tempSensor = analogRead(A0);
    int humiditySensor = analogRead(A1);
    int gasSensor = analogRead(A2);
    int lightSensor = analogRead(A3);
    
    // Convert to meaningful values (adjust calibration as needed)
    float temperature = map(tempSensor, 0, 1023, 10, 35);  // Example calibration
    float humidity = map(humiditySensor, 0, 1023, 30, 90);   // Example calibration
    
    // Light status
    String lightStatus = lightSensor > 512 ? "DAY" : "NIGHT";
    
    // Gas status
    String gasStatus;
    if (gasSensor <= 50) {
      gasStatus = "GOOD";
    } else if (gasSensor <= 100) {
      gasStatus = "SATISFACTORY";
    } else if (gasSensor <= 200) {
      gasStatus = "MODERATE";
    } else if (gasSensor <= 300) {
      gasStatus = "POOR";
    } else if (gasSensor <= 400) {
      gasStatus = "VERY_POOR";
    } else {
      gasStatus = "SEVERE";
    }
    
    // Send to Firebase...
    // (same as above)
  }
  
  delay(100);
}
```

---

## 📱 Firebase JSON Structure for ESP8266

```cpp
// Define structure that matches your Firebase database
struct FirebaseData {
  unsigned long timestamp;    // Milliseconds since epoch
  float temperature;            // Temperature in Celsius
  float humidity;               // Humidity in percentage
  int gasLevel;                 // Raw gas sensor reading
  int gasAQI;                  // Air Quality Index
  int aqi;                      // Duplicate for compatibility
  String gasStatus;             // Air quality category
  String lightStatus;            // DAY or NIGHT
};

FirebaseData firebaseData;
```

---

## 🔐 Firebase Rules for Database

```json
{
  "rules": {
    "garden": {
      ".read": true,
      "live": {
        ".read": true,
        ".write": "auth != null"
      }
    }
  }
}
```

---

## 🌐 Setup in Firebase Console

1. **Create Project** at https://console.firebase.google.com
2. **Enable Realtime Database**
3. **Go to Project Settings** → General
4. **Copy Project ID** and **API Key**
5. **Go to Authentication** → Sign-in method
6. **Enable Anonymous** authentication (or Email/Password)
7. **Copy** the authentication settings

---

## 📊 Data Calibration Examples

### Temperature (LM35 or DHT22)

```cpp
// LM35 analog sensor
float readTemperature() {
  int rawValue = analogRead(TEMP_PIN);
  float voltage = rawValue * (3.3 / 4095);  // Convert to voltage
  float temp = voltage * 100;  // Example: 10mV per degree
  return temp;
}

// DHT22 digital sensor
float readTemperature() {
  float temp = dht.readTemperature();
  if (isnan(temp)) {
    Serial.println("Failed to read temperature from DHT sensor!");
    return 0;
  }
  return temp;
}
```

### Humidity (Capacitive or DHT22)

```cpp
float readHumidity() {
  float humidity = dht.readHumidity();
  if (isnan(humidity)) {
    Serial.println("Failed to read humidity from DHT sensor!");
    return 0;
  }
  return humidity;
}
```

### Gas Sensor (MQ-135 or similar)

```cpp
int readGasLevel() {
  int rawValue = analogRead(GAS_PIN);
  int gasLevel = map(rawValue, 0, 1023, 0, 500);  // Map to AQI range
  return gasLevel;
}
```

### Light Sensor (LDR + Resistor)

```cpp
String readLightStatus() {
  int rawValue = analogRead(LIGHT_PIN);
  // Adjust threshold based on your environment
  return rawValue > 500 ? "DAY" : "NIGHT";
}
```

---

## 🔧 Pin Configuration (ESP8266 NodeMCU/ESP12E)

```cpp
// Sensor Pin Definitions
#define DHTPIN 4          // D4 pin for DHT22 data
#define TEMP_PIN A0         // A0 for LM35 temperature
#define HUMID_PIN A1        // A1 for capacitive humidity
#define GAS_PIN A2           // A2 for gas sensor (MQ-135)
#define LIGHT_PIN A3         // A3 for LDR light sensor
```

---

## ⚠️ Troubleshooting

### WiFi Connection Issues

```cpp
// Add WiFi reconnection logic
void checkWiFi() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi disconnected, reconnecting...");
    WiFi.reconnect();
  }
}
```

### Firebase Connection Issues

```cpp
// Check Firebase connection
void checkFirebase() {
  if (!Firebase.connected()) {
    Serial.println("Firebase not connected, reconnecting...");
    Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
  }
}
```

### Serial Debug Output

```cpp
// Add comprehensive logging
void debugPrint(String message) {
  Serial.print("[DEBUG] ");
  Serial.print(millis());
  Serial.print(" - ");
  Serial.println(message);
}

// Use throughout code:
debugPrint("WiFi connected");
debugPrint("Temperature: " + String(temperature));
```

---

## 📱 Web Dashboard Connection

### Device Registration

After ESP8266 is programmed and connected:

1. **Register Device** at your web dashboard:
   - Go to `/signup` page
   - Enter Device ID (unique identifier like "DEVICE001")
   - Enter Location (e.g., "Garden Zone A")
   - Enter Email (optional)
   - Set Password
   - Click "Register Device"

2. **Login** to dashboard:
   - Use Device ID as username
   - Use Password
   - Dashboard will show your device's live data

### Data Flow

```
ESP8266 Sensors → Read Every 2.5s
     ↓
Firebase Realtime Database (/garden/live)
     ↓
Web Dashboard → Real-time Updates (no refresh needed)
     ↓
Charts, Stats, Alerts → Live Display
```

---

## 🎯 Quick Deployment Checklist

### Hardware
- [ ] ESP8266 NodeMCU or ESP12E module
- [ ] DHT22 temperature/humidity sensor
- [ ] MQ-135 gas sensor
- [ ] LDR light sensor
- [ ] Jumper wires / breadboard
- [ ] USB cable for programming

### Software
- [ ] Arduino IDE installed
- [ ] Firebase ESP8266 library installed
- [ ] WiFi credentials configured
- [ ] Firebase project created
- [ ] Firebase Realtime Database enabled
- [ ] Firebase authentication set up
- [ ] Code uploaded to ESP8266

### Firebase Console
- [ ] Database rules configured
- [ ] Authentication enabled
- [ ] Project ID and keys copied
- [ ] Database path created: `/garden/live`

### Web Dashboard
- [ ] Device registered on dashboard
- [ ] Login credentials working
- [ ] Real-time data updating
- [ ] Charts displaying correctly
- [ ] Export functions working (CSV/PDF)

---

## 📞 Support & Resources

**Documentation Files:**
- `FIREBASE_DATA_STRUCTURE.md` - Complete data structure reference
- `ESP8266_SETUP_GUIDE.md` - This file

**Contact:**
- Email: aaruto@admin.smartgarden
- Admin: AARUTO / AARUTO100108112

---

*Last Updated: 2025-01-15*
*Version: 1.0.0*
