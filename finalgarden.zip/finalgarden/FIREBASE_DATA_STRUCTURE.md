# Firebase Data Structure - Updated for Device ID

## Smart Garden Monitoring System - Firebase Realtime Database

---

## 📍 Firebase Path Structure (Updated)

```
/device_id/
└── garden/
    └── live/                    # Main sensor data path
        └── {
            timestamp: number
            temperature: number
            humidity: number
            gasLevel: number
            gasAQI: number
            aqi: number
            gasStatus: string
            lightStatus: string
            device_id: string        # NEW: Device ID from Firebase
          }
```

---

## 📊 Sensor Data Schema (GardenData)

### Updated Interface

```typescript
export interface GardenData {
  temperature?: number
  humidity?: number
  gasAQI?: number
  aqi?: number
  gasStatus?: string
  lightStatus?: string
  gardenLight?: 'ON' | 'OFF'
  device_id?: string        // NEW: Device ID from Firebase
  timestamp?: number
}
```

### Example Data Object with device_id

```json
{
  "timestamp": 1736886734500,
  "temperature": 24.5,
  "humidity": 65.2,
  "gasLevel": 120,
  "gasAQI": 120,
  "aqi": 120,
  "gasStatus": "MODERATE",
  "lightStatus": "DAY",
  "device_id": "DEVICE001"  // NEW
}
```

### Field Descriptions

| Field | Type | Description | Example | Unit |
|-------|------|-------------|---------|------|
| `timestamp` | number | Unix timestamp in milliseconds | 1736886734500 | ms |
| `temperature` | number | Current temperature reading | 24.5 | °C |
| `humidity` | number | Current humidity reading | 65.2 | % |
| `gasLevel` | number | Raw gas sensor reading | 120 | - |
| `gasAQI` | number | Air Quality Index | 120 | AQI |
| `aqi` | number | Duplicate of gasAQI | 120 | AQI |
| `gasStatus` | string | Air quality category | "MODERATE" | - |
| `lightStatus` | string | Day/Night status | "DAY" | - |
| `device_id` | string | Device identifier | "DEVICE001" | - |

---

## 🏷️ Gas Status Values (Indian CPCB Standard)

| Status | AQI Range | Description | Health Impact |
|---------|-----------|-------------|----------------|
| `GOOD` | 0-50 | Good air quality | Minimal impact |
| `SATISFACTORY` | 51-100 | Acceptable | Little discomfort |
| `MODERATE` | 101-200 | Moderate | Breathing discomfort |
| `POOR` | 201-300 | Poor | Breathing issues |
| `VERY_POOR` | 301-400 | Very Poor | Health alert |
| `SEVERE` | 401-500 | Severe | Emergency |

---

## ☀️ Light Status Values

| Status | Description |
|---------|-------------|
| `DAY` | Daytime (6:00 AM - 6:00 PM) |
| `NIGHT` | Nighttime (6:00 PM - 6:00 AM) |

---

## 🔄 Expected Data Update Frequency

- **Update Interval**: Every 2-5 seconds (typical for ESP8266)
- **Data Source**: ESP8266 IoT Sensors
- **Sync Method**: Firebase Realtime Database SDK
- **Firebase Path**: `/device_id/garden/live`

---

## 📱 User/Device Data Structure

### Storage Keys

```typescript
const USERS_STORAGE_KEY = 'garden_users'
const CURRENT_USER_KEY = 'garden_current_user'
```

### User Schema (Device Account)

```typescript
interface User {
  id: string              // Unique user ID (timestamp)
  username: string       // Device ID (acts as login username)
  password: string       // Device password (same as username for simplicity)
  email: string         // Contact email
  deviceId: string       // Device ID (unique identifier)
  location: string       // Physical device location
  createdAt: number     // Registration timestamp
  isAdmin?: boolean      // Admin flag
}
```

### Example User Object

```json
{
  "id": "17368867345000",
  "username": "DEVICE001",
  "password": "pass1234",
  "email": "device001@example.com",
  "deviceId": "DEVICE001",
  "location": "Garden Zone A",
  "createdAt": 17368867345000",
  "isAdmin": false
}
```

---

## 👤 Admin Account

### Admin Credentials

```typescript
const ADMIN_USERNAME = 'AARUTO'
const ADMIN_PASSWORD = 'AARUTO100108112'
```

### Admin User Object

```json
{
  "id": "admin-aaruto-001",
  "username": "AARUTO",
  "password": "AARUTO100108112",
  "email": "aaruto@admin.smartgarden",
  "deviceId": "AARUTO",
  "location": "Admin Console",
  "createdAt": 17368867345000",
  "isAdmin": true
}
```

### Admin Restrictions

- ✅ Can access `/admin` page
- ✅ Can add, edit, delete device accounts
- ✅ Cannot be deleted (protected)
- ✅ Cannot be modified (password and username locked)
- ✅ Preserved when "Reset All Devices" is used

---

## 🔐 Authentication Flow

### Device Login (Regular User)

```
1. User enters Device ID (e.g., "DEVICE001")
2. User enters Password (e.g., "pass1234")
3. System checks for deviceId in user database
4. If password matches, user is authenticated
5. Session stored in sessionStorage
6. Dashboard shows device-specific data
```

### Admin Login

```
1. Navigate to /admin
2. Enter username: "AARUTO"
3. Enter password: "AARUTO100108112"
4. If authenticated:
   - Auto-login if admin account exists
   - Show device management console
   - Can add/edit/delete device accounts
```

---

## 📋 Device Registration Flow

### Signup/Register Device

```
1. Navigate to signup page
2. Enter Device ID (acts as username for login)
3. Enter Location (e.g., "Garden Zone A")
4. Enter Email (optional, for notifications)
5. Enter Password
6. Confirm Password
7. Submit registration
8. Account created with:
   - username = deviceId
   - deviceId = deviceId
   - isAdmin = false
9. Auto-login to dashboard
```

### Validation Rules

- **Device ID**: Minimum 3 characters, unique
- **Password**: Minimum 6 characters
- **Location**: Minimum 2 characters
- **Email**: Valid email format (optional)

---

## 🧩 ESP8266 Firebase Integration

### Arduino Code Structure

```cpp
#include <FirebaseESP8266.h>
#include <WiFiClient.h>

// Firebase configuration
#define FIREBASE_HOST "your-project.firebaseio.com"
#define FIREBASE_AUTH "your-firebase-auth-token"
#define DATABASE_PATH "/device_id/garden/live"

// Sensor data structure
FirebaseData firebaseData;

void setupFirebase() {
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
  Firebase.reconnectWiFi(true);
}

void sendDataToFirebase() {
  // Read sensors
  float temp = readTemperature();
  float humidity = readHumidity();
  int gasLevel = readGasSensor();
  int lightLevel = readLightSensor();

  // Create data object
  firebaseData.timestamp = millis();
  firebaseData.temperature = temp;
  firebaseData.humidity = humidity;
  firebaseData.gasLevel = gasLevel;
  firebaseData.gasAQI = gasLevel;  // Use gas level as AQI
  firebaseData.aqi = gasLevel;     // Duplicate for compatibility
  firebaseData.gasStatus = getGasStatus(gasLevel);
  firebaseData.lightStatus = getLightStatus(lightLevel);
  firebaseData.device_id = "DEVICE001";  // NEW: Device ID

  // Send to Firebase
  Firebase.setJSON(firebaseData, DATABASE_PATH);
}

String getGasStatus(int aqi) {
  if (aqi <= 50) return "GOOD";
  if (aqi <= 100) return "SATISFACTORY";
  if (aqi <= 200) return "MODERATE";
  if (aqi <= 300) return "POOR";
  if (aqi <= 400) return "VERY_POOR";
  return "SEVERE";
}

String getLightStatus(int lightLevel) {
  return lightLevel > 500 ? "DAY" : "NIGHT";
}
```

---

## 🔧 Firebase Rules for Database

```json
{
  "rules": {
    "device_id": {
      "garden": {
        "live": {
          ".read": true,
          ".write": "auth != null"
        }
      }
    }
  }
}
```

---

## 🎨 Theme Colors (Dashboard & PDF)

```typescript
const THEME = {
  primary: [34, 197, 94],       // Green-500 (#22c55e)
  primaryDark: [21, 128, 61],  // Green-700 (#15803d)
  secondary: [16, 185, 129],   // Emerald-500 (#10b981)
  accent: [251, 191, 36],     // Amber-400 (#fbbf24)
  text: [30, 41, 59],          // Slate-800 (#1e293b)
  textLight: [148, 163, 184], // Slate-300 (#94a3b8)
  bgLight: [255, 255, 255],    // White (#ffffff)
  bgGray: [249, 250, 251],   // Slate-50 (#f9fafb)
  danger: [239, 68, 68],     // Red-500 (#ef4444)
  success: [34, 197, 94],      // Green-500 (#22c55e)
  warning: [251, 191, 36],   // Amber-400 (#fbbf24)
}
```

---

## 📊 Dashboard Data Display

### Data Flow

```
Firebase Realtime Database (/device_id/garden/live)
    ↓
    Firebase onValue event
    ↓
    useGardenData() hook (dashboard.tsx)
    ↓
    Display Data → Update charts
```

### Update Frequency

- **Real-time updates**: Firebase Realtime Database triggers immediately on data change
- **No polling**: Uses Firebase SDK's real-time listeners
- **Automatic re-render**: React state updates on data change

---

## 📤 Export Formats

### CSV Export

```typescript
exportToCSV(data: GardenData[], filename: string)
```

**CSV Columns:**
1. Timestamp
2. Date
3. Time
4. Temperature (°C)
5. Humidity (%)
6. Device ID
7. Light Status
8. AQI
9. Air Quality Status

### PDF Export

```typescript
exportToPDF(data: GardenData[], deviceInfo?: DeviceInfo, options?: PDFExportOptions)
```

**PDF Contents:**
1. Report header with live timestamp
2. Device information (if multi-device mode)
3. Status summary cards (4 cards)
4. Historical data table (up to 50 records)
5. Page numbers
6. Footer with report ID

---

## 🚨 Important Notes

### Data Accuracy

- **Timestamp**: Always use `Date.now()` for live time
- **Synchronization**: Firebase provides real-time sync without manual refresh
- **Demo Mode**: Shows realistic data when no Firebase connection

### Security

- **Admin Protection**: AARUTO account cannot be deleted or modified
- **Device IDs**: Unique per device, used for login
- **Passwords**: Stored in localStorage (client-side only)
- **Reset Functionality**: Admin can reset all devices except admin account

### Performance

- **Real-time Updates**: Firebase Realtime Database SDK
- **No Polling Required**: Listeners automatically trigger on data changes
- **Efficient Rendering**: React hooks optimize re-renders

---

## 🖥 Application Routes

| Route | Purpose | Access |
|-------|---------|--------|
| `/` | Main Dashboard | All authenticated users |
| `/admin` | Admin Console | AARUTO account only |
| `/login` | Login Page | Public |
| `/signup` | Device Registration | Public |

---

## 🗄️ Storage Locations

### Client Storage (Browser)

```typescript
// Device/User accounts
localStorage.setItem('garden_users', JSON.stringify(users))

// Current session
sessionStorage.setItem('garden_current_user', JSON.stringify(currentUser))
```

### Firebase Realtime Database

```
/device_id/garden/live/    ← Main sensor data (real-time updates)
```

---

## 📦 Summary

### Core Data Structure

```
Smart Garden System
├── Firebase Realtime Database
│   └── /device_id/garden/live/
│       └── Sensor Data (real-time updates)
├── Client Storage
│   ├── User Accounts (localStorage)
│   └── Current Session (sessionStorage)
└── Features
    ├── Device Authentication (Device ID = Username)
    ├── Admin Console (AARUTO)
    ├── Data Export (CSV/PDF)
    └── Multi-device Support
```

### Key Points

✅ **Device-specific Data Paths**: `/device_id/garden/live/DEVICE001` for device "DEVICE001"
✅ **Real-time Sync**: Firebase SDK listeners automatically update UI
✅ **Device-based Auth**: Device ID = Username for easy ESP8266 integration
✅ **Admin Protection**: AARUTO account fully protected
✅ **Multi-device**: Support for multiple device registrations
✅ **Data Export**: Both CSV and PDF formats with live timestamps
✅ **Responsive UI**: Mobile-first design with green theme
✅ **Demo Mode**: Shows realistic data when no sensor connection

---

## 📞 Support & Contact

**Admin**: AARUTO
**Email**: aaruto@admin.smartgarden
**Managed by**: AARUTO (Smart Garden Pro Team)

---

*This documentation reflects complete device-specific Firebase data structure for Smart Garden Monitoring System.*
