/*
 * ESP8266 Firebase Realtime Database Connection
 * Sends sensor data to Firebase at garden/live path
 */

#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>
#include "MQ135.h"

// ===== WIFI CREDENTIALS =====
const char* ssid = "VIPIN";
const char* password = "@@@@@@@@";

// ===== FIREBASE CREDENTIALS =====
#define FIREBASE_HOST "rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
#define FIREBASE_AUTH "9gPXcUYJty4rjU05k1mBDEUUnXEyt9SQKB1nQTRz"

// ===== SENSOR CONFIGURATION =====
#define SENSOR_UPDATE_INTERVAL 5000  // Update every 5 seconds

// ===== OBJECTS =====
WiFiClient wifiClient;
FirebaseData firebaseData;
Adafruit_AHTX0 aht;

// ===== SENSOR DATA STRUCTURE =====
struct SensorData {
  float temperature;      // Celsius
  float humidity;        // Percentage (0-100)
  float gasPPM;          // PPM
  int gasAQI;            // AQI (0-500)
  String gasStatus;       // "GOOD", "MODERATE", "POOR", "DANGEROUS"
  String lightStatus;     // "DAY", "NIGHT"
  String gardenLight;     // "ON", "OFF"
  unsigned long timestamp; // Milliseconds since epoch
};

SensorData sensorData;

// ===== FUNCTION PROTOTYPES =====
void setupWiFi();
void readSensors();
void determineGasStatus();
void sendToFirebase();

// ===== SETUP =====
void setup() {
  // Initialize Serial
  Serial.begin(115200);
  Serial.println("\n");
  Serial.println("========================================");
  Serial.println("  SMART GARDEN IoT ESP8266");
  Serial.println("========================================\n");

  // Initialize I2C for AHT sensor
  Wire.begin();

  // Initialize AHT sensor
  if (!aht.begin()) {
    Serial.println("Could not find AHT sensor!");
    while (1) delay(10);
  }

  // Initialize WiFi
  setupWiFi();

  // Initialize Firebase
  Serial.println("Initializing Firebase...");
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
  firebaseData.setConnectionTimeout(5000);

  Serial.println("Firebase initialized!");
  Serial.print("Firebase Host: ");
  Serial.println(FIREBASE_HOST);
  Serial.print("Database Path: garden/live\n");
  Serial.println("========================================\n");

  // Initial sensor reading
  readSensors();
  sendToFirebase();
}

// ===== MAIN LOOP =====
void loop() {
  // Read all sensors
  readSensors();

  // Send to Firebase
  sendToFirebase();

  // Wait before next reading
  delay(SENSOR_UPDATE_INTERVAL);
}

// ===== SETUP WIFI =====
void setupWiFi() {
  Serial.println("Connecting to WiFi...");

  WiFi.begin(ssid, password);

  // Wait for connection
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected!");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWiFi connection failed!");
    while (1) delay(10);
  }
}

// ===== READ SENSORS =====
void readSensors() {
  Serial.println("----------------------------------------");
  Serial.println("Reading Sensors...");

  // Read temperature and humidity from AHT sensor
  sensors_event_t humidityEvent = aht.getHumiditySensorData();
  sensors_event_t tempEvent = aht.getTemperatureSensorData();

  sensorData.temperature = tempEvent.temperature;
  sensorData.humidity = humidityEvent.relative_humidity;

  // Read gas PPM from MQ135 and calculate AQI
  float rawPPM = mq135_sensor.getPPM();
  sensorData.gasPPM = rawPPM;

  // AQI calculation (0-500 scale based on PPM)
  sensorData.gasAQI = map(constrain(rawPPM, 0, 1000), 0, 500);

  // Determine light status (using same pin as gas for now)
  // LDR will be on a separate pin in your setup
  int lightValue = analogRead(A0);
  sensorData.lightStatus = (lightValue > 512) ? "DAY" : "NIGHT";

  // Determine garden light status
  sensorData.gardenLight = (sensorData.lightStatus == "NIGHT") ? "ON" : "OFF";

  // Get current timestamp
  sensorData.timestamp = millis();

  // Print sensor readings
  Serial.println("Sensor Readings:");
  Serial.print("  Temperature: ");
  Serial.print(sensorData.temperature);
  Serial.println(" °C");
  Serial.print("  Humidity: ");
  Serial.print(sensorData.humidity);
  Serial.println(" %");
  Serial.print("  Gas PPM: ");
  Serial.println(sensorData.gasPPM);
  Serial.print("  Gas AQI: ");
  Serial.println(sensorData.gasAQI);
  Serial.print("  Gas Status: ");
  Serial.println(sensorData.gasStatus);
  Serial.print("  Light Status: ");
  Serial.println(sensorData.lightStatus);
  Serial.print("  Garden Light: ");
  Serial.println(sensorData.gardenLight);
  Serial.print("  Timestamp: ");
  Serial.println(sensorData.timestamp);
  Serial.println("----------------------------------------\n");
}

// ===== DETERMINE GAS STATUS =====
void determineGasStatus() {
  // AQI-based status determination
  if (sensorData.gasAQI < 50) {
    sensorData.gasStatus = "GOOD";
  } else if (sensorData.gasAQI < 100) {
    sensorData.gasStatus = "MODERATE";
  } else if (sensorData.gasAQI < 200) {
    sensorData.gasStatus = "POOR";
  } else {
    sensorData.gasStatus = "DANGEROUS";
  }
}

// ===== SEND TO FIREBASE =====
void sendToFirebase() {
  Serial.println("Sending to Firebase...");

  // Create Firebase JSON object
  FirebaseJson json;

  // Add all required fields
  json.add("temperature", sensorData.temperature);
  json.add("humidity", sensorData.humidity);
  json.add("gasPPM", sensorData.gasPPM);
  customAdd(json, "gasLevel", (int)sensorData.gasPPM);
  json.add("gasAQI", sensorData.gasAQI);
  json.add("gasStatus", sensorData.gasStatus);
  json.add("lightStatus", sensorData.lightStatus);
  json.add("gardenLight", sensorData.gardenLight);
  json.add("timestamp", sensorData.timestamp);

  // Send to Firebase at garden/live path
  if (Firebase.setJSON(firebaseData, "/garden/live", json)) {
    Serial.println("Data sent successfully!");
    Serial.println("HTTP response code: " + String(firebaseData.httpCode()));
  } else {
    Serial.println("Failed to send data!");
    Serial.println("HTTP response code: " + String(firebaseData.httpCode()));
    Serial.println("Reason: " + firebaseData.errorReason());
  }

  Serial.println("----------------------------------------\n");
}

// ===== HELPER FUNCTION =====
void customAdd(FirebaseJson& json, const String& key, int value) {
  // Helper to add integer to FirebaseJson
  json.set(key.c_str(), value);
}
