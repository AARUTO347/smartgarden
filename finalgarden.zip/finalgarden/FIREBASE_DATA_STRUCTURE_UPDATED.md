# Firebase Data Structure - Updated

## Firebase Path
```
garden/live
```

## Current Data Structure

```json
{
  "garden": {
    "live": {
      "gasLevel": 284,
      "aqi": 94,
      "gasStatus": "MODERATE",
      "humidity": 62.1,
      "temperature": 28.0,
      "lightStatus": "NIGHT",
      "timestamp": 5124
    }
  }
}
```

## Field Descriptions

| Field | Type | Range/Values | Description |
|-------|------|--------------|-------------|
| `gasLevel` | integer | 0 to 1000 | Raw gas sensor level |
| `aqi` | integer | 0 to 500 | **Air Quality Index** - PRIMARY FIELD |
| `gasStatus` | string | "GOOD", "MODERATE", "POOR", "DANGEROUS" | Air quality status based on AQI |
| `humidity` | float | 0 to 100% | Relative humidity percentage |
| `temperature` | float | -40 to 85°C | Temperature in Celsius |
| `lightStatus` | string | "DAY", "NIGHT" | Day/Night cycle status |
| `timestamp` | number | Any number | Time identifier |

## Supported Field Aliases (for backward compatibility)

The dashboard supports multiple field names for AQI:
- `aqi` (PRIMARY - matches new Firebase structure)
- `gasAQI` (backward compatibility)
- `gasLevel` (fallback - raw sensor value)

## Data Flow

```
ESP8266 → Firebase (garden/live) → Dashboard
           ↓
    {
      "gasLevel": 284,
      "aqi": 94,
      "gasStatus": "MODERATE",
      "humidity": 62.1,
      "temperature": 28.0,
      "lightStatus": "NIGHT",
      "timestamp": 5124
    }
```

## AQI Reference

| AQI Range | Status | Color | Meaning |
|-----------|--------|-------|---------|
| 0-50 | GOOD | 🟢 Green | Air quality is satisfactory |
| 51-100 | MODERATE | 🟡 Yellow | Acceptable quality for most people |
| 101-200 | POOR | 🟠 Orange | Sensitive groups may be affected |
| 201-500 | DANGEROUS | 🔴 Red | Everyone may experience health effects |

## ESP8266 Firebase Sending Example

```cpp
// Send data to Firebase
FirebaseJson json;
json.add("gasLevel", sensorData.gasLevel);
json.add("aqi", sensorData.aqi);
json.add("gasStatus", sensorData.gasStatus);
json.add("humidity", sensorData.humidity);
json.add("temperature", sensorData.temperature);
json.add("lightStatus", sensorData.lightStatus);
json.add("timestamp", sensorData.timestamp);

Firebase.setJSON(firebaseData, "/garden/live", json);
```

## Dashboard Components Using This Data

### 1. AQI Status Card
- Shows `aqi` value (94)
- Displays `gasStatus` (MODERATE)
- Color-coded based on status

### 2. Temperature Card
- Shows `temperature` (28.0°C)
- Unit: °C

### 3. Humidity Card
- Shows `humidity` (62.1%)
- Unit: %

### 4. Light Status Card
- Shows `lightStatus` (NIGHT)
- Icon changes based on DAY/NIGHT

### 5. Charts
- Historical AQI trends (using `aqi` field)
- Temperature & Humidity trends
- Last 100 readings displayed

### 6. CSV Export
- Exports all fields including `aqi`
- Headers: Timestamp, Date, Time, Temperature (°C), Humidity (%), Light Status, Garden Light, AQI, Air Quality Status

## Example Data Sets

### Example 1: Good Air Quality
```json
{
  "gasLevel": 150,
  "aqi": 47,
  "gasStatus": "GOOD",
  "humidity": 65.0,
  "temperature": 26.5,
  "lightStatus": "DAY",
  "timestamp": 12345
}
```

### Example 2: Moderate Air Quality
```json
{
  "gasLevel": 284,
  "aqi": 94,
  "gasStatus": "MODERATE",
  "humidity": 62.1,
  "temperature": 28.0,
  "lightStatus": "NIGHT",
  "timestamp": 5124
}
```

### Example 3: Poor Air Quality
```json
{
  "gasLevel": 450,
  "aqi": 182,
  "gasStatus": "POOR",
  "humidity": 70.0,
  "temperature": 25.8,
  "lightStatus": "DAY",
  "timestamp": 6789
}
```

### Example 4: Dangerous Air Quality
```json
{
  "gasLevel": 680,
  "aqi": 342,
  "gasStatus": "DANGEROUS",
  "humidity": 62.0,
  "temperature": 27.2,
  "lightStatus": "DAY",
  "timestamp": 9012
}
```

## Notes

- **Primary AQI field is `aqi`** (matching new Firebase structure)
- `gasLevel` contains raw sensor reading for reference
- Dashboard automatically falls back to `gasAQI` or `gasLevel` if `aqi` is missing
- All status types are supported: GOOD, MODERATE, POOR, DANGEROUS
- Path in Firebase: `rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app/garden/live`
- Update frequency: Recommended every 5 seconds (5000ms)
- The dashboard now matches your Firebase structure exactly!

## Testing

### Using Firebase Console
1. Go to Firebase Console
2. Navigate to Realtime Database
3. Find `garden/live` path
4. You can manually add/test data using the JSON structure above

### Expected Dashboard Behavior
- When data is received, dashboard will immediately show:
  - AQI: 94 (with yellow MODERATE badge)
  - Temperature: 28.0°C
  - Humidity: 62.1%
  - Light Status: NIGHT (with moon icon)
  - Garden Light: ON or OFF (if available)
  - Charts will update with new AQI reading

### Browser Console Logging
The dashboard logs all data received:
```
📡 Firebase data received: {gasLevel: 284, aqi: 94, ...}
📡 Snapshot exists: true
📡 Valid data received, keys: ["gasLevel", "aqi", "gasStatus", "humidity", "temperature", "lightStatus", "timestamp"]
```

## Troubleshooting

### Data Not Showing
1. Check Firebase path: `/garden/live`
2. Verify field names match exactly (`aqi`, not `AQI`)
3. Check browser console for errors
4. Confirm Firebase rules allow read access

### Wrong AQI Displaying
1. Ensure `aqi` field is present (not just `gasLevel`)
2. Check `gasStatus` matches expected values
3. Verify data format is correct

### Charts Not Updating
1. Wait for multiple readings (charts show last 100)
2. Check historical data is being stored
3. Verify timestamp field is present

---

**Version**: 3.0 (Updated for new Firebase structure)
**Last Updated**: Current Session
**Firebase Path**: `/garden/live`
**Primary AQI Field**: `aqi`
