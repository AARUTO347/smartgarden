# 🔆 LDR (Light Sensor) Integration Guide

## ✅ LDR (Light Dependent Resistor) Added to ESP8266

### New File: `ESP8266_SmartGarden_LDR.ino`

---

## 🔌 What is LDR?

LDR (Light Dependent Resistor) is a sensor that:
- ✅ Detects light intensity
- ✅ Resistance decreases when light increases
- ✅ Analog output (0-1023 on ESP8266)
- ✅ Used for DAY/NIGHT detection

---

## 🔌 LDR Circuit Connection

### ESP8266 Pin Configuration

**LDR Pin**: **A0** (same as D1 on ESP8266)

### Simple Circuit (No Resistor Needed)
Many LDR modules have built-in resistor:

```
LDR Module → ESP8266
─────────────→───────────
  VCC     → 3.3V
  GND     → GND
  OUT     → A0 (Pin 3)
```

### Circuit with Resistor (If Raw LDR)

If you have a bare LDR, use voltage divider:

```
3.3V
  │
  ├─ LDR
  │   └─ A0 (Analog Input)
  │
  └─ Resistor (10kΩ)
      └─ GND
```

---

## 📱 Code Changes Made

### 1. LDR Pin Definition
```cpp
#define LDR_PIN A0             // LDR connected to A0 (same as D1)
#define LIGHT_THRESHOLD 512   // Threshold: >512 = DAY, <=512 = NIGHT
```

### 2. Read LDR Value
```cpp
// READ LDR (LIGHT SENSOR)
int ldrValue = analogRead(LDR_PIN);
Serial.print("  LDR Raw Value: ");
Serial.println(ldrValue);
```

### 3. Determine Light Status
```cpp
// LDR on A0 pin (same as D1 pin on ESP8266)
// Higher LDR value = more light = DAY
// Lower LDR value = less light = NIGHT

if (ldrValue > LIGHT_THRESHOLD) {
  sensorData.lightStatus = "DAY";
  Serial.println("  Light detected: DAY");
} else {
  sensorData.lightStatus = "NIGHT";
  Serial.println("  Light detected: NIGHT");
}
```

### 4. Automatic Garden Light Control
```cpp
// Turn garden light ON at night, OFF during day
if (sensorData.lightStatus == "NIGHT") {
  sensorData.gardenLight = "ON";
} else {
  sensorData.gardenLight = "OFF";
}
```

---

## 🔌 How LDR Works

### Reading Process

1. **ESP8266 reads analog value** from A0 pin
2. **Returns 0-1023** based on light intensity
3. **0 = Dark**, **1023 = Bright**
4. **Compares to threshold** (512)

### Light Detection Logic

| LDR Value | Light Status | Garden Light | Meaning |
|-----------|-------------|-------------|----------|
| 0-512 | NIGHT | ON | Low light detected |
| 513-1023 | DAY | OFF | Sufficient light |

### Threshold Adjustment

**Default**: 512 (midpoint)

**Adjust for your environment**:

```cpp
// For darker environments (turn ON earlier)
#define LIGHT_THRESHOLD 400

// For brighter environments (turn ON later)
#define LIGHT_THRESHOLD 600

// For very dark environments
#define LIGHT_THRESHOLD 300

// For very bright environments
#define LIGHT_THRESHOLD 700
```

---

## 🔌 Wiring Diagram

### Simple LDR Module (Recommended)

```
         ESP8266
         ┌─────┐
3.3V ──┤  1  ├─ 3.3V (Vin)
         │  │     │
         │  │     ├─ A0  (Signal)
GND  ──┤  2  ├─ GND (GND)
         └─────┘
         LDR
         Module
```

### Bare LDR with Voltage Divider

```
              3.3V
                │
                ├──── LDR ────┐
                │              │
                │              ├─ A0
                │              │
                ├──── 10kΩ ──┤
                │              │
                └──────────────┘
               GND
```

---

## 📋 Components Needed

### Option 1: LDR Module (Easiest)
- [ ] LDR Module with built-in resistor
- [ ] Jumper wires (male-to-male)
- [ ] ESP8266

### Option 2: Bare LDR with Resistor
- [ ] LDR (Light Dependent Resistor)
- [ ] Resistor (10kΩ recommended)
- [ ] Breadboard and jumper wires
- [ ] ESP8266

---

## 🚀 Setup Steps

### Step 1: Connect LDR to ESP8266

#### Using LDR Module:
1. Connect module VCC to ESP8266 3.3V
2. Connect module GND to ESP8266 GND
3. Connect module OUT to ESP8266 A0
4. Power on ESP8266

#### Using Bare LDR:
1. Connect one LDR lead to 3.3V
2. Connect other LDR lead to GND through 10kΩ resistor
3. Connect junction point to A0
4. Power on ESP8266

### Step 2: Upload Code

1. Open Arduino IDE
2. Open: `ESP8266_SmartGarden_LDR.ino`
3. Configure WiFi credentials
4. Get Firebase database secret
5. Upload to ESP8266

### Step 3: Test LDR

**Open Serial Monitor** (115200 baud):

```
Reading Sensors...
  LDR Raw Value: 245 (NIGHT)
  Light detected: NIGHT (LDR: 245)

Sending to Firebase...
✅ Temperature sent successfully!
✅ Light status sent successfully!
```

**Test Light Detection**:
1. Cover LDR with hand → Value should drop, show "NIGHT"
2. Expose LDR to light → Value should rise, show "DAY"
3. Garden light should turn ON when dark
4. Garden light should turn OFF when bright

---

## 🔧 Calibration

### Finding Optimal Threshold

1. **Cover LDR** completely with hand
2. **Note raw value** in Serial Monitor (should be low, 0-200)
3. **Expose LDR** to room light
4. **Note raw value** in Serial Monitor (should be medium, 400-700)
5. **Shine flashlight** directly on LDR
6. **Note raw value** in Serial Monitor (should be high, 800-1023)

### Adjust Threshold Based on Readings

```cpp
// If room light reads around 512
#define LIGHT_THRESHOLD 512  // Default

// If room light is darker (reads 300-400)
#define LIGHT_THRESHOLD 350

// If room light is brighter (reads 600-700)
#define LIGHT_THRESHOLD 650
```

---

## 📊 Serial Monitor Output

### What You'll See

```
========================================
  SMART GARDEN ESP8266
  With LDR Light Sensor
========================================

Connecting to WiFi...
....
✅ WiFi connected!
IP Address: 192.168.1.100
SSID: Your_Network_Name

Initializing Firebase...
Firebase initialized!
Firebase Host: rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app
Database Path: /garden/live
LDR Pin: A0 (D1)
========================================

✅ AHT sensor initialized successfully!

Reading Sensors...
  LDR Raw Value: 245
  Light detected: NIGHT (LDR: 245)
Sensor Readings:
  Temperature: 24.5 °C
  Humidity: 68 %
  Gas Level: 120 PPM
  Gas Status: SAFE
  LDR Value: 245 (NIGHT)
  Garden Light: ON
  Timestamp: 1704148800000
Sending to Firebase...
✅ Temperature sent successfully!
✅ Humidity sent successfully!
✅ Gas level sent successfully!
✅ Gas status sent successfully!
✅ Light status sent successfully!
✅ Garden light status sent successfully!
✅ Timestamp sent successfully!
✅ Firebase HTTP response: 200 OK
----------------------------------------
```

---

## 🎨 Dashboard Behavior

### What You'll See in Dashboard

### When LDR Detects NIGHT:
- ✅ Light Status: **NIGHT** (Moon icon 🌙)
- ✅ Garden Light: **ON** (Green badge)
- ✅ Light Status color: Blue
- ✅ Garden Light color: Green

### When LDR Detects DAY:
- ✅ Light Status: **DAY** (Sun icon ☀️)
- ✅ Garden Light: **OFF** (Gray badge)
- ✅ Light Status color: Yellow
- ✅ Garden Light color: Gray

### Automatic Behavior:
1. **Room gets dark** → LDR value drops → Shows "NIGHT" → Garden light turns ON
2. **Room gets bright** → LDR value rises → Shows "DAY" → Garden light turns OFF
3. **Every 5 seconds** → LDR read → Status updated → Firebase updated

---

## 🎯 Expected LDR Values

| Light Condition | LDR Value | Light Status | Garden Light |
|---------------|------------|-------------|-------------|
| Very Dark | 0-100 | NIGHT | ON |
| Dim Room | 100-400 | NIGHT | ON |
| Normal Room | 400-512 | NIGHT | ON |
| Bright Room | 513-700 | DAY | OFF |
| Very Bright | 701-900 | DAY | OFF |
| Direct Light | 901-1023 | DAY | OFF |

---

## 🔍 Troubleshooting

### Problem 1: LDR Always Reads 0

**Cause**: Wrong pin or circuit

**Solution**:
1. Verify LDR connected to A0
2. Check LDR module power (3.3V)
3. Check GND connection

### Problem 2: Light Not Updating

**Cause**: LDR disconnected or not reading

**Solution**:
1. Check Serial Monitor for LDR value
2. Verify LDR changes when you cover/uncover it
3. Check connections

### Problem 3: Always Shows DAY or NIGHT

**Cause**: Threshold too high or too low

**Solution**:
1. Note actual LDR values in Serial Monitor
2. Adjust LIGHT_THRESHOLD in code
3. Re-upload code
4. Test again

### Problem 4: Erratic Readings

**Cause**: Loose connection or interference

**Solution**:
1. Check all connections
2. Add small capacitor (0.1µF) to A0 pin for stability
3. Keep wires short

---

## 📱 Code Reference

### Pin Definitions
```cpp
#define LDR_PIN A0             // LDR sensor pin
#define LIGHT_THRESHOLD 512   // Day/Night threshold
```

### Reading LDR
```cpp
int ldrValue = analogRead(LDR_PIN);
determineLightStatus(ldrValue);
```

### Light Status Logic
```cpp
void determineLightStatus(int ldrValue) {
  if (ldrValue > LIGHT_THRESHOLD) {
    sensorData.lightStatus = "DAY";
  } else {
    sensorData.lightStatus = "NIGHT";
  }
}
```

---

## ✅ Complete Setup Checklist

### Hardware:
- [ ] LDR connected to A0 pin
- [ ] LDR VCC connected to 3.3V
- [ ] LDR GND connected to GND
- [ ] If bare LDR: 10kΩ resistor in place

### Software:
- [ ] `ESP8266_SmartGarden_LDR.ino` opened
- [ ] WiFi SSID and password configured
- [ ] Firebase database secret added
- [ ] Code uploaded to ESP8266
- [ ] Serial Monitor open (115200 baud)

### Testing:
- [ ] Cover LDR → Shows "NIGHT"
- [ ] Expose LDR → Shows "DAY"
- [ ] Garden light turns ON/OFF automatically
- [ ] Firebase receives light status
- [ ] Dashboard shows correct status

### Dashboard:
- [ ] Light status updates in real-time
- [ ] Garden light status correct
- [ ] No yellow demo banner
- [ ] All 7 fields displaying

---

## 🎉 Summary

**What Was Added:**
1. ✅ LDR (Light Dependent Resistor) sensor integration
2. ✅ Pin D1/A0 configuration
3. ✅ Real-time light detection (DAY/NIGHT)
4. ✅ Automatic garden light control
5. ✅ Threshold-based switching
6. ✅ Serial Monitor logging of LDR values

**How It Works:**
1. ✅ LDR reads light intensity every 5 seconds
2. ✅ Determines if it's DAY or NIGHT
3. ✅ Automatically controls garden light
4. ✅ Sends status to Firebase
5. ✅ Dashboard displays in real-time

**Files:**
- `ESP8266_SmartGarden_LDR.ino` - Complete code with LDR

**Next Steps:**
1. Connect LDR to A0 pin
2. Upload code to ESP8266
3. Test light detection (cover/uncover LDR)
4. Verify dashboard shows correct status
5. Adjust threshold if needed

**Your Smart Garden now has automatic light detection and garden light control!** 🌱✨
