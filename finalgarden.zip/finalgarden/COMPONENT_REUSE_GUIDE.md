# 🎨 Component Export & Reuse Guide

Quick reference for copying components to new projects and customizing them.

## 📦 Files to Copy

### For a Complete Dashboard Clone:

```
src/
├── components/
│   ├── dashboard.tsx                 # Main dashboard component
│   ├── data-charts.tsx               # Charts visualization
│   ├── world-clock.tsx               # Optional: World clock widget
│   ├── login.tsx                     # Authentication UI
│   ├── signup.tsx                    # Registration UI
│   └── ui/                           # shadcn/ui components
│       ├── card.tsx
│       ├── button.tsx
│       ├── badge.tsx
│       ├── progress.tsx
│       ├── chart.tsx
│       └── ... (other UI components)
├── lib/
│   ├── app-logic.ts                  # Data structures & helpers
│   ├── csv-export.ts                 # Export functionality
│   ├── pdf-export.ts                 # PDF generation
│   └── user-store.ts                 # Authentication logic
├── hooks/
│   ├── use-session.ts                # Session management
│   └── use-toast.ts                  # Toast notifications
└── app/
    ├── layout.tsx                    # Root layout with logo
    ├── page.tsx                      # Home page
    └── globals.css                   # Global styles
```

---

## 🚀 Quick Copy Commands

### Copy Dashboard Component
```bash
cp src/components/dashboard.tsx ../my-new-project/src/components/

# Also copy dependencies:
cp src/components/data-charts.tsx ../my-new-project/src/components/
cp src/components/ui/* ../my-new-project/src/components/ui/
cp src/lib/app-logic.ts ../my-new-project/src/lib/
```

### Copy UI Component Library
```bash
# Copy all shadcn/ui components
cp -r src/components/ui/ ../my-new-project/src/components/

# Copy utilities
cp src/lib/utils.ts ../my-new-project/src/lib/
```

### Copy Entire Component System
```bash
# Full backup before modifying
cp -r src/ ../my-new-project/src/
```

---

## 🎯 Individual Component Reference

### 1. Dashboard Component

**File:** `src/components/dashboard.tsx`  
**Size:** ~1400 lines  
**Dependencies:**
- React, useState, useEffect, useMemo
- lucide-react (icons)
- recharts (charts)
- shadcn/ui (Card, Button, Badge, Progress)
- Custom hooks (useSession, useToast, useGardenData)

**Exports:**
- `Dashboard` (default) - Main component
- `SensorCard` - Display sensor data
- `QuickStatCard` - Quick stats display
- `RecommendationCard` - Smart recommendations
- `DataFieldProps` - Data display interface
- `RecommendationCardProps` - Recommendation interface

**Usage:**
```tsx
import Dashboard from '@/components/dashboard'

<Dashboard 
  username="John"
  isAdmin={false}
  deviceId="device-123"
  onLogout={handleLogout}
/>
```

---

### 2. Data Charts Component

**File:** `src/components/data-charts.tsx`  
**Size:** ~300 lines  
**Dependencies:**
- Recharts (LineChart, BarChart, Line, Bar)
- shadcn/ui (Card, CardHeader, CardTitle, CardContent)
- lucide-react (icons)

**Features:**
- Temperature trend chart
- Humidity level chart
- Gas quality monitoring
- Demo data generation
- Responsive design

**Props:**
```typescript
interface DataChartsProps {
  gardenData: GardenData
  historicalData?: GardenData[]
}
```

**Usage:**
```tsx
import DataCharts from '@/components/data-charts'

<DataCharts 
  gardenData={currentData}
  historicalData={pastData}
/>
```

---

### 3. Card Components (UI Library)

**File:** `src/components/ui/card.tsx`  
**Exports:**
- `Card` - Main container
- `CardHeader` - Title section
- `CardTitle` - Title text
- `CardDescription` - Subtitle text
- `CardContent` - Content area
- `CardFooter` - Footer area
- `CardAction` - Action buttons area

**Usage:**
```tsx
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'

<Card>
  <CardHeader>
    <CardTitle>Title</CardTitle>
  </CardHeader>
  <CardContent>
    Content goes here
  </CardContent>
</Card>
```

---

### 4. Chart Component

**File:** `src/components/ui/chart.tsx`  
**Exports:**
- `ChartContainer` - Wraps Recharts
- `ChartStyle` - Styling context
- `ChartLegend` - Legend component
- `ChartTooltip` - Interactive tooltip
- `ChartConfig` - Type definitions

**Usage:**
```tsx
import { ChartContainer } from '@/components/ui/chart'
import { LineChart, Line } from 'recharts'

const chartConfig = {
  temperature: { label: 'Temperature', color: 'hsl(0, 84%, 60%)' }
}

<ChartContainer config={chartConfig}>
  <LineChart data={data}>
    <Line dataKey="temperature" stroke={chartConfig.temperature.color} />
  </LineChart>
</ChartContainer>
```

---

## 🎨 Styling Reference

### Glassmorphism Design System

**Primary Pattern:**
```tsx
className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300"
```

**Variations:**
```tsx
// Darker
className="bg-white/20 border-white/30"

// Lighter
className="bg-white/5 border-white/10"

// With glow
className="shadow-lg shadow-green-500/20"

// With scale animation
className="hover:scale-105 hover:-translate-y-1"
```

### Color Classes

**Status Indicators:**
```tsx
// Success
"text-green-400", "bg-green-500/10", "border-green-500/20"

// Warning
"text-yellow-400", "bg-yellow-500/10", "border-yellow-500/20"

// Error/Critical
"text-red-400", "bg-red-500/10", "border-red-500/20"

// Info
"text-blue-400", "bg-blue-500/10", "border-blue-500/20"

// Temperature
"text-orange-400", "bg-orange-500/10", "border-orange-500/20"

// Humidity
"text-cyan-400", "bg-cyan-500/10", "border-cyan-500/20"
```

### Responsive Classes

```tsx
// Mobile first
grid-cols-1        // Mobile: single column

// Tablet
sm:grid-cols-2     // 640px+: two columns

// Desktop
md:grid-cols-3     // 768px+: three columns
lg:grid-cols-4     // 1024px+: four columns
xl:grid-cols-6     // 1280px+: six columns
```

---

## 🔧 Customization Patterns

### Pattern 1: Change Color Scheme

**Before:**
```tsx
color="text-orange-400"
bgColor="bg-orange-500/10 border-orange-500/20"
```

**After (Purple):**
```tsx
color="text-purple-400"
bgColor="bg-purple-500/10 border-purple-500/20"
```

### Pattern 2: Adjust Card Styling

**Before:**
```tsx
className="backdrop-blur-xl bg-white/10 border-white/20"
```

**After (More transparent):**
```tsx
className="backdrop-blur-xl bg-white/5 border-white/5"
```

**After (Less transparent):**
```tsx
className="backdrop-blur-xl bg-black/40 border-white/40"
```

### Pattern 3: Modify Grid Layout

**Before:**
```tsx
className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
```

**After (3 columns on desktop):**
```tsx
className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
```

### Pattern 4: Change Icon Size

**Before:**
```tsx
<Thermometer className="w-14 h-14" />
```

**After (Smaller):**
```tsx
<Thermometer className="w-8 h-8" />
```

**After (Larger):**
```tsx
<Thermometer className="w-16 h-16" />
```

---

## 📊 Data Structure Patterns

### GardenData Interface
```typescript
interface GardenData {
  temperature?: number      // Celsius
  humidity?: number         // Percentage (0-100)
  lightStatus?: 'DAY' | 'NIGHT'
  gasAQI?: number          // AQI value
  gasStatus?: 'Good' | 'Moderate' | 'Poor' | 'Very Poor' | 'Severe'
  aqi?: number             // Alternative AQI field
  timestamp?: number       // Unix timestamp
}
```

### Chart Data Format
```typescript
interface ChartDataPoint {
  name: string             // Label (time, date)
  temperature?: number
  humidity?: number
  aqi?: number
  [key: string]: any       // Flexible for additional fields
}
```

### Quick Stat Format
```typescript
interface QuickStat {
  icon: React.ReactNode
  title: string           // e.g., "Connection"
  value: string          // e.g., "Excellent"
  color: string          // e.g., "text-green-400"
  bgColor: string        // e.g., "bg-green-500/10 border-green-500/20"
}
```

---

## 🔌 Hook Dependencies

### useSession Hook
**File:** `src/hooks/use-session.ts`

```typescript
interface SessionContext {
  isAuthenticated: boolean
  username: string | null
  deviceId: string | null
  isAdmin: boolean
  isLoading: boolean
  login: (username: string, password: string) => Promise<void>
  logout: () => void
  setUser: (user: User) => void
}

const { isAuthenticated, username, logout } = useSession()
```

### useToast Hook
**File:** `src/hooks/use-toast.ts`

```typescript
interface Toast {
  id: string
  title: string
  description?: string
  action?: ToastAction
}

const { toast } = useToast()

// Usage
toast({
  title: "Success",
  description: "Data saved successfully"
})
```

### useGardenData Hook
**File:** `src/lib/app-logic.ts`

```typescript
const { 
  data, 
  historicalData, 
  isDemo, 
  refresh 
} = useGardenData(deviceId)
```

---

## 🎯 Common Modifications

### Add New Sensor Card
```tsx
// In dashboard.tsx, find sensor cards section and add:
<SensorCard
  icon={<YourIcon className="w-14 h-14" />}
  title="New Sensor"
  value={newValue}
  unit="unit"
  color="text-[color]-400"
  bgColor="bg-[color]-500/10 border-[color]-500/20"
  description="Your description"
  trend="normal"
/>
```

### Add New Chart
```tsx
// In data-charts.tsx, add to the charts section:
<Card>
  <CardHeader>
    <CardTitle>New Chart Title</CardTitle>
  </CardHeader>
  <CardContent>
    <ChartContainer config={chartConfig}>
      <YourChart data={data}>
        {/* Chart elements */}
      </YourChart>
    </ChartContainer>
  </CardContent>
</Card>
```

### Add New View Tab
```tsx
// In dashboard.tsx view toggle section:
{['dashboard', 'charts', 'data', 'system', 'new-view'].map((v) => (
  <Button
    key={v}
    variant={isActive ? 'default' : 'outline'}
    onClick={() => setView(v as any)}
  >
    New View
  </Button>
))}

// Then add the view content:
{view === 'new-view' && (
  <div>Your new view content</div>
)}
```

---

## 📱 Mobile Responsive Breakpoints

```css
/* Tailwind breakpoints used in components */
sm: 640px       /* Small devices - tablets portrait */
md: 768px       /* Medium devices - tablets landscape */
lg: 1024px      /* Large devices - laptops */
xl: 1280px      /* Extra large - desktops */
2xl: 1536px     /* Ultra wide - large monitors */
```

**Pattern:**
```tsx
// Default (mobile): 1 column
// sm: (tablet): 2 columns  
// lg: (desktop): 4 columns
className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
```

---

## ✅ Pre-Flight Checklist for New Project

Before using components in a new project:

- [ ] Install Next.js 15+
- [ ] Install React 19+
- [ ] Install Tailwind CSS 4+
- [ ] Install required dependencies:
  ```json
  {
    "recharts": "^2.0+",
    "lucide-react": "^latest",
    "@radix-ui/react-*": "^latest",
    "zod": "^3.0+",
    "react-hook-form": "^7.0+"
  }
  ```
- [ ] Configure Tailwind CSS
- [ ] Copy UI components
- [ ] Copy hooks
- [ ] Copy lib utilities
- [ ] Update imports in components
- [ ] Test component rendering
- [ ] Check responsiveness on mobile
- [ ] Verify styling loads correctly

---

## 🚀 Deploy Checklist

- [ ] All components render without errors
- [ ] Logo displays in browser tab
- [ ] Responsive on all screen sizes
- [ ] Dark theme works (or adjust for your theme)
- [ ] All icons render
- [ ] Charts display correctly
- [ ] Build passes: `bun run build`
- [ ] No TypeScript errors
- [ ] netlify.toml is present
- [ ] Environment variables set (if needed)
- [ ] Security headers configured

---

**Last Updated:** February 16, 2026  
**Version:** 1.0  
**Component Library Status:** Production Ready ✅
