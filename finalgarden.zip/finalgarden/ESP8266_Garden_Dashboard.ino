/*
 * ESP8266 Smart Garden Firebase Sender
 * Complete code for Smart Garden Dashboard
 *
 * This code sends all 7 required fields to Firebase:
 * - temperature (number)
 * - humidity (number)
 * - gasLevel (number)
 * - gasStatus (string)
 * - lightStatus (string)
 * - gardenLight (string)
 * - timestamp (number)
 *
 * Firebase Path: /garden/live
 * Update Interval: 5 seconds
 */

#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <Wire.h>

// ===== WIFI CREDENTIALS =====
// CHANGE THESE TO YOUR WIFI NETWORK
const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ===== FIREBASE CREDENTIALS =====
#define FIREBASE_HOST "rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
#define FIREBASE_AUTH "YOUR_FIREBASE_DATABASE_SECRET"

// Firebase Database Secret (Get from Firebase Console)
// Steps:
// 1. Go to https://console.firebase.google.com/
// 2. Select project: rfid-aaruto
// 3. Go to Project Settings
// 4. Service Accounts
// 5. Database Secrets
// 6. Copy the database secret
// 7. Paste it below in quotes: "your-secret-here"

// ===== SENSOR CONFIGURATION =====
#define UPDATE_INTERVAL 5000  // Update every 5 seconds (5000 ms)

// ===== OBJECTS =====
WiFiClient wifiClient;
FirebaseData firebaseData;

// ===== SENSOR DATA STRUCTURE =====
struct SensorData {
  float temperature;      // Celsius
  float humidity;        // Percentage (0-100)
  int gasLevel;          // PPM (0-1023)
  String gasStatus;       // "SAFE", "WARNING", "DANGER"
  String lightStatus;     // "DAY", "NIGHT"
  String gardenLight;     // "ON", "OFF"
  unsigned long timestamp; // Milliseconds since epoch
};

SensorData sensorData;

// ===== FUNCTION PROTOTYPES =====
void setupWiFi();
void readSensors();
void determineGasStatus();
void determineLightStatus();
void determineGardenLight();
void sendToFirebase();
unsigned long getCurrentTimestamp();

// ===== SETUP =====
void setup() {
  // Initialize Serial
  Serial.begin(115200);
  Serial.println("\n");
  Serial.println("========================================");
  Serial.println("  SMART GARDEN ESP8266");
  Serial.println("========================================\n");

  // Setup WiFi
  setupWiFi();

  // Initialize Firebase
  Serial.println("Initializing Firebase...");
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
  firebaseData.setConnectionTimeout(5000); // 5 second timeout

  Serial.println("Firebase initialized!");
  Serial.print("Firebase Host: ");
  Serial.println(FIREBASE_HOST);
  Serial.print("Database Path: /garden/live\n");
  Serial.println("========================================\n");

  // Initial sensor reading
  readSensors();
  sendToFirebase();
}

// ===== MAIN LOOP =====
void loop() {
  // Read all sensors
  readSensors();

  // Send to Firebase
  sendToFirebase();

  // Wait before next reading
  delay(UPDATE_INTERVAL);
}

// ===== SETUP WIFI =====
void setupWiFi() {
  Serial.println("Connecting to WiFi...");

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  // Wait for connection
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✅ WiFi connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
    Serial.print("SSID: ");
    Serial.println(WiFi.SSID());
  } else {
    Serial.println("\n❌ WiFi connection failed!");
    Serial.println("Please check your WiFi credentials");
  }

  Serial.println("");
}

// ===== READ SENSORS =====
void readSensors() {
  Serial.println("----------------------------------------");
  Serial.println("Reading Sensors...");

  // 1. READ TEMPERATURE
  // Replace with your actual sensor reading
  // Example: using DHT22, AHT, or DS18B20
  // For now, use random values for testing
  sensorData.temperature = 20.0 + (rand() % 15); // 20-35°C

  // 2. READ HUMIDITY
  // Replace with your actual sensor reading
  sensorData.humidity = 40.0 + (rand() % 40); // 40-80%

  // 3. READ GAS LEVEL
  // Replace with actual gas sensor reading (analog pin A0)
  // int gasValue = analogRead(A0);
  sensorData.gasLevel = 50 + (rand() % 300); // 50-350 PPM

  // 4. DETERMINE GAS STATUS
  determineGasStatus();

  // 5. READ LIGHT SENSOR
  // Replace with actual light sensor reading (analog pin A0 or digital pin)
  // int lightValue = analogRead(A0);
  // sensorData.lightStatus = (lightValue > 512) ? "DAY" : "NIGHT";
  int lightValue = rand() % 1024;
  determineLightStatus(lightValue);

  // 6. DETERMINE GARDEN LIGHT STATUS
  determineGardenLight();

  // 7. GET CURRENT TIMESTAMP
  sensorData.timestamp = getCurrentTimestamp();

  // Print sensor readings
  Serial.println("Sensor Readings:");
  Serial.print("  Temperature: ");
  Serial.print(sensorData.temperature);
  Serial.println(" °C");
  Serial.print("  Humidity: ");
  Serial.print(sensorData.humidity);
  Serial.println(" %");
  Serial.print("  Gas Level: ");
  Serial.print(sensorData.gasLevel);
  Serial.println(" PPM");
  Serial.print("  Gas Status: ");
  Serial.println(sensorData.gasStatus);
  Serial.print("  Light Status: ");
  Serial.println(sensorData.lightStatus);
  Serial.print("  Garden Light: ");
  Serial.println(sensorData.gardenLight);
  Serial.print("  Timestamp: ");
  Serial.println(sensorData.timestamp);
}

// ===== DETERMINE GAS STATUS =====
void determineGasStatus() {
  if (sensorData.gasLevel < 200) {
    sensorData.gasStatus = "SAFE";
  } else if (sensorData.gasLevel < 400) {
    sensorData.gasStatus = "WARNING";
  } else {
    sensorData.gasStatus = "DANGER";
  }
}

// ===== DETERMINE LIGHT STATUS =====
void determineLightStatus(int lightValue) {
  // Light sensor threshold: 512 (midpoint of 0-1023)
  if (lightValue > 512) {
    sensorData.lightStatus = "DAY";
  } else {
    sensorData.lightStatus = "NIGHT";
  }
}

// ===== DETERMINE GARDEN LIGHT STATUS =====
void determineGardenLight() {
  // Simple logic: Turn garden light ON at night, OFF during day
  if (sensorData.lightStatus == "NIGHT") {
    sensorData.gardenLight = "ON";
  } else {
    sensorData.gardenLight = "OFF";
  }

  // Add random variation for demo
  if (rand() % 10 == 0) {
    sensorData.gardenLight = (sensorData.gardenLight == "ON") ? "OFF" : "ON";
  }
}

// ===== GET CURRENT TIMESTAMP =====
unsigned long getCurrentTimestamp() {
  // Return timestamp in milliseconds since epoch
  // ESP8266 has built-in time from NTP or use millis()
  // For simplicity, we'll use millis() offset by a known time

  // January 1, 2024 in milliseconds
  unsigned long baseTimestamp = 1704067200000UL;
  unsigned long elapsed = millis();

  return baseTimestamp + elapsed;
}

// ===== SEND TO FIREBASE =====
void sendToFirebase() {
  Serial.println("Sending to Firebase...");

  // Create Firebase JSON object with all 7 required fields
  FirebaseJson json;

  // Add all 7 required fields
  json.add("temperature", sensorData.temperature);      // Field 1: number
  json.add("humidity", sensorData.humidity);          // Field 2: number
  json.add("gasLevel", sensorData.gasLevel);          // Field 3: number
  json.add("gasStatus", sensorData.gasStatus);        // Field 4: string
  json.add("lightStatus", sensorData.lightStatus);      // Field 5: string
  json.add("gardenLight", sensorData.gardenLight);      // Field 6: string
  json.add("timestamp", sensorData.timestamp);            // Field 7: number

  // Send to Firebase at path /garden/live
  if (Firebase.setJSON(firebaseData, "/garden/live", json)) {
    Serial.println("✅ Data sent successfully!");

    // Optional: Verify data was sent
    if (firebaseData.httpCode() == 200) {
      Serial.println("✅ Firebase HTTP response: 200 OK");
    }
  } else {
    Serial.println("❌ Failed to send data!");
    Serial.print("Error code: ");
    Serial.println(firebaseData.httpCode());
    Serial.print("Error reason: ");
    Serial.println(firebaseData.errorReason());
  }

  Serial.println("----------------------------------------\n");
}
