# ✅ ESP8266 Final Pin Configuration Guide

## 🔌 ESP8266 Analog Pin Limitation

**IMPORTANT**: ESP8266 has **only ONE** analog pin: **A0**

| Board | Analog Pins Available |
|-------|----------------------|
| ESP8266 | **A0 ONLY** |

### Why This Matters

- **A0 (ADC0)**: True analog input (0-1023 values)
- **D0-D15**: Digital pins only (GPIO 0-15)
- **D1**: Can be used as digital input, not analog

---

## ✅ Final Pin Configuration

| Sensor | ESP8266 Pin | Type | Library |
|--------|--------------|------|----------|
| MQ135 Gas | **A0** | Analog | Built-in analogRead() |
| LDR Light | **D1** | Digital | digitalRead() |
| DHT11 Temp/Hum | **D2** | I2C | DHT library |

---

## 🔌 LDR on D1 - Digital Input

### How It Works

Since D1 is **not** an analog pin, we use it as **digital input**:

```cpp
// Read LDR as digital (0 or 1)
int ldrDigital = digitalRead(LDR_PIN);  // D1 pin

// Map to analog-like value for threshold logic
int ldrAnalog = ldrDigital ? 800 : 200; // Map for comparison
```

### Alternative: True Analog LDR

If you want **true analog** LDR readings, use **A0** instead:

**Option 1**: Use A0 for LDR, move MQ135 to digital circuit
**Option 2**: Use capacitor method on A0 for true analog
```cpp
// For true analog LDR on A0:
#define LDR_PIN A0  // Use A0 instead of D1
int ldrAnalog = analogRead(LDR_PIN); // True analog 0-1023
```

---

## 📱 Code File: `ESP8266_Garden_Final.ino`

### Pin Definitions Used:

```cpp
#define MQ135_PIN A0             // Gas sensor on A0 (ONLY analog pin)
#define LDR_PIN D1                // LDR on D1 (digital input)
#define DHT11_PIN D2             // DHT11 on D2 (I2C SDA)
#define DHTTYPE DHT11             // DHT11 sensor type
#define LIGHT_THRESHOLD_ANALOG 500   // For LDR digital reading
```

---

## 🔌 Wiring Diagram

### Current Configuration (D1 = LDR Digital)

```
          ESP8266
         ┌─────┐
3.3V ──┤ 1 ├─ VCC (for all)
         │ 2  ├─ 3.3V (or 5V)
GND ──┤ 3  ├─ GND (for all)
         │ 4  ├─ D2 ────┐
         │    │         │
         │    └─ DHT11 ─┘
         │ 5  ├─ D1 ────┐
         │    │         │
         │    └─ LDR ───┘
         │ 6  ├─ A0 ────┐
         │    │         │
         │    └─ MQ135 ─┘
```

### Pin-by-Pin Connections

#### 1. MQ135 Gas Sensor (A0)
| MQ135 Pin | ESP8266 Pin | Description |
|-----------|--------------|-------------|
| VCC | 3.3V | Power |
| GND | GND | Ground |
| AOUT | A0 | Analog output |

#### 2. LDR Light Sensor (D1)
| LDR Pin | ESP8266 Pin | Description |
|----------|--------------|-------------|
| One Leg | 3.3V | Power |
| Other Leg | GND | Ground |
| Output | D1 | Digital input (0 or 1) |

#### 3. DHT11 Temp/Humidity (D2)
| DHT11 Pin | ESP8266 Pin | Description |
|-----------|--------------|-------------|
| VCC | 3.3V | Power |
| GND | GND | Ground |
| SDA | D2 | I2C SDA (or D4) |
| SCL | D1 | I2C SCL (or D3) |
| NC | NC | Not connected |

**Important**: Add 10KΩ resistor between VCC and DATA pin

---

## 📊 How LDR Digital Input Works

### Current Implementation (D1):

```
LDR Dark → Reads 0 → Shows "NIGHT" → Garden Light ON
LDR Light → Reads 1 → Shows "DAY" → Garden Light OFF
```

### LDR Values:

| Light Condition | Digital Read | Analog Value | Light Status | Garden Light |
|---------------|---------------|--------------|-------------|-------------|
| Very Dark | 0 | 200 | NIGHT | ON |
| Dim | 0 | 200 | NIGHT | ON |
| Normal | 0 | 200 | NIGHT | ON |
| Bright | 1 | 800 | DAY | OFF |
| Very Bright | 1 | 800 | DAY | OFF |

### Calibration:

```cpp
// Adjust this threshold in code:
#define LIGHT_THRESHOLD_ANALOG 500

// Lower = More sensitive (turns ON earlier)
// Higher = Less sensitive (stays ON longer)
```

---

## 🔧 Alternative: True Analog LDR on A0

### If you want precise light detection:

**Option 1**: Move MQ135 to digital circuit
- MQ135 can work with digital readout
- Free up A0 for true analog LDR

**Option 2**: Capacitor method on A0
```cpp
// Use A0 for true analog LDR
#define LDR_PIN A0  // Use A0 instead of D1

// In loop():
unsigned long ldrAnalog = 0;
const int samples = 100;
for (int i = 0; i < samples; i++) {
  ldrAnalog += analogRead(LDR_PIN);
}
ldrAnalog = ldrAnalog / samples;

// Use precise value
if (ldrAnalog > LIGHT_THRESHOLD_ANALOG) {
  lightStatus = "DAY";
} else {
  lightStatus = "NIGHT";
}
```

---

## 📋 Complete Setup Checklist

### Hardware:
- [ ] **MQ135** on A0 (gas sensor)
- [ ] **LDR** on D1 (digital input)
- [ ] **DHT11** on D2 (I2C SDA/SCL)
- [ ] All sensors powered from 3.3V
- [ ] All sensors grounded to GND
- [ ] 10KΩ resistor on DHT11 DATA line

### Software:
- [ ] **Code**: `ESP8266_Garden_Final.ino`
- [ ] **WiFi**: SSID and password configured
- [ ] **Firebase**: Database secret obtained
- [ ] **Library**: DHT library installed
- [ ] **Board**: ESP8266 selected
- [ ] **Port**: COMx selected

### After Upload:
- [ ] **Serial Monitor**: Open at 115200 baud
- [ ] **WiFi connected**: ✅
- [ ] **DHT11 initialized**: ✅
- [ ] **Firebase connected**: ✅
- [ ] **All sensors reading**: ✅
- [ ] **Data sending**: Every 5 seconds ✅

---

## 📊 Serial Monitor Output

### What You'll See:

```
========================================
  SMART GARDEN ESP8266
  Pin Configuration:
   A0 = MQ135 Gas Sensor (Analog)
   D1 = LDR Light Sensor (Digital)
   D2 = DHT11 Temp/Humidity (I2C)
========================================

✅ DHT11 sensor initialized successfully!
  Initial Temp: 24.50 °C
  Initial Hum: 65.00 %

Connecting to WiFi....
....
✅ WiFi connected!
IP Address: 192.168.1.100
SSID: Your_Network_Name

Initializing Firebase...
Firebase initialized!
Firebase Host: rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app
Database Path: /garden/live
========================================

Reading Sensors...
 Temperature: 24.50 °C
  Humidity: 65.00 %
  Gas Level (MQ135/A0): 245 (0-1023)
  Gas Status: SAFE
  LDR Value (D1 digital): 0
  LDR Analog Value (mapped): 200
  Light detected: NIGHT (LDR: 200)
 Garden Light: ON
----------------------------------------

Sending to Firebase...
✅ Temperature sent successfully
✅ Humidity sent successfully
✅ Gas level sent successfully
✅ Gas status sent successfully
✅ Light status sent successfully
✅ Garden light status sent successfully
✅ Timestamp sent successfully
✅ Firebase HTTP response: 200 OK
----------------------------------------
```

---

## 🎯 Dashboard Behavior

### When LDR Reads 0 (Dark):
- ✅ **Light Status**: NIGHT (moon icon 🌙)
- ✅ **Garden Light**: ON (green badge)
- ✅ **Garden Light turns on automatically**

### When LDR Reads 1 (Light):
- ✅ **Light Status**: DAY (sun icon ☀️)
- ✅ **Garden Light**: OFF (gray badge)
- ✅ **Garden Light turns off automatically**

### Real-time Updates:
- ✅ Every 5 seconds
- ✅ All 7 fields sent to Firebase
- ✅ Dashboard displays instantly
- ✅ Charts show last 100 readings

---

## 🔧 Troubleshooting

### Problem 1: DHT11 Not Responding

**Symptom**:
```
⚠️  DHT11 sensor not responding!
```

**Solutions**:
1. Check DHT11 on D2 pin (SDA/SCL or D2/D3)
2. Verify 10KΩ resistor on DATA line
3. Check 3.3V power supply
4. Try different DHT11 sensor

### Problem 2: MQ135 Always Reads 0

**Symptom**:
```
Gas Level (MQ135/A0): 0
```

**Solutions**:
1. Check MQ135 wiring (VCC, GND, AOUT)
2. Verify 3.3V power to MQ135
3. MQ135 needs 24-48 hours to pre-heat
4. Check A0 pin connection

### Problem 3: LDR Always 0 or 1

**Symptom**:
```
LDR Value (D1 digital): 0 (constant)
```

**Solutions**:
1. Check LDR wiring to 3.3V and GND
2. Verify D1 pin connection
3. Test with external light source
4. Adjust LIGHT_THRESHOLD_ANALOG in code

### Problem 4: WiFi Connection Failed

**Symptom**:
```
❌ WiFi connection failed!
```

**Solutions**:
1. Verify SSID and password
2. Check 2.4GHz WiFi network
3. Move ESP8266 closer to router
4. Restart ESP8266

---

## ✅ Final Summary

### Correct Pin Configuration:

| Sensor | Pin | Type | Function |
|--------|-----|------|----------|
| MQ135 Gas | **A0** | Analog (0-1023) | Reads gas PPM |
| LDR Light | **D1** | Digital (0 or 1) | Reads day/night |
| DHT11 Temp | **D2** | I2C | Reads temp/hum |

### Key Features:
- ✅ Uses **only available analog pin** (A0) for gas sensor
- ✅ Uses D1 as **digital input** for LDR
- ✅ Uses D2 for I2C DHT11
- ✅ All 7 fields sent to Firebase
- ✅ Updates every 5 seconds
- ✅ Comprehensive Serial Monitor output
- ✅ Error handling and logging

### Files Created:
1. **`ESP8266_Garden_Final.ino`** - Corrected pin configuration
2. **`FINAL_PIN_CONFIG_GUIDE.md`** - This guide

---

## 🎉 Ready to Use!

### Upload Steps:

1. Open: `ESP8266_Garden_Final.ino`
2. Configure WiFi credentials
3. Get Firebase database secret
4. Select Board: ESP8266
5. Select Port: COMx
6. Click: Upload (→)

### Wiring:

1. **MQ135**: VCC→3.3V, GND→GND, AOUT→A0
2. **LDR**: One leg→3.3V, Other leg→GND, Junction→D1
3. **DHT11**: VCC→3.3V, GND→GND, SDA→D2, SCL→D1
4. **Power**: 3.3V to all sensors from ESP8266

### Test:

1. Open Serial Monitor (115200 baud)
2. Verify all sensors initialize
3. Verify WiFi connects
4. Verify Firebase sends data
5. Check Firebase Console for data
6. Check dashboard for live updates

---

**Your ESP8266 smart garden with correct pin configuration is ready!** 🚀

**A0 = MQ135 Gas (Analog Only Pin)**
**D1 = LDR Light (Digital Input)**
**D2 = DHT11 Temp/Humidity (I2C)**

**Everything is correctly configured for ESP8266!** ✨
