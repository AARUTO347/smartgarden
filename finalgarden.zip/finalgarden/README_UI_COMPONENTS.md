# 🎨 Smart Garden Dashboard UI Components Guide

A complete guide to using the reusable UI components from the Smart Garden Dashboard in your own projects.

## 📋 Table of Contents

1. [Overview](#overview)
2. [Component Library](#component-library)
3. [Installation & Setup](#installation--setup)
4. [Component Usage](#component-usage)
5. [Styling System](#styling-system)
6. [Deployment Ready](#deployment-ready)

---

## 🎯 Overview

The Smart Garden Dashboard uses a modern, glassmorphic design system with:
- **shadcn/ui** components as the base
- **Tailwind CSS** for styling
- **Recharts** for data visualization
- **Lucide Icons** for consistent iconography
- **Dark theme** with cyberpunk-inspired gradients

All components are **fully responsive** and **production-ready** for Netlify deployment.

---

## 🧩 Component Library

### 1. **Sensor Card Component**
Display real-time sensor data with visual indicators.

```tsx
<SensorCard
  icon={<Thermometer className="w-14 h-14" />}
  title="Temperature"
  value={25.5}
  unit="°C"
  color="text-orange-400"
  bgColor="bg-orange-500/10 border-orange-500/20"
  description="Current temperature"
  trend="normal"
/>
```

**Props:**
- `icon`: React node (Lucide icon)
- `title`: Card title string
- `value`: Number or string value
- `unit`: Measurement unit
- `color`: Tailwind text color
- `bgColor`: Tailwind background and border color
- `description`: Subtitle text
- `trend?`: 'high' | 'low' | 'normal'

**File Location:** [src/components/dashboard.tsx#L1370](src/components/dashboard.tsx#L1370)

---

### 2. **Quick Stat Card Component**
Compact statistics display for dashboards.

```tsx
<QuickStatCard
  icon={<Wifi className="w-5 h-5" />}
  title="Connection"
  value="Excellent"
  color="text-green-400"
  bgColor="bg-green-500/10 border-green-500/20"
/>
```

**Props:**
- `icon`: React node (Lucide icon)
- `title`: Label text
- `value`: Display value
- `color`: Text color
- `bgColor`: Background color

**File Location:** [src/components/dashboard.tsx#L1407](src/components/dashboard.tsx#L1407)

---

### 3. **Recommendation Card Component**
Display smart recommendations with visual states.

```tsx
<RecommendationCard
  icon={<Sun className="w-8 h-8" />}
  title="Temperature"
  description="Optimal temperature for plants"
  type="success"
/>
```

**Props:**
- `icon`: React node
- `title`: Card title
- `description`: Recommendation text
- `type`: 'success' | 'warning' | 'info'

**File Location:** [src/components/dashboard.tsx#L1441](src/components/dashboard.tsx#L1441)

---

### 4. **Data Charts Component**
Interactive charts using Recharts for data visualization.

```tsx
import DataCharts from '@/components/data-charts'

<DataCharts 
  gardenData={currentData}
  historicalData={pastData}
/>
```

**Features:**
- Temperature trends
- Humidity levels
- Gas quality monitoring
- Responsive line & bar charts
- Interactive tooltips

**File Location:** [src/components/data-charts.tsx](src/components/data-charts.tsx)

---

### 5. **Dashboard Layout**
Complete dashboard with header, navigation, and content areas.

**Features:**
- Sticky header with logo
- View toggle (Dashboard/Charts/Data/System)
- Responsive grid layout
- Footer with branding
- Demo mode indicator

**File Location:** [src/components/dashboard.tsx](src/components/dashboard.tsx)

---

## 🚀 Installation & Setup

### Prerequisites
```bash
# Node.js 22+
# Bun package manager (recommended) or npm

# Install dependencies
bun install
# or
npm install
```

### Required Dependencies
Already installed in `package.json`:
```json
{
  "next": "^15.0+",
  "react": "^19+",
  "tailwindcss": "^4.0+",
  "recharts": "^2.0+",
  "lucide-react": "^latest",
  "@radix-ui/*": "^latest",
  "zod": "^3.0+"
}
```

### Setting Up Components in New Project

1. **Copy component files:**
```bash
cp src/components/dashboard.tsx your-project/src/components/
cp src/components/data-charts.tsx your-project/src/components/
cp src/components/ui/ your-project/src/components/ui/
```

2. **Configure Tailwind CSS:**
```js
// tailwind.config.ts
import type { Config } from "tailwindcss"

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
      },
    },
  },
  plugins: [],
}
export default config
```

---

## 💻 Component Usage Examples

### Example 1: Simple Dashboard
```tsx
import Dashboard from '@/components/dashboard'
import { useSession } from '@/hooks/use-session'

export default function Page() {
  const { username, isAdmin, onLogout } = useSession()
  
  return (
    <Dashboard 
      username={username}
      isAdmin={isAdmin}
      onLogout={onLogout}
    />
  )
}
```

### Example 2: Custom Data Display
```tsx
'use client'

import { SensorCard } from '@/components/dashboard'
import { Thermometer } from 'lucide-react'
import { useState, useEffect } from 'react'

export default function TemperatureMonitor() {
  const [temp, setTemp] = useState(0)
  
  useEffect(() => {
    // Fetch from API
    fetch('/api/temperature')
      .then(r => r.json())
      .then(data => setTemp(data.value))
  }, [])
  
  return (
    <SensorCard
      icon={<Thermometer className="w-14 h-14" />}
      title="Room Temperature"
      value={temp}
      unit="°C"
      color="text-orange-400"
      bgColor="bg-orange-500/10 border-orange-500/20"
      description="Real-time monitoring"
      trend={temp > 25 ? 'high' : 'normal'}
    />
  )
}
```

### Example 3: Grid Layout with Multiple Cards
```tsx
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { QuickStatCard } from '@/components/dashboard'

export default function Stats() {
  const stats = [
    { icon: <Wifi />, title: 'Status', value: 'Active', color: 'text-green-400' },
    { icon: <Battery />, title: 'Battery', value: '85%', color: 'text-blue-400' },
    { icon: <Activity />, title: 'Uptime', value: '12h 45m', color: 'text-purple-400' },
  ]
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {stats.map((stat, i) => (
        <QuickStatCard key={i} {...stat} bgColor="bg-slate-500/10 border-slate-500/20" />
      ))}
    </div>
  )
}
```

---

## 🎨 Styling System

### Color Palette
```css
/* Primary */
text-green-400, text-green-500
bg-green-500/10, border-green-500/20

/* Temperature */
text-orange-400, bg-orange-500/10

/* Humidity */
text-blue-400, bg-blue-500/10

/* Critical */
text-red-400, bg-red-500/10

/* Warning */
text-yellow-400, bg-yellow-500/10

/* Success */
text-emerald-400, bg-emerald-500/10
```

### Card Styling Pattern
```tsx
// Glassmorphism effect used throughout
className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300"
```

### Responsive Grid
```tsx
// Dashboard layout
grid-cols-1 sm:grid-cols-2 lg:grid-cols-4

// Two-column layout
grid-cols-1 lg:grid-cols-2

// Three-column layout
grid-cols-1 md:grid-cols-3
```

---

## 🌐 Netlify Deployment

### Current Status: ✅ **PRODUCTION READY**

**Configuration File:** [netlify.toml](netlify.toml)

### Deployment Steps

1. **Connect GitHub Repository**
   - Go to [netlify.com](https://netlify.com)
   - Click "New site from Git"
   - Select your repository

2. **Environment Variables** (if needed)
   ```bash
   NEXT_PUBLIC_FIREBASE_API_KEY=your_key_here
   NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_domain
   NEXT_PUBLIC_FIREBASE_DATABASE_URL=your_url
   ```

3. **Build Configuration**
   - Netlify automatically detects `netlify.toml`
   - Build Command: `bun install && bun run build`
   - Publish Directory: `.next`

4. **Deploy**
   - Push to main branch
   - Netlify automatically builds and deploys
   - Check deployment at `https://your-site.netlify.app`

### Performance Features
- ✅ Static asset caching (1 year)
- ✅ Security headers configured
- ✅ SPA routing support
- ✅ Logo.png optimized (1.9MB)
- ✅ Next.js plugin enabled
- ✅ Production Node version (22.22.0)

---

## 📱 Responsive Design

All components are fully responsive:

```tsx
// Breakpoints used
sm: 640px    // Single column → Two columns
md: 768px    // Adjust spacing and sizing
lg: 1024px   // Three/Four column layouts
xl: 1280px   // Full-width optimizations
```

### Mobile-First Approach
- Default: Single column
- Tablet: Two columns
- Desktop: Three-four columns
- Large screens: Full grid with gaps

---

## 🔧 Customization

### Change Color Scheme
Replace color classes in component props:
```tsx
// From orange to purple
color="text-purple-400"
bgColor="bg-purple-500/10 border-purple-500/20"
```

### Modify Card Styling
Edit the glassmorphism effect:
```tsx
// Less transparent
className="bg-white/20 border-white/30"

// More transparent
className="bg-white/5 border-white/10"
```

### Adjust Animations
Modify animation classes:
```tsx
// Faster
animate-in fade-in duration-300

// Slower
animate-in fade-in duration-700

// No animation
```

---

## 📊 Data Structure

### GardenData Interface
```typescript
interface GardenData {
  temperature?: number
  humidity?: number
  lightStatus?: 'DAY' | 'NIGHT'
  gasAQI?: number
  gasStatus?: 'Good' | 'Moderate' | 'Poor'
  timestamp?: number
}
```

### Chart Data Format
```typescript
interface ChartData {
  name: string           // X-axis label
  temperature?: number   // Y-axis value
  humidity?: number
  aqi?: number
}
```

---

## 🎯 Use Cases

### 1. IoT Dashboard
- Monitor sensors (temperature, humidity, gas)
- Display real-time metrics
- Show alerts and recommendations

### 2. Analytics Dashboard
- Display key metrics
- Show trends and charts
- System performance monitoring

### 3. Control Panel
- Device status overview
- Quick action cards
- System information display

### 4. Monitoring System
- Multi-sensor data
- Historical trend analysis
- Data export functionality

---

## 🚀 Performance Tips

1. **Use Image Optimization:**
```tsx
import Image from 'next/image'
<Image src="/logo.png" alt="Logo" width={48} height={48} />
```

2. **Lazy Load Charts:**
```tsx
import dynamic from 'next/dynamic'
const DataCharts = dynamic(() => import('@/components/data-charts'))
```

3. **Memoize Heavy Components:**
```tsx
const Dashboard = React.memo(function Dashboard(props) {
  // Component code
})
```

---

## 📚 Additional Resources

- **Next.js Docs:** https://nextjs.org/docs
- **Tailwind CSS:** https://tailwindcss.com/docs
- **shadcn/ui:** https://ui.shadcn.com
- **Recharts:** https://recharts.org
- **Lucide Icons:** https://lucide.dev

---

## ✅ Netlify Readiness Checklist

- ✅ `netlify.toml` configured
- ✅ `logo.png` in public folder
- ✅ Environment variables documented
- ✅ Build command verified
- ✅ Security headers enabled
- ✅ Caching rules optimized
- ✅ SPA routing configured
- ✅ Mobile responsive design
- ✅ Performance optimized
- ✅ Ready for production deployment

---

## 🤝 Support

For issues or questions about components:
1. Check [src/components/](src/components/) folder
2. Review component interfaces at the top of files
3. Check [NEW_FEATURES.md](NEW_FEATURES.md) for recent updates

---

**Last Updated:** February 16, 2026  
**Version:** 1.0  
**Status:** Production Ready ✅
