'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Leaf, User, Mail, Lock, ArrowLeft, MapPin, Server } from 'lucide-react'
import { toast } from 'sonner'
import { createUser } from '@/lib/user-store'

interface SignupProps {
  onSignupSuccess: (username: string, password: string) => void
  onBackToLogin: () => void
}

export default function Signup({ onSignupSuccess, onBackToLogin }: SignupProps) {
  const [deviceId, setDeviceId] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [location, setLocation] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Validate passwords match
    if (password !== confirmPassword) {
      toast.error('Passwords do not match')
      setIsLoading(false)
      return
    }

    // Create user with deviceId as username
    const result = createUser(deviceId, password, location, email)

    // Simulate network delay for better UX
    await new Promise(resolve => setTimeout(resolve, 500))

    setIsLoading(false)

    if (result.success) {
      toast.success(result.message)
      // Auto-login after signup
      onSignupSuccess(deviceId, password)
    } else {
      toast.error(result.message)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden bg-gradient-to-br from-green-900 via-green-800 to-emerald-900">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-green-400/5 rounded-full blur-3xl animate-pulse delay-500" />
      </div>

      {/* Signup Card */}
      <div className="relative z-10 w-full max-w-md px-4">
        <Card className="backdrop-blur-xl bg-white/10 border-white/20 shadow-2xl">
          <CardContent className="p-8">
            {/* Logo and Title */}
            <div className="flex flex-col items-center mb-8">
              <div className="relative mb-4">
                <div className="absolute inset-0 bg-green-400/30 blur-xl rounded-full animate-pulse" />
                <div className="relative w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center shadow-lg">
                  <Leaf className="w-10 h-10 text-white" />
                </div>
              </div>
              <h1 className="text-2xl font-bold text-white text-center mb-1">
                Register Device
              </h1>
              <p className="text-green-200/80 text-sm">
                Add your device to Smart Garden Monitoring
              </p>
            </div>

            {/* Signup Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <label htmlFor="deviceId" className="text-sm font-medium text-green-100">
                  Device ID
                </label>
                <div className="relative">
                  <Server className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-300" />
                  <Input
                    id="deviceId"
                    type="text"
                    placeholder="Enter your device ID"
                    value={deviceId}
                    onChange={(e) => setDeviceId(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder-green-200/50 pl-10 focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all"
                    required
                    minLength={3}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="location" className="text-sm font-medium text-green-100">
                  Location
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-300" />
                  <Input
                    id="location"
                    type="text"
                    placeholder="e.g., Garden Zone A"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder-green-200/50 pl-10 focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all"
                    required
                    minLength={2}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-green-100">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-300" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder-green-200/50 pl-10 focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="password" className="text-sm font-medium text-green-100">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-300" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Create a password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder-green-200/50 pl-10 focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all"
                    required
                    minLength={6}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="confirmPassword" className="text-sm font-medium text-green-100">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-300" />
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm your password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder-green-200/50 pl-10 focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50 transition-all"
                    required
                    minLength={6}
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-medium shadow-lg hover:shadow-green-500/25 transition-all duration-300 group"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Registering Device...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    Register Device
                    <svg
                      className="w-4 h-4 transform group-hover:translate-x-1 transition-transform"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </span>
                )}
              </Button>

              <Button
                type="button"
                onClick={onBackToLogin}
                variant="ghost"
                className="w-full text-green-200 hover:text-white hover:bg-white/5 transition-all"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Login
              </Button>
            </form>

            {/* Footer Info */}
            <div className="mt-6 pt-6 border-t border-white/10 text-center">
              <p className="text-xs text-green-200/60">
                Your device ID and password will be used to login
              </p>
              <p className="text-xs text-green-200/60">
                Contact admin for help: AARUTO
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer with Branding */}
      <footer className="absolute bottom-0 left-0 right-0 py-4 bg-black/20 backdrop-blur-sm border-t border-white/10">
        <div className="text-center space-y-1">
          <p className="text-sm font-semibold text-green-100">
            MANAGED BY AARUTO
          </p>
          <p className="text-xs text-green-200/60">
            SECURE DEVICE MANAGEMENT SYSTEM
          </p>
        </div>
      </footer>
    </div>
  )
}
