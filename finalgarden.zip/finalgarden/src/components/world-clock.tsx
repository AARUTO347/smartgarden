'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Clock, Globe, Sun, Moon, MapPin, Calendar } from 'lucide-react'

interface TimezoneInfo {
  id: string
  name: string
  location: string
  timezone: string
}

const timezones: TimezoneInfo[] = [
  { id: 'local', name: 'Local Time', location: 'Your Location', timezone: Intl.DateTimeFormat().resolvedOptions().timeZone },
  { id: 'utc', name: 'UTC', location: 'Universal Coordinated', timezone: 'UTC' },
  { id: 'ny', name: 'New York', location: 'USA', timezone: 'America/New_York' },
  { id: 'london', name: 'London', location: 'UK', timezone: 'Europe/London' },
  { id: 'tokyo', name: 'Tokyo', location: 'Japan', timezone: 'Asia/Tokyo' },
  { id: 'sydney', name: 'Sydney', location: 'Australia', timezone: 'Australia/Sydney' },
  { id: 'dubai', name: 'Dubai', location: 'UAE', timezone: 'Asia/Dubai' },
  { id: 'singapore', name: 'Singapore', location: 'Singapore', timezone: 'Asia/Singapore' }
]

// Calculate time for a timezone - no state, direct Date() function
const getTimeForTimezone = (timezone: string) => {
  try {
    const now = new Date()

    // Get time string with seconds
    const timeStr = now.toLocaleTimeString('en-US', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    })

    // Get date string
    const dateStr = now.toLocaleDateString('en-US', {
      timeZone: timezone,
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    })

    // Get hour number to determine day/night
    const hourNum = parseInt(
      now.toLocaleTimeString('en-US', {
        timeZone: timezone,
        hour: 'numeric'
      }) || '0',
      10
    )
    const isDay = hourNum >= 6 && hourNum < 18

    return { time: timeStr, date: dateStr, isDay }
  } catch (error) {
    console.error(`Error formatting time for ${timezone}:`, error)
    return { time: '--:--:--', date: 'Timezone error', isDay: true }
  }
}

export default function WorldClock() {
  // Calculate times on each render - no state, no infinite loop
  const now = new Date()
  const times = timezones.reduce((acc, tz) => {
    acc[tz.id] = getTimeForTimezone(tz.timezone)
    return acc
  }, {} as { [key: string]: { time: string; date: string; isDay: boolean } })

  return (
    <Card className="backdrop-blur-xl bg-white/10 border-white/20">
      <CardHeader className="pb-3">
        <CardTitle className="text-white flex items-center gap-2">
          <Globe className="w-5 h-5 text-green-400" />
          World Clock - Live
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {/* Local Time - Highlighted */}
          <div className="p-4 bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-xl border border-green-500/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-500/30 rounded-full flex items-center justify-center">
                  {times['local']?.isDay ? (
                    <Sun className="w-7 h-7 text-yellow-400" />
                  ) : (
                    <Moon className="w-7 h-7 text-blue-300" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-semibold text-green-200/60 flex items-center gap-2">
                    <MapPin className="w-3 h-3" />
                    Local Time
                  </p>
                  <p className="text-3xl font-bold text-white tracking-wider">
                    {times['local']?.time || '--:--:--'}
                  </p>
                  <p className="text-xs text-green-200/70 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {times['local']?.date || '--'}
                  </p>
                </div>
              </div>
              <Badge className="bg-green-500/30 text-green-300 border-green-500/40 animate-pulse">
                Your Timezone
              </Badge>
            </div>
          </div>

          {/* UTC Time */}
          <div className="p-3 bg-black/20 rounded-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center">
                  <Globe className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-xs text-green-200/60">UTC (Universal)</p>
                  <p className="text-2xl font-bold text-white">
                    {times['utc']?.time || '--:--:--'}
                  </p>
                  <p className="text-xs text-green-200/70">
                    {times['utc']?.date || '--'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Major Cities Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {timezones.slice(2).map(tz => (
              <div
                key={tz.id}
                className="p-3 bg-black/20 rounded-xl hover:bg-black/30 transition-all duration-300 hover:scale-105"
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${times[tz.id]?.isDay ? 'bg-yellow-500/20' : 'bg-blue-500/20'}`}>
                    {times[tz.id]?.isDay ? (
                      <Sun className="w-4 h-4 text-yellow-400" />
                    ) : (
                      <Moon className="w-4 h-4 text-blue-300" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-green-200/60 truncate">{tz.location}</p>
                    <p className="text-sm font-semibold text-white truncate">{tz.name}</p>
                  </div>
                </div>
                <p className="text-xl font-bold text-white tracking-wider">
                  {times[tz.id]?.time || '--:--:--'}
                </p>
              </div>
            ))}
          </div>

          {/* Time Sync Indicator */}
          <div className="flex items-center justify-center gap-2 p-2 bg-green-500/10 rounded-lg">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <p className="text-xs text-green-200/70">
              Using system time (Date()) • Updates every second
            </p>
            <Clock className="w-3 h-3 text-green-400 animate-spin" style={{ animationDuration: '60s' }} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
