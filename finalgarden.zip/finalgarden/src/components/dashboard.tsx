'use client'

import { useState, useEffect, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  Leaf, Thermometer, Droplets, Sun, Moon, Flame, AlertTriangle, Shield, LogOut,
  Download, BarChart3, Clock, MapPin, Wifi, Battery, Activity, Zap, RefreshCw,
  Bell, Info, CheckCircle, AlertCircle, TrendingUp, TrendingDown, Cpu,
  Globe, Satellite, Cloud, CloudRain, Wind, Eye, Gauge, Radio, Sparkles, HardDrive,
  FileText, FileSpreadsheet, Smartphone, Server, Database, Settings
} from 'lucide-react'
import { GardenData, useGardenData, getGasStatusColor, getGasStatusBgColor, getLightStatusColor } from '@/lib/app-logic'
import { exportCurrentToCSV } from '@/lib/csv-export'
import { exportToPDF, exportCurrentToPDF, generateMockDeviceInfo, DeviceInfo } from '@/lib/pdf-export'
import { useToast } from '@/hooks/use-toast'
import DataCharts from '@/components/data-charts'
import WorldClock from '@/components/world-clock'

interface DashboardProps {
  username: string
  isAdmin?: boolean
  deviceId?: string
  onLogout: () => void
}

interface SystemInfo {
  uptime: string
  connectionQuality: string
}

interface LocationInfo {
  latitude: number | null
  longitude: number | null
  accuracy: number | null
  address: string
  city: string
  country: string
  postcode: string
  fullAddress: string
  timestamp: number | null
  isLoading: boolean
}

export default function Dashboard({ username, isAdmin = false, deviceId, onLogout }: DashboardProps) {
  const [gardenDataRef, setGardenDataRef] = useState<any>(null)
  const [view, setView] = useState<'dashboard' | 'charts' | 'data' | 'system'>('dashboard')
  const [historicalData, setHistoricalData] = useState<GardenData[]>([])
  const { toast } = useToast()

  // Multi-device state
  const [multiDeviceMode, setMultiDeviceMode] = useState(false)
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | undefined>(undefined)

  // System info state - minimal state, no frequent updates
  const [startTime] = useState(() => Date.now())
  const [systemInfo, setSystemInfo] = useState<SystemInfo>({
    uptime: '0h 0m',
    connectionQuality: 'Excellent'
  })

  // Derived system metrics calculated on render - no state updates
  const fullSystemInfo = useMemo(() => {
    const now = new Date()
    const elapsed = now.getTime() - startTime
    const hours = Math.floor(elapsed / 3600000)
    const minutes = Math.floor((elapsed % 3600000) / 60000)
    const seconds = Math.floor((elapsed % 60000) / 1000)

    return {
      uptime: `${hours}h ${minutes}m ${seconds}s`,
      lastSync: now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }),
      batteryLevel: Math.max(10, 85 - (elapsed / 1000 / 60) * 0.1),
      memoryUsage: 30 + Math.sin(elapsed / 10000) * 10 + 20,
      cpuUsage: 10 + Math.sin(elapsed / 5000) * 20 + 30,
      dataPoints: historicalData.length,
      connectionQuality: systemInfo.connectionQuality
    }
  }, [startTime, historicalData.length, systemInfo.connectionQuality])

  // Location state - No loading, just data or disabled
  const [locationInfo, setLocationInfo] = useState<LocationInfo>({
    latitude: null,
    longitude: null,
    accuracy: null,
    address: 'Location disabled',
    city: '--',
    country: '--',
    postcode: '--',
    fullAddress: 'Enable location access',
    timestamp: null,
    isLoading: false
  })

  // Reverse geocoding function - simple and fast
  const reverseGeocode = async (lat: number, lon: number): Promise<Partial<LocationInfo>> => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=10&addressdetails=1`,
        {
          headers: {
            'Accept-Language': 'en-US,en;q=0.9',
          }
        }
      )

      if (!response.ok) return {}

      const data = await response.json()

      if (data && data.address) {
        const addr = data.address
        return {
          city: addr.city || addr.town || addr.village || addr.suburb || addr.county || '--',
          country: addr.country || '--',
          postcode: addr.postcode || addr.zip || '--',
          fullAddress: data.display_name || `${lat.toFixed(4)}°N, ${lon.toFixed(4)}°E`
        }
      }
      return {}
    } catch {
      return {}
    }
  }

  // Get user location - smooth, no loading states
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude
          const lon = position.coords.longitude

          // Update with coordinates immediately
          setLocationInfo({
            latitude: lat,
            longitude: lon,
            accuracy: position.coords.accuracy,
            address: `${lat.toFixed(4)}°N, ${lon.toFixed(4)}°E`,
            city: '--',
            country: '--',
            postcode: '--',
            fullAddress: `${lat.toFixed(4)}°N, ${lon.toFixed(4)}°E`,
            timestamp: position.timestamp,
            isLoading: false
          })

          // Try to get place name in background
          try {
            const geocodedData = await reverseGeocode(lat, lon)
            setLocationInfo(prev => ({
              ...prev,
              ...geocodedData,
              address: geocodedData.city || `${lat.toFixed(4)}°N, ${lon.toFixed(4)}°E`
            }))

            toast({
              title: "Location Found",
              description: geocodedData.city ? `${geocodedData.city}, ${geocodedData.country}` : "GPS coordinates retrieved",
              variant: "default",
            })
          } catch (error) {
            // Silent fail - keep coordinates display
            console.log('Geocoding skipped, showing coordinates')
          }
        },
        (error) => {
          setLocationInfo({
            latitude: null,
            longitude: null,
            accuracy: null,
            address: 'Location disabled',
            city: 'Disabled',
            country: '--',
            postcode: '--',
            fullAddress: 'Enable location in browser settings',
            timestamp: null,
            isLoading: false
          })
        },
        { enableHighAccuracy: true, timeout: 5000 }
      )
    }
  }, [toast])

  // Lazy load Firebase on client side only
  useEffect(() => {
    if (typeof window !== 'undefined') {
      console.log('🚀 Loading Firebase module...')
      console.log('🚀 Device ID for Firebase:', deviceId)

      import('@/lib/firebase').then(({ getGardenDataRef }) => {
        try {
          const ref = getGardenDataRef(deviceId)
          console.log('✅ Firebase reference created successfully for device:', deviceId)
          console.log('✅ Firebase path:', ref.toString())
          setGardenDataRef(ref)
          void toast({
            title: "Connected to Database",
            description: deviceId
              ? `Real-time data synchronization enabled for device: ${deviceId}`
              : "Real-time data synchronization enabled",
            variant: "default",
          })
        } catch (error) {
          console.error('❌ Error getting Firebase ref:', error)
          void toast({
            title: "Connection Error",
            description: "Failed to connect to Firebase",
            variant: "destructive",
          })
        }
      }).catch((error) => {
        console.error('❌ Error loading Firebase module:', error)
        void toast({
          title: "System Error",
          description: "Failed to initialize database module",
          variant: "destructive",
        })
      })
    }
  }, [deviceId, toast])

  const { gardenData, isConnected } = useGardenData(gardenDataRef)

  // Update connection quality when it changes - moved after isConnected is defined
  useEffect(() => {
    setSystemInfo(prev => ({
      ...prev,
      connectionQuality: isConnected ? 'Excellent' : 'Disconnected'
    }))
  }, [isConnected])

  // Demo data when no live data is available
  const hasValidData = gardenData !== null &&
    typeof gardenData === 'object' &&
    Object.keys(gardenData).length > 0

  const displayData: GardenData = hasValidData ? {
    ...gardenData
  } : (() => {
    // More realistic demo data based on time of day
    const now = new Date()
    const hour = now.getHours()
    const isDay = hour >= 6 && hour < 18

    // Temperature varies by time of day
    let baseTemp = 24
    if (hour >= 6 && hour < 14) {
      baseTemp = 22 + (hour - 6) * 0.8 // Rising morning
    } else if (hour >= 14 && hour < 18) {
      baseTemp = 28 - (hour - 14) * 0.3 // Peaking afternoon
    } else if (hour >= 18 || hour < 6) {
      baseTemp = 26 - ((hour >= 18 ? hour - 18 : hour + 6)) * 0.6 // Cooling evening/night
    }

    const temp = baseTemp + (Math.random() - 0.5) * 3

    // Humidity inversely related to temperature
    const humidity = 65 + (Math.random() - 0.5) * 15 - (temp - 24) * 1.5

    // AQI - higher during rush hours (7-9 AM, 5-7 PM)
    let baseAQI = 100
    if ((hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19)) {
      baseAQI = 150 + Math.random() * 50 // Rush hour
    } else if (hour >= 10 && hour < 16) {
      baseAQI = 80 + Math.random() * 40 // Mid-day
    } else {
      baseAQI = 60 + Math.random() * 60 // Off-peak
    }
    const aqi = Math.max(20, Math.min(450, baseAQI))

    // Determine gas status based on AQI
    let gasStatus: 'GOOD' | 'SATISFACTORY' | 'MODERATE' | 'POOR' | 'VERY_POOR' | 'SEVERE'
    if (aqi <= 50) {
      gasStatus = 'GOOD'
    } else if (aqi <= 100) {
      gasStatus = 'SATISFACTORY'
    } else if (aqi <= 200) {
      gasStatus = 'MODERATE'
    } else if (aqi <= 300) {
      gasStatus = 'POOR'
    } else if (aqi <= 400) {
      gasStatus = 'VERY_POOR'
    } else {
      gasStatus = 'SEVERE'
    }

    return {
      temperature: Math.round(temp * 10) / 10,
      humidity: Math.round(Math.max(35, Math.min(95, humidity)) * 10) / 10,
      gasLevel: Math.round(aqi),
      gasAQI: Math.round(aqi),
      aqi: Math.round(aqi),
      gasStatus,
      lightStatus: isDay ? 'DAY' : 'NIGHT',
      timestamp: Date.now()
    }
  })()

  const isDemoData = !hasValidData

  // Show notification when data changes - removed displayData and historicalData from deps
  useEffect(() => {
    if (gardenData && hasValidData) {
      const prevAQI = historicalData[historicalData.length - 2]?.aqi || 0
      const currentAQI = gardenData.aqi || gardenData.gasAQI || 0

      if (prevAQI > 0 && Math.abs(currentAQI - prevAQI) > 20) {
        void toast({
          title: "Air Quality Alert",
          description: `AQI changed from ${prevAQI} to ${currentAQI}`,
          variant: currentAQI > prevAQI ? "destructive" : "default",
        })
      }

      if (['POOR', 'VERY_POOR', 'SEVERE', 'UNHEALTHY', 'VERY_UNHEALTHY', 'DANGER'].includes(gardenData.gasStatus || '')) {
        void toast({
          title: "Air Quality Warning",
          description: `Current status: ${gardenData.gasStatus}. Consider closing windows.`,
          variant: "destructive",
        })
      }
    }
  }, [gardenData, hasValidData]) // ✅ Removed displayData, historicalData, toast

  // Last update time calculated directly on render
  const lastUpdate = new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  })

  // Update historical data when data changes from Firebase
  useEffect(() => {
    if (gardenData?.timestamp) {
      setHistoricalData(prev => {
        const newData = [...prev, gardenData]
        return newData.slice(-100)
      })
    }
  }, [gardenData])

  const handleExportCSV = () => {
    exportCurrentToCSV(gardenData)
    toast({
      title: "Export Successful",
      description: "Data has been exported to CSV",
      variant: "default",
    })
  }

  const handleExportPDF = () => {
    // Generate device info if in multi-device mode
    const currentDeviceInfo = multiDeviceMode ? (deviceInfo || generateMockDeviceInfo()) : undefined

    exportCurrentToPDF(gardenData, currentDeviceInfo, {
      title: 'Smart Garden Dashboard Report',
      includeCharts: true,
      includeDeviceInfo: multiDeviceMode
    })

    toast({
      title: "PDF Export Successful",
      description: multiDeviceMode
        ? `Report exported with device information for ${currentDeviceInfo?.deviceName || 'multiple devices'}`
        : "Report exported with current sensor data",
      variant: "default",
    })
  }

  const handleExportAll = () => {
    // Generate device info if in multi-device mode
    const currentDeviceInfo = multiDeviceMode ? (deviceInfo || generateMockDeviceInfo()) : undefined

    // Export both formats
    exportCurrentToCSV(gardenData)
    exportCurrentToPDF(gardenData, currentDeviceInfo, {
      title: 'Smart Garden Complete Report',
      includeCharts: true,
      includeDeviceInfo: multiDeviceMode
    })

    toast({
      title: "Export Complete",
      description: "Data exported to both CSV and PDF formats",
      variant: "default",
    })
  }

  const handleRefresh = () => {
    toast({
      title: "Refreshing",
      description: "Updating sensor data...",
      variant: "default",
    })
    // Force re-render
    setSystemInfo(prev => ({ ...prev }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-green-800 to-emerald-900 flex flex-col relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-green-400/5 rounded-full blur-3xl animate-pulse delay-500" />

        {/* Floating particles */}
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-green-400/30 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
        <div className="absolute top-1/3 right-1/3 w-3 h-3 bg-emerald-400/30 rounded-full animate-bounce" style={{ animationDelay: '1s' }} />
        <div className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-green-300/30 rounded-full animate-bounce" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-emerald-300/30 rounded-full animate-bounce" style={{ animationDelay: '0.5s' }} />
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-black/30 backdrop-blur-lg border-b border-white/10 sticky top-0 z-30 transition-all duration-300">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              {/* Logo and Title */}
              <div className="flex items-center gap-3 group cursor-pointer">
                <div className="relative transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                  <div className="absolute inset-0 bg-green-400/40 blur-xl rounded-full animate-pulse" />
                  <div className="relative w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center shadow-xl shadow-green-500/30">
                    <Leaf className="w-6 h-6 text-white animate-pulse" />
                  </div>
                </div>
                <div className="transform group-hover:translate-x-2 transition-all duration-300">
                  <h1 className="text-xl font-bold text-white tracking-wide">
                    Smart Garden
                    <span className="text-green-400">Pro</span>
                  </h1>
                  <p className="text-xs text-green-200/60">IoT Monitoring System v2.0</p>
                </div>
              </div>

              {/* User Info and Actions */}
              <div className="flex items-center gap-4">
                <div className="hidden sm:flex flex-col items-end space-y-1">
                  <span className="text-sm font-semibold text-green-100 flex items-center gap-2">
                    <Bell className="w-4 h-4 text-green-400" />
                    {username}
                  </span>
                  <span className="text-xs text-green-200/60 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    Last updated: {lastUpdate}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleRefresh}
                    className="text-green-100 hover:text-white hover:bg-white/10 transition-all duration-300 hover:rotate-180"
                    title="Refresh Data"
                  >
                    <RefreshCw className="w-5 h-5" />
                  </Button>
                  {isAdmin && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => window.location.href = '/admin'}
                      className="text-green-100 hover:text-purple-400 hover:bg-white/10 transition-all duration-300"
                      title="Admin Console"
                    >
                      <Settings className="w-5 h-5" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onLogout}
                    className="text-green-100 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                    title="Logout"
                  >
                    <LogOut className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="flex-1 container mx-auto px-4 py-6 space-y-6">
          {/* View Toggle and Actions */}
          <div className="flex flex-wrap items-center justify-between gap-4 animate-in slide-in-from-top-4 duration-500">
            <div className="flex items-center gap-2">
              {['dashboard', 'charts', 'data', 'system'].map((v) => {
                const isActive = view === v
                const icons: Record<string, any> = {
                  dashboard: <Leaf className="w-4 h-4" />,
                  charts: <BarChart3 className="w-4 h-4" />,
                  data: <Download className="w-4 h-4" />,
                  system: <Activity className="w-4 h-4" />
                }
                const labels: Record<string, string> = {
                  dashboard: 'Dashboard',
                  charts: 'Charts',
                  data: 'Raw Data',
                  system: 'System'
                }

                return (
                  <Button
                    key={v}
                    variant={isActive ? 'default' : 'outline'}
                    onClick={() => setView(v as any)}
                    className={isActive
                      ? 'bg-green-500 hover:bg-green-600 text-white border-green-500 shadow-lg shadow-green-500/30 transform scale-105'
                      : 'text-green-200 border-green-500/30 hover:bg-green-500/10 hover:scale-105 transition-all duration-300'
                    }
                  >
                    {icons[v]}
                    <span className="ml-2">{labels[v]}</span>
                  </Button>
                )
              })}
            </div>

            {view === 'dashboard' && (
              <div className="flex items-center gap-2">
                {/* Multi-device toggle */}
                <Button
                  onClick={() => setMultiDeviceMode(!multiDeviceMode)}
                  variant={multiDeviceMode ? 'default' : 'outline'}
                  className={multiDeviceMode
                    ? 'bg-green-500 hover:bg-green-600 text-white border-green-500 shadow-lg shadow-green-500/30'
                    : 'text-green-200 border-green-500/30 hover:bg-green-500/10 hover:scale-105 transition-all duration-300'
                  }
                  title="Toggle Multi-Device Mode"
                >
                  <Server className="w-4 h-4 mr-2" />
                  {multiDeviceMode ? 'Multi-Device: ON' : 'Multi-Device: OFF'}
                </Button>

                {/* CSV Export */}
                <Button
                  onClick={handleExportCSV}
                  variant="outline"
                  className="text-green-200 border-green-500/30 hover:bg-green-500/10 hover:text-white hover:scale-105 transition-all duration-300 shadow-lg"
                  title="Export as CSV"
                >
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  CSV
                </Button>

                {/* PDF Export */}
                <Button
                  onClick={handleExportPDF}
                  variant="outline"
                  className="text-green-200 border-green-500/30 hover:bg-green-500/10 hover:text-white hover:scale-105 transition-all duration-300 shadow-lg"
                  title="Export as PDF"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  PDF
                </Button>

                {/* Export All */}
                <Button
                  onClick={handleExportAll}
                  variant="outline"
                  className="text-green-200 border-green-500/30 hover:bg-green-500/10 hover:text-white hover:scale-105 transition-all duration-300 shadow-lg"
                  title="Export All Formats"
                >
                  <Download className="w-4 h-4 mr-2" />
                  All
                </Button>
              </div>
            )}
          </div>

          {/* Demo Data Alert */}
          {isDemoData && (
            <div className="animate-in fade-in slide-in-from-top-2 duration-500">
              <div className="p-4 bg-yellow-500/20 border border-yellow-500/30 rounded-xl backdrop-blur-xl flex items-center gap-3 hover:bg-yellow-500/30 transition-all duration-300 cursor-pointer">
                <div className="w-10 h-10 bg-yellow-500/30 rounded-full flex items-center justify-center animate-pulse">
                  <Shield className="w-5 h-5 text-yellow-300" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-yellow-200">Demo Mode Active</p>
                  <p className="text-xs text-yellow-300/70">Waiting for live ESP8266 sensor data from Firebase...</p>
                </div>
                <Badge className="bg-yellow-500/30 text-yellow-300 border-yellow-500/40 animate-pulse">
                  Demo
                </Badge>
              </div>
            </div>
          )}

          {/* Dashboard View */}
          {view === 'dashboard' && (
            <div className="space-y-6">
              {/* Sensor Cards Grid */}
              <div className="flex items-center justify-center animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="w-full max-w-7xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {/* Temperature Card */}
                  <SensorCard
                    icon={<Thermometer className="w-14 h-14" />}
                    title="Temperature"
                    value={displayData.temperature ?? '--'}
                    unit="°C"
                    color="text-orange-400"
                    bgColor="bg-orange-500/10 border-orange-500/20"
                    description="Current temperature"
                    trend={displayData.temperature && displayData.temperature > 30 ? 'high' : displayData.temperature && displayData.temperature < 15 ? 'low' : 'normal'}
                  />

                  {/* Humidity Card */}
                  <SensorCard
                    icon={<Droplets className="w-14 h-14" />}
                    title="Humidity"
                    value={displayData.humidity ?? '--'}
                    unit="%"
                    color="text-blue-400"
                    bgColor="bg-blue-500/10 border-blue-500/20"
                    description="Relative humidity"
                    trend={displayData.humidity && displayData.humidity > 70 ? 'high' : displayData.humidity && displayData.humidity < 30 ? 'low' : 'normal'}
                  />

                  {/* Light Status Card */}
                  <SensorCard
                    icon={displayData.lightStatus === 'DAY' ? <Sun className="w-14 h-14" /> : <Moon className="w-14 h-14" />}
                    title="Light Status"
                    value={displayData.lightStatus ?? '--'}
                    unit=""
                    color={getLightStatusColor(displayData.lightStatus || '')}
                    bgColor="bg-purple-500/10 border-purple-500/20"
                    description="Day/Night cycle"
                  />

                  {/* AQI Status Card */}
                  <SensorCard
                    icon={
                      ['SEVERE', 'DANGER', 'DANGEROUS', 'HAZARDOUS'].includes(displayData.gasStatus || '') ? <Flame className="w-14 h-14" /> :
                      ['VERY_POOR', 'VERY_UNHEALTHY', 'UNHEALTHY', 'WARNING', 'POOR', 'SATISFACTORY', 'MODERATE'].includes(displayData.gasStatus || '') ? <AlertTriangle className="w-14 h-14" /> :
                      <Shield className="w-14 h-14" />
                    }
                    title="Air Quality"
                    value={displayData.aqi ?? displayData.gasAQI ?? displayData.gasLevel ?? '--'}
                    unit="AQI"
                    color={getGasStatusColor(displayData.gasStatus || '')}
                    bgColor={getGasStatusBgColor(displayData.gasStatus || '')}
                    description={
                      <div className="flex items-center gap-2">
                        <Clock className="w-5 h-5 text-green-600/80" />
                        <span className="text-sm text-green-200/80">
                          {displayData.gasStatus ?? '--'}
                        </span>
                      </div>
                    }
                    isStatusCard={true}
                  />
                </div>
              </div>

              {/* Quick Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-in fade-in slide-in-from-bottom-6 duration-500 delay-100">
                <QuickStatCard
                  icon={<Wifi className="w-5 h-5" />}
                  title="Connection"
                  value={fullSystemInfo.connectionQuality}
                  color={fullSystemInfo.connectionQuality === 'Excellent' ? 'text-green-400' : 'text-red-400'}
                  bgColor="bg-green-500/10 border-green-500/20"
                />
                <QuickStatCard
                  icon={<Battery className="w-5 h-5" />}
                  title="Device Battery"
                  value={`${fullSystemInfo.batteryLevel.toFixed(0)}%`}
                  color={fullSystemInfo.batteryLevel > 50 ? 'text-green-400' : fullSystemInfo.batteryLevel > 20 ? 'text-yellow-400' : 'text-red-400'}
                  bgColor="bg-blue-500/10 border-blue-500/20"
                />
                <QuickStatCard
                  icon={<Clock className="w-5 h-5" />}
                  title="Uptime"
                  value={fullSystemInfo.uptime}
                  color="text-emerald-400"
                  bgColor="bg-purple-500/10 border-purple-500/20"
                />
                <QuickStatCard
                  icon={<Activity className="w-5 h-5" />}
                  title="Data Points"
                  value={fullSystemInfo.dataPoints.toString()}
                  color="text-cyan-400"
                  bgColor="bg-cyan-500/10 border-cyan-500/20"
                />
              </div>

              {/* System Information & Location Cards */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-8 duration-500 delay-200">
                {/* System Information Card */}
                <Card className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300 hover:shadow-2xl hover:shadow-green-500/10 hover:-translate-y-1">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white flex items-center gap-2">
                        <Cpu className="w-5 h-5 text-green-400" />
                        System Information
                      </CardTitle>
                      {isDemoData && (
                        <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                          Demo Mode
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <p className="text-xs text-green-200/60 uppercase tracking-wider">Connected User</p>
                        <p className="text-sm font-medium text-white flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-400" />
                          {username}
                        </p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-xs text-green-200/60 uppercase tracking-wider">Status</p>
                        <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                          Online
                        </Badge>
                      </div>
                    </div>

                    <div className="space-y-3 pt-2">
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-green-200/60">Memory Usage</span>
                          <span className="text-white">{fullSystemInfo.memoryUsage.toFixed(0)}%</span>
                        </div>
                        <Progress value={fullSystemInfo.memoryUsage} className="h-2 bg-white/10" />
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-green-200/60">CPU Usage</span>
                          <span className="text-white">{fullSystemInfo.cpuUsage.toFixed(0)}%</span>
                        </div>
                        <Progress value={fullSystemInfo.cpuUsage} className="h-2 bg-white/10" />
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-green-200/60">Device Battery</span>
                          <span className="text-white">{fullSystemInfo.batteryLevel.toFixed(0)}%</span>
                        </div>
                        <Progress value={fullSystemInfo.batteryLevel} className="h-2 bg-white/10" />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <div className="p-3 bg-black/20 rounded-lg">
                        <p className="text-xs text-green-200/60">Data Source</p>
                        <p className="text-sm font-medium text-white mt-1">{isDemoData ? 'Demo Data' : 'Firebase Realtime'}</p>
                      </div>
                      <div className="p-3 bg-black/20 rounded-lg">
                        <p className="text-xs text-green-200/60">Last Sync</p>
                        <p className="text-sm font-medium text-white mt-1">{fullSystemInfo.lastSync}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* GPS Location Card */}
                <Card className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300 hover:shadow-2xl hover:shadow-green-500/10 hover:-translate-y-1">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white flex items-center gap-2">
                        <Globe className="w-5 h-5 text-cyan-400" />
                        GPS Location
                      </CardTitle>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          if (navigator.geolocation) {
                            navigator.geolocation.getCurrentPosition(async (pos) => {
                              const lat = pos.coords.latitude
                              const lon = pos.coords.longitude
                              setLocationInfo({
                                latitude: lat,
                                longitude: lon,
                                accuracy: pos.coords.accuracy,
                                address: `${lat.toFixed(4)}°N, ${lon.toFixed(4)}°E`,
                                timestamp: pos.timestamp
                              })
                              try {
                                const geocodedData = await reverseGeocode(lat, lon)
                                setLocationInfo(prev => ({
                                  ...prev,
                                  ...geocodedData,
                                  address: geocodedData.city || `${lat.toFixed(4)}°N, ${lon.toFixed(4)}°E`
                                }))
                              } catch {}
                            })
                          }
                        }}
                        className="text-green-100 hover:text-white hover:bg-white/10 transition-all duration-300 hover:rotate-90"
                        title="Refresh Location"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Place Name - Prominent Display */}
                    <div className="p-4 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-xl space-y-2 border border-cyan-500/30">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-cyan-500/30 rounded-full flex items-center justify-center">
                          <MapPin className="w-6 h-6 text-cyan-400" />
                        </div>
                        <div className="flex-1">
                          <p className="text-xs text-green-200/60">Current Location</p>
                          <p className="text-lg font-bold text-white">
                            {locationInfo.city}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-cyan-300">
                        <Globe className="w-4 h-4" />
                        {locationInfo.country}
                      </div>
                    </div>

                    {/* Full Address */}
                    {locationInfo.fullAddress !== '--' && (
                      <div className="p-3 bg-black/20 rounded-xl space-y-2">
                        <div className="flex items-center gap-2 text-xs text-green-200/60">
                          <MapPin className="w-3 h-3" />
                          <span>Full Address</span>
                        </div>
                        <p className="text-sm text-white leading-relaxed">
                          {locationInfo.fullAddress}
                        </p>
                      </div>
                    )}

                    {/* Location Details Grid */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-black/20 rounded-lg space-y-1">
                        <div className="flex items-center gap-1 text-xs text-green-200/60">
                          <MapPin className="w-3 h-3" />
                          Latitude
                        </div>
                        <p className="text-sm font-mono text-cyan-300">
                          {locationInfo.latitude?.toFixed(6) ?? '--'}
                        </p>
                      </div>
                      <div className="p-3 bg-black/20 rounded-lg space-y-1">
                        <div className="flex items-center gap-1 text-xs text-green-200/60">
                          <MapPin className="w-3 h-3" />
                          Longitude
                        </div>
                        <p className="text-sm font-mono text-cyan-300">
                          {locationInfo.longitude?.toFixed(6) ?? '--'}
                        </p>
                      </div>
                    </div>

                    {/* Additional Details */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2 bg-black/20 rounded-lg text-center space-y-1">
                        <p className="text-xs text-green-200/60">Accuracy</p>
                        <p className="text-sm font-medium text-white">
                          {locationInfo.accuracy?.toFixed(0) ?? '--'}m
                        </p>
                      </div>
                      <div className="p-2 bg-black/20 rounded-lg text-center space-y-1">
                        <p className="text-xs text-green-200/60">Postcode</p>
                        <p className="text-sm font-medium text-white">
                          {locationInfo.postcode}
                        </p>
                      </div>
                      <div className="p-2 bg-black/20 rounded-lg text-center space-y-1">
                        <p className="text-xs text-green-200/60">Status</p>
                        <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                          <div className="w-1.5 h-1.5 bg-green-400 rounded-full mr-1 animate-pulse" />
                          Active
                        </Badge>
                      </div>
                    </div>

                    {/* Signal and Update Time */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-black/20 rounded-lg flex items-center gap-3">
                        <Wifi className="w-4 h-4 text-green-400" />
                        <div>
                          <p className="text-xs text-green-200/60">Signal</p>
                          <p className="text-sm font-medium text-white">Strong</p>
                        </div>
                      </div>
                      <div className="p-3 bg-black/20 rounded-lg flex items-center gap-3">
                        <Zap className="w-4 h-4 text-yellow-400" />
                        <div>
                          <p className="text-xs text-green-200/60">Updates</p>
                          <p className="text-sm font-medium text-white">Real-time</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Environmental Recommendations */}
              <Card className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300 animate-in fade-in slide-in-from-bottom-10 duration-500 delay-300">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-yellow-400" />
                    Smart Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <RecommendationCard
                      icon={displayData.temperature && displayData.temperature > 30 ? <Wind className="w-8 h-8" /> : <Sun className="w-8 h-8" />}
                      title="Temperature"
                      description={displayData.temperature && displayData.temperature > 30 ? 'Hot! Use fans or cooling systems' : displayData.temperature && displayData.temperature < 15 ? 'Cold! Protect plants from cold' : 'Optimal temperature for plants'}
                      type={displayData.temperature && displayData.temperature > 30 ? 'warning' : displayData.temperature && displayData.temperature < 15 ? 'info' : 'success'}
                    />
                    <RecommendationCard
                      icon={displayData.humidity && displayData.humidity > 70 ? <CloudRain className="w-8 h-8" /> : <Droplets className="w-8 h-8" />}
                      title="Humidity"
                      description={displayData.humidity && displayData.humidity > 70 ? 'High! Reduce watering' : displayData.humidity && displayData.humidity < 30 ? 'Low! Increase watering' : 'Optimal humidity level'}
                      type={displayData.humidity && displayData.humidity > 70 ? 'warning' : displayData.humidity && displayData.humidity < 30 ? 'warning' : 'success'}
                    />
                    <RecommendationCard
                      icon={['GOOD', 'SAFE'].includes(displayData.gasStatus || '') ? <Shield className="w-8 h-8" /> : <AlertCircle className="w-8 h-8" />}
                      title="Air Quality"
                      description={displayData.gasStatus || 'Check air quality status'}
                      type={['GOOD', 'SAFE', 'SATISFACTORY'].includes(displayData.gasStatus || '') ? 'success' : 'warning'}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Device Information (Multi-Device Mode) */}
              {multiDeviceMode && (
                <Card className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300 animate-in fade-in slide-in-from-bottom-10 duration-500">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Server className="w-5 h-5 text-green-400" />
                      Device Information
                      <Badge className="ml-auto bg-green-500/30 text-green-300 border-green-500/40">
                        Multi-Device
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Device Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-xl space-y-2 border border-green-500/30">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-green-500/30 rounded-full flex items-center justify-center">
                            <Smartphone className="w-5 h-5 text-green-400" />
                          </div>
                          <div>
                            <p className="text-xs text-green-200/60">Device Name</p>
                            <p className="text-base font-bold text-white">
                              {deviceInfo?.deviceName || 'Multiple Sensors'}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="p-4 bg-black/20 rounded-xl space-y-2">
                        <p className="text-xs text-green-200/60">Device ID</p>
                        <p className="text-sm font-mono text-cyan-300">
                          {deviceInfo?.deviceId || 'Multiple-Devices-Aggregated'}
                        </p>
                      </div>

                      <div className="p-4 bg-black/20 rounded-xl space-y-2">
                        <p className="text-xs text-green-200/60">Location</p>
                        <p className="text-sm text-white">
                          {deviceInfo?.location || 'Various Locations'}
                        </p>
                      </div>

                      <div className="p-4 bg-black/20 rounded-xl space-y-2">
                        <p className="text-xs text-green-200/60">Sensor Type</p>
                        <p className="text-sm font-medium text-white">
                          {deviceInfo?.sensorType || 'ESP8266 Multi-Sensor Array'}
                        </p>
                      </div>

                      <div className="p-4 bg-black/20 rounded-xl space-y-2">
                        <p className="text-xs text-green-200/60">Last Seen</p>
                        <div className="flex items-center gap-2">
                          <Clock className="w-3 h-3 text-green-400" />
                          <p className="text-sm font-mono text-white">
                            {deviceInfo?.lastSeen || new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
                          </p>
                        </div>
                      </div>

                      <div className="p-4 bg-black/20 rounded-xl space-y-2">
                        <p className="text-xs text-green-200/60">Data Points</p>
                        <div className="flex items-center gap-2">
                          <Database className="w-3 h-3 text-green-400" />
                          <p className="text-sm font-bold text-white">{historicalData.length}</p>
                        </div>
                      </div>
                    </div>

                    {/* Device Status */}
                    <div className="p-4 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-xl border border-cyan-500/30">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-green-500/30 rounded-full flex items-center justify-center animate-pulse">
                            <Wifi className="w-4 h-4 text-green-400" />
                          </div>
                          <div>
                            <p className="text-xs text-green-200/60">Connection Status</p>
                            <p className="text-sm font-semibold text-white">All Devices Online</p>
                          </div>
                        </div>
                        <Badge className="bg-green-500/30 text-green-300 border-green-500/40">
                          <div className="w-1.5 h-1.5 bg-green-400 rounded-full mr-1 animate-pulse" />
                          Active
                        </Badge>
                      </div>
                    </div>

                    {/* Sync Info */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 bg-black/20 rounded-lg flex items-center gap-3">
                        <Cloud className="w-4 h-4 text-cyan-400" />
                        <div>
                          <p className="text-xs text-green-200/60">Sync Mode</p>
                          <p className="text-sm font-medium text-white">Real-time</p>
                        </div>
                      </div>
                      <div className="p-3 bg-black/20 rounded-lg flex items-center gap-3">
                        <Radio className="w-4 h-4 text-green-400" />
                        <div>
                          <p className="text-xs text-green-200/60">Update Rate</p>
                          <p className="text-sm font-medium text-white">Every 1 second</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* World Clock */}
              <WorldClock />
            </div>
          )}

          {/* Charts View */}
          {view === 'charts' && (
            <div className="animate-in fade-in duration-500">
              {isDemoData && (
                <div className="mb-6 p-4 bg-yellow-500/20 border border-yellow-500/30 rounded-lg flex items-center gap-3">
                  <div className="w-8 h-8 bg-yellow-500/30 rounded-full flex items-center justify-center">
                    <Shield className="w-4 h-4 text-yellow-300" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-yellow-200">Showing Demo Charts</p>
                    <p className="text-xs text-yellow-300/70">Live charts will appear when ESP8266 sends data...</p>
                  </div>
                </div>
              )}
              <DataCharts gardenData={displayData} historicalData={historicalData} />

              {/* World Clock in Charts View */}
              <div className="mt-6">
                <WorldClock />
              </div>
            </div>
          )}

          {/* Raw Data View */}
          {view === 'data' && (
            <Card className="backdrop-blur-xl bg-white/10 border-white/20 animate-in fade-in duration-500">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white flex items-center gap-2">
                    <Download className="w-5 h-5 text-green-400" />
                    Current Sensor Data
                  </CardTitle>
                  {isDemoData && (
                    <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                      Demo Data
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-black/40 rounded-lg p-6 overflow-x-auto">
                    <pre className="text-sm text-green-300 font-mono whitespace-pre-wrap">
                      {JSON.stringify(displayData, null, 2)}
                    </pre>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                    <div className="space-y-3">
                      <h4 className="text-sm font-semibold text-green-200 mb-3">Data Fields</h4>
                      <div className="space-y-2">
                        <DataField label="Temperature" value={displayData.temperature} unit="°C" />
                        <DataField label="Humidity" value={displayData.humidity} unit="%" />
                        <DataField label="AQI" value={displayData.aqi ?? displayData.gasAQI} unit="" />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h4 className="text-sm font-semibold text-green-200 mb-3">Status Information</h4>
                      <div className="space-y-2">
                        <DataField label="Light Status" value={displayData.lightStatus} unit="" />
                        <DataField label="Air Quality" value={displayData.gasStatus} unit="" />
                        <DataField label="Timestamp" value={displayData.timestamp ? new Date(displayData.timestamp).toISOString() : '--'} unit="" />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* System View */}
          {view === 'system' && (
            <div className="space-y-6 animate-in fade-in duration-500">
              <Card className="backdrop-blur-xl bg-white/10 border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Activity className="w-5 h-5 text-green-400" />
                    Detailed System Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-4 bg-black/20 rounded-xl space-y-2">
                      <div className="flex items-center gap-2">
                        <Cpu className="w-5 h-5 text-orange-400" />
                        <p className="text-xs text-green-200/60">CPU Usage</p>
                      </div>
                      <p className="text-2xl font-bold text-white">{fullSystemInfo.cpuUsage.toFixed(0)}%</p>
                      <Progress value={fullSystemInfo.cpuUsage} className="h-2 bg-white/10" />
                    </div>

                    <div className="p-4 bg-black/20 rounded-xl space-y-2">
                      <div className="flex items-center gap-2">
                        <HardDrive className="w-5 h-5 text-blue-400" />
                        <p className="text-xs text-green-200/60">Memory Usage</p>
                      </div>
                      <p className="text-2xl font-bold text-white">{fullSystemInfo.memoryUsage.toFixed(0)}%</p>
                      <Progress value={fullSystemInfo.memoryUsage} className="h-2 bg-white/10" />
                    </div>

                    <div className="p-4 bg-black/20 rounded-xl space-y-2">
                      <div className="flex items-center gap-2">
                        <Battery className="w-5 h-5 text-green-400" />
                        <p className="text-xs text-green-200/60">Device Battery</p>
                      </div>
                      <p className="text-2xl font-bold text-white">{fullSystemInfo.batteryLevel.toFixed(0)}%</p>
                      <Progress value={fullSystemInfo.batteryLevel} className="h-2 bg-white/10" />
                    </div>

                    <div className="p-4 bg-black/20 rounded-xl space-y-2">
                      <div className="flex items-center gap-2">
                        <Wifi className="w-5 h-5 text-cyan-400" />
                        <p className="text-xs text-green-200/60">Signal Quality</p>
                      </div>
                      <p className="text-2xl font-bold text-white">{fullSystemInfo.connectionQuality}</p>
                      <div className="flex gap-1 mt-2">
                        {[...Array(4)].map((_, i) => (
                          <div
                            key={i}
                            className={`h-2 flex-1 rounded-full transition-all duration-300 ${i < 3 ? 'bg-green-400' : 'bg-white/20'}`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-black/20 rounded-xl space-y-2">
                      <p className="text-xs text-green-200/60">System Uptime</p>
                      <p className="text-xl font-bold text-white">{fullSystemInfo.uptime}</p>
                    </div>
                    <div className="p-4 bg-black/20 rounded-xl space-y-2">
                      <p className="text-xs text-green-200/60">Total Data Points</p>
                      <p className="text-xl font-bold text-white">{fullSystemInfo.dataPoints}</p>
                    </div>
                    <div className="p-4 bg-black/20 rounded-xl space-y-2">
                      <p className="text-xs text-green-200/60">Last Synchronization</p>
                      <p className="text-xl font-bold text-white">{fullSystemInfo.lastSync}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Location Details */}
              <Card className="backdrop-blur-xl bg-white/10 border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Globe className="w-5 h-5 text-cyan-400" />
                    Location Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Place Information */}
                    <div className="p-4 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-xl space-y-3 border border-cyan-500/30">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-5 h-5 text-cyan-400" />
                        <p className="text-xs text-green-200/60">Place Information</p>
                      </div>
                      <div className="space-y-2">
                        <div className="p-2 bg-black/20 rounded-lg">
                          <p className="text-xs text-green-200/60 mb-1">City / Town</p>
                          <p className="text-base font-bold text-white">{locationInfo.city}</p>
                        </div>
                        <div className="p-2 bg-black/20 rounded-lg">
                          <p className="text-xs text-green-200/60 mb-1">Country</p>
                          <p className="text-base font-medium text-white">{locationInfo.country}</p>
                        </div>
                        {locationInfo.postcode !== '--' && (
                          <div className="p-2 bg-black/20 rounded-lg">
                            <p className="text-xs text-green-200/60 mb-1">Postcode / ZIP</p>
                            <p className="text-sm font-mono text-white">{locationInfo.postcode}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Full Address */}
                    {locationInfo.fullAddress !== '--' && (
                      <div className="p-4 bg-black/20 rounded-xl space-y-3">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-5 h-5 text-green-400" />
                          <p className="text-xs text-green-200/60">Full Address</p>
                        </div>
                        <p className="text-sm text-white leading-relaxed">
                          {locationInfo.fullAddress}
                        </p>
                      </div>
                    )}

                    {/* GPS Coordinates */}
                    <div className="p-4 bg-black/20 rounded-xl space-y-3">
                      <div className="flex items-center gap-2">
                        <Satellite className="w-5 h-5 text-green-400" />
                        <p className="text-xs text-green-200/60">GPS Coordinates</p>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                          <span className="text-sm text-green-200/60">Latitude</span>
                          <span className="text-sm font-mono text-cyan-300">{locationInfo.latitude?.toFixed(8) ?? '--'}</span>
                        </div>
                        <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                          <span className="text-sm text-green-200/60">Longitude</span>
                          <span className="text-sm font-mono text-cyan-300">{locationInfo.longitude?.toFixed(8) ?? '--'}</span>
                        </div>
                        <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                          <span className="text-sm text-green-200/60">Accuracy</span>
                          <span className="text-sm font-mono text-white">±{locationInfo.accuracy?.toFixed(2) ?? '--'} meters</span>
                        </div>
                      </div>
                    </div>

                    {/* Status & Updates */}
                    <div className="p-4 bg-black/20 rounded-xl space-y-3">
                      <div className="flex items-center gap-2">
                        <Satellite className="w-5 h-5 text-green-400" />
                        <p className="text-xs text-green-200/60">Status & Updates</p>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                          <span className="text-sm text-green-200/60">Last Update</span>
                          <span className="text-sm text-white">
                            {locationInfo.timestamp ? new Date(locationInfo.timestamp).toLocaleString() : '--'}
                          </span>
                        </div>
                        <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                          <span className="text-sm text-green-200/60">Status</span>
                          <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Active
                          </Badge>
                        </div>
                        <div className="flex justify-between p-2 bg-black/30 rounded-lg">
                          <span className="text-sm text-green-200/60">Data Source</span>
                          <span className="text-sm text-white">OpenStreetMap</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>

        {/* Footer with Branding */}
        <footer className="bg-black/30 backdrop-blur-lg border-t border-white/10 mt-auto">
          <div className="container mx-auto px-4 py-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
              <div className="text-center md:text-left space-y-1">
                <p className="text-sm font-bold text-green-100 flex items-center justify-center md:justify-start gap-2">
                  <Sparkles className="w-4 h-4" />
                  MADE BY AARUTO
                </p>
                <p className="text-xs text-green-200/60">
                  POWERED BY CHRONOBOTICS
                </p>
              </div>

              <div className="text-center space-y-1">
                <p className="text-xs text-green-200/60">
                  Smart Garden Monitoring System v2.0
                </p>
                <p className="text-xs text-green-300/40">
                  Next.js 15 • TypeScript • Tailwind CSS
                </p>
              </div>

              <div className="text-center md:text-right">
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30 flex items-center justify-center md:justify-end gap-2">
                  <CheckCircle className="w-3 h-3 animate-pulse" />
                  System Online
                </Badge>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}

interface SensorCardProps {
  icon: React.ReactNode
  title: string
  value: number | string
  unit: string
  color: string
  bgColor: string
  description: React.ReactNode
  isStatusCard?: boolean
  trend?: 'high' | 'low' | 'normal'
}

function SensorCard({ icon, title, value, unit, color, bgColor, description, isStatusCard, trend }: SensorCardProps) {
  const getTrendIcon = () => {
    if (trend === 'high') return <TrendingUp className="w-4 h-4" />
    if (trend === 'low') return <TrendingDown className="w-4 h-4" />
    return null
  }

  return (
    <Card className={`backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-green-500/20 group ${isStatusCard ? bgColor : ''}`}>
      <CardContent className="p-6">
        <div className="flex flex-col items-center text-center space-y-4">
          {/* Icon */}
          <div className={`p-4 rounded-full ${color} bg-black/20 min-w-20 min-h-20 flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}>
            {icon}
          </div>

          {/* Title */}
          <h3 className="text-sm font-medium text-green-200/80">
            {title}
          </h3>

          {/* Value */}
          <div className="space-y-1">
            <p className={`text-4xl font-bold ${color} transition-all duration-300 group-hover:scale-110`}>
              {value}
              <span className="text-xl ml-1 opacity-80">{unit}</span>
            </p>

            {/* Trend indicator */}
            {trend && trend !== 'normal' && (
              <div className={`flex items-center justify-center gap-1 text-xs ${trend === 'high' ? 'text-red-400' : 'text-blue-400'}`}>
                {getTrendIcon()}
                <span>{trend === 'high' ? 'High' : 'Low'}</span>
              </div>
            )}

            <div className="text-xs text-green-200/60">
              {description}
            </div>
          </div>

          {/* Status Badge for status cards */}
          {isStatusCard && (
            <Badge className={`${color} ${bgColor} border-0 animate-pulse`}>
              Active
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

interface QuickStatCardProps {
  icon: React.ReactNode
  title: string
  value: string
  color: string
  bgColor: string
}

function QuickStatCard({ icon, title, value, color, bgColor }: QuickStatCardProps) {
  return (
    <Card className={`${bgColor} backdrop-blur-xl border border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105 hover:shadow-xl`}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${color} bg-black/20 flex items-center justify-center`}>
            {icon}
          </div>
          <div className="flex-1">
            <p className="text-xs text-green-200/60">{title}</p>
            <p className={`text-lg font-bold ${color}`}>{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

interface RecommendationCardProps {
  icon: React.ReactNode
  title: string
  description: string
  type: 'success' | 'warning' | 'info'
}

function RecommendationCard({ icon, title, description, type }: RecommendationCardProps) {
  const typeStyles = {
    success: 'bg-green-500/10 border-green-500/20 text-green-400',
    warning: 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400',
    info: 'bg-blue-500/10 border-blue-500/20 text-blue-400'
  }

  return (
    <Card className={`${typeStyles[type]} border backdrop-blur-xl hover:bg-white/20 transition-all duration-300 hover:scale-105 hover:-translate-y-1`}>
      <CardContent className="p-4">
        <div className="flex gap-4">
          <div className={`p-2 rounded-lg ${typeStyles[type]} bg-black/20 flex items-center justify-center flex-shrink-0`}>
            {icon}
          </div>
          <div className="flex-1 space-y-2">
            <h4 className="text-sm font-semibold text-white">{title}</h4>
            <p className="text-xs text-green-200/80">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

interface DataFieldProps {
  label: string
  value: number | undefined | string
  unit: string
}

function DataField({ label, value, unit }: DataFieldProps) {
  return (
    <div className="flex justify-between items-center p-3 bg-black/20 rounded-lg hover:bg-black/30 transition-colors duration-300">
      <span className="text-sm text-green-200/80">{label}</span>
      <span className="text-sm font-medium text-white font-mono">
        {value !== undefined ? `${value} ${unit}` : '--'}
      </span>
    </div>
  )
}
