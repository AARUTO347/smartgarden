'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { Thermometer, Droplets, Flame } from 'lucide-react'
import { GardenData } from '@/lib/app-logic'

interface DataChartsProps {
  gardenData: GardenData | null
  historicalData?: GardenData[]
}

export default function DataCharts({ gardenData, historicalData = [] }: DataChartsProps) {
  // Combine current data with historical data
  const allData = historicalData.length > 0 ? [...historicalData] : []

  // Add current data if available
  if (gardenData) {
    allData.push(gardenData)
  }

  // Generate demo historical data if no real data exists
  const displayData = allData.length > 0 ? allData : generateDemoData()

  // Use current time for all chart timestamps to match "last update"
  const currentTime = Date.now()

  // Prepare data for charts - use current time as base for all points
  const chartData = displayData.map((data, index) => {
    // Calculate time offset for historical effect (2.5 minutes per point, going backwards)
    const timeOffset = (displayData.length - 1 - index) * 2.5 * 60 * 1000
    const pointTime = currentTime - timeOffset

    return {
      name: new Date(pointTime).toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }),
      temperature: data.temperature || 0,
      humidity: data.humidity || 0,
      gasAQI: (data.aqi ?? data.gasAQI ?? data.gasLevel) || 0
    }
  })

  // Calculate temperature range
  const tempValues = chartData.map(d => d.temperature).filter(v => v !== undefined && v !== null)
  const tempMin = tempValues.length > 0 ? Math.min(...tempValues) : 20
  const tempMax = tempValues.length > 0 ? Math.max(...tempValues) : 30

  // Calculate humidity range
  const humidityValues = chartData.map(d => d.humidity).filter(v => v !== undefined && v !== null)
  const humidityMin = humidityValues.length > 0 ? Math.min(...humidityValues) : 50
  const humidityMax = humidityValues.length > 0 ? Math.max(...humidityValues) : 80

  // Calculate AQI range
  const gasValues = chartData.map(d => d.gasAQI).filter(v => v !== undefined && v !== null)
  const gasMin = gasValues.length > 0 ? Math.min(...gasValues) : 50
  const gasMax = gasValues.length > 0 ? Math.max(...gasValues) : 200

  return (
    <div className="space-y-6">
      {/* Temperature & Humidity Line Chart */}
      <Card className="backdrop-blur-xl bg-white/10 border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Thermometer className="w-5 h-5 text-orange-400" />
            <Droplets className="w-5 h-5 text-blue-400" />
            Temperature & Humidity Trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <defs>
                <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="humidityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis
                dataKey="name"
                stroke="#86efac"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="#86efac"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                domain={[Math.floor(tempMin - 2), Math.ceil(tempMax + 2)]}
                tickFormatter={(value: any) => String(Math.round(value))}
                allowDecimals={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(0,0,0,0.8)',
                  border: '1px solid rgba(255,255,255,0.2)',
                  borderRadius: '8px',
                  color: 'white'
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="temperature"
                stroke="#f97316"
                strokeWidth={3}
                dot={{ r: 3 }}
                activeDot={{ r: 5 }}
                name="Temperature (°C)"
              />
              <Line
                type="monotone"
                dataKey="humidity"
                stroke="#3b82f6"
                strokeWidth={3}
                dot={{ r: 3 }}
                activeDot={{ r: 5 }}
                name="Humidity (%)"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Gas Level Bar Chart */}
      <Card className="backdrop-blur-xl bg-white/10 border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Flame className="w-5 h-5 text-yellow-400" />
            AQI HISTORY
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis
                dataKey="name"
                stroke="#86efac"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="#86efac"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                domain={[Math.floor(gasMin - 20), Math.ceil(gasMax + 20)]}
                tickFormatter={(value: any) => String(Math.round(value))}
                allowDecimals={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(0,0,0,0.8)',
                  border: '1px solid rgba(255,255,255,0.2)',
                  borderRadius: '8px',
                  color: 'white'
                }}
              />
              <Legend />
              <Bar
                dataKey="gasAQI"
                name="AQI Level"
                fill="#fbbf24"
                radius={[8, 8, 0, 0]}
                opacity={0.8}
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}

// Generate demo data for charts (Indian AQI Standard) - More realistic variations
function generateDemoData(): GardenData[] {
  const data: GardenData[] = []
  const baseTime = Date.now() - 2 * 60 * 60 * 1000 // 2 hours ago for more recent data

  // Starting values
  let temp = 24 + Math.random() * 4
  let humidity = 60 + Math.random() * 15
  let aqiValue = 100 + Math.random() * 50
  let isDay = new Date(baseTime).getHours() >= 6 && new Date(baseTime).getHours() < 18

  for (let i = 0; i < 50; i++) {
    const currentTime = baseTime + i * 2.5 * 60 * 1000 // Every 2.5 minutes
    const hour = new Date(currentTime).getHours()

    // Update day/night status based on time
    const newIsDay = hour >= 6 && hour < 18
    if (isDay !== newIsDay) {
      isDay = newIsDay
      // Temperature changes at day/night transition
      temp += isDay ? 2 : -2
    }

    // More realistic temperature variations
    // Lower in early morning, peaks in afternoon, drops at night
    if (hour >= 6 && hour < 14) {
      temp += (Math.random() - 0.3) * 0.5 // Rising in morning
    } else if (hour >= 14 && hour < 18) {
      temp += (Math.random() - 0.6) * 0.5 // Peaking afternoon
    } else {
      temp += (Math.random() - 0.5) * 0.3 // Cooling at night
    }

    // Keep temperature in realistic range (18-35°C)
    temp = Math.max(18, Math.min(35, temp))

    // Humidity inversely related to temperature typically
    humidity += (Math.random() - 0.5) * 2
    if (temp > 30) {
      humidity -= 0.3 // Hotter = lower humidity typically
    } else if (temp < 22) {
      humidity += 0.3 // Cooler = higher humidity
    }
    humidity = Math.max(35, Math.min(95, humidity))

    // AQI variations - influenced by time of day and random factors
    aqiValue += (Math.random() - 0.5) * 30
    // Rush hours typically have higher AQI (7-9 AM and 5-7 PM)
    if ((hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19)) {
      aqiValue += Math.random() * 20
    }
    aqiValue = Math.max(20, Math.min(450, aqiValue))

    // Determine gas status based on AQI (Indian Standard CPCB)
    let gasStatus: 'GOOD' | 'SATISFACTORY' | 'MODERATE' | 'POOR' | 'VERY_POOR' | 'SEVERE'
    if (aqiValue <= 50) {
      gasStatus = 'GOOD'
    } else if (aqiValue <= 100) {
      gasStatus = 'SATISFACTORY'
    } else if (aqiValue <= 200) {
      gasStatus = 'MODERATE'
    } else if (aqiValue <= 300) {
      gasStatus = 'POOR'
    } else if (aqiValue <= 400) {
      gasStatus = 'VERY_POOR'
    } else {
      gasStatus = 'SEVERE'
    }

    data.push({
      temperature: Math.round(temp * 10) / 10,
      humidity: Math.round(humidity * 10) / 10,
      gasLevel: Math.round(aqiValue),
      gasAQI: Math.round(aqiValue),
      aqi: Math.round(aqiValue),
      gasStatus: gasStatus,
      lightStatus: isDay ? 'DAY' : 'NIGHT',
      timestamp: currentTime
    })
  }

  return data
}
