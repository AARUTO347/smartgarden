'use client'

import { useState } from 'react'
import { authenticateUser as authUser, getCurrentUser, setCurrentUser, logout as userLogout } from '@/lib/user-store'

export interface AuthState {
  isAuthenticated: boolean
  username: string | null
  email: string | null
  deviceId: string | null
  location: string | null
  isAdmin: boolean
  isLoading: boolean
}

export function useSession() {
  console.log('🔌 useSession: START OF FUNCTION')
  
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    username: null,
    email: null,
    deviceId: null,
    location: null,
    isAdmin: false,
    isLoading: false,  // Start with false
  })

  console.log('🔌 useSession: State initialized:', authState)
  
  const login = (username: string, password: string): boolean => {
    console.log('🔑 login attempt:', { username, password })
    const user = authUser(username, password)
    console.log('🔑 login result user:', user)
    if (user) {
      setCurrentUser(user)
      setAuthState({
        isAuthenticated: true,
        username: user.username,
        email: user.email,
        deviceId: user.deviceId,
        location: user.location,
        isAdmin: user.isAdmin || false,
        isLoading: false,
      })
      console.log('✅ login successful')
      return true
    }
    console.log('❌ login failed')
    return false
  }

  const logout = () => {
    userLogout()
    setAuthState({
      isAuthenticated: false,
      username: null,
      email: null,
      deviceId: null,
      location: null,
      isAdmin: false,
      isLoading: false,
    })
  }

  console.log('🔌 useSession: END OF FUNCTION, returning state')
  
  return {
    ...authState,
    login,
    logout,
  }
}
