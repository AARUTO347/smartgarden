import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable'
import { GardenData } from './app-logic'

/**
 * Device information interface for multi-device support
 */
export interface DeviceInfo {
  deviceId: string
  deviceName: string
  location: string
  sensorType: string
  lastSeen: string
}

/**
 * PDF export options interface
 */
export interface PDFExportOptions {
  title?: string
  includeCharts?: boolean
  includeDeviceInfo?: boolean
  theme?: 'light' | 'dark'
}

/**
 * Smart Garden theme colors matching dashboard
 */
const THEME = {
  primary: [34, 197, 94],    // Green-500
  primaryDark: [21, 128, 61],  // Green-700
  secondary: [16, 185, 129],  // Emerald-500
  accent: [251, 191, 36],   // Amber-400
  text: [30, 41, 59],         // Slate-800
  textLight: [148, 163, 184], // Slate-300
  bgLight: [255, 255, 255],  // White
  bgGray: [249, 250, 251],  // Slate-50
  danger: [239, 68, 68],    // Red-500
  success: [34, 197, 94],    // Green-500
  warning: [251, 191, 36],   // Amber-400
}

/**
 * Export garden data to PDF format with live timestamp
 * @param data - Array of garden data entries
 * @param deviceInfo - Device information for multi-device support
 * @param options - PDF export options
 */
export function exportToPDF(
  data: GardenData[],
  deviceInfo?: DeviceInfo,
  options: PDFExportOptions = {}
): void {
  if (data.length === 0) {
    console.warn('No data to export')
    return
  }

  const {
    title = 'Smart Garden Dashboard Report',
    includeCharts = true,
    includeDeviceInfo = true,
    theme = 'light'
  } = options

  // Create PDF document (A4 size, portrait)
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  })

  const pageWidth = doc.internal.pageSize.getWidth()
  const pageHeight = doc.internal.pageSize.getHeight()
  const margin = 15
  const contentWidth = pageWidth - (margin * 2)

  // --- HEADER SECTION ---
  const headerHeight = 45

  // Background gradient effect (simulated with rectangles)
  doc.setFillColor(...THEME.primary)
  doc.rect(0, 0, pageWidth, headerHeight, 'F')

  doc.setFillColor(...THEME.primaryDark)
  doc.rect(0, headerHeight - 10, pageWidth, 10, 'F')

  // Title
  doc.setTextColor(...THEME.bgLight)
  doc.setFontSize(22)
  doc.setFont('helvetica', 'bold')
  doc.text(title, margin, 15)

  // Subtitle
  doc.setFontSize(10)
  doc.setFont('helvetica', 'normal')
  doc.text('IoT Monitoring System v2.0', margin, 22)

  // Live update time - using current time
  const liveTime = new Date()
  const updateDateTime = liveTime.toLocaleString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  })

  doc.setFontSize(9)
  doc.text(`Last Updated: ${updateDateTime}`, margin, 30)

  // Report ID
  const reportId = `RPT-${liveTime.getFullYear()}${(liveTime.getMonth() + 1).toString().padStart(2, '0')}${liveTime.getDate().toString().padStart(2, '0')}-${Date.now().toString().slice(-6)}`
  doc.setFontSize(8)
  doc.text(`Report ID: ${reportId}`, margin, 35)

  // --- DEVICE INFO SECTION (if enabled) ---
  if (includeDeviceInfo) {
    let yPos = headerHeight + 12

    doc.setFillColor(...THEME.bgGray)
    doc.roundedRect(margin, yPos - 8, contentWidth, 28, 3, 3, 'FD')

    doc.setFillColor(...THEME.primary)
    doc.circle(margin + 5, yPos + 4, 3, 'F')

    doc.setTextColor(...THEME.text)
    doc.setFontSize(11)
    doc.setFont('helvetica', 'bold')
    doc.text('Device Information', margin + 12, yPos + 4)

    if (deviceInfo) {
      yPos += 12
      doc.setFontSize(9)
      doc.setFont('helvetica', 'normal')

      const deviceData = [
        [`Device ID: ${deviceInfo.deviceId}`, `Last Seen: ${deviceInfo.lastSeen}`],
        [`Device Name: ${deviceInfo.deviceName}`, `Sensor Type: ${deviceInfo.sensorType}`],
        [`Location: ${deviceInfo.location}`, ``]
      ]

      deviceData.forEach((row, i) => {
        row.forEach((text, j) => {
          if (text) {
            doc.text(text, margin + 8, yPos + (i * 6) + (j * 2.5))
          }
        })
      })
    } else {
      yPos += 12
      doc.setFontSize(9)
      doc.setFont('helvetica', 'normal')
      doc.text('Multiple Devices: Data aggregated from all connected sensors', margin + 8, yPos)
    }

    yPos += 10
  } else {
    yPos = headerHeight + 12
  }

  // --- SUMMARY CARDS SECTION ---
  const latestData = data[data.length - 1]
  const avgTemp = data.reduce((sum, d) => sum + (d.temperature || 0), 0) / data.length
  const avgHumidity = data.reduce((sum, d) => sum + (d.humidity || 0), 0) / data.length
  const avgAQI = data.reduce((sum, d) => sum + (d.aqi || d.gasAQI || d.gasLevel || 0), 0) / data.length

  const summaryData = [
    {
      label: 'Temperature',
      value: `${latestData?.temperature?.toFixed(1) || '--'} °C`,
      avg: `Avg: ${avgTemp.toFixed(1)}°C`,
      status: latestData?.temperature ? (latestData.temperature > 30 ? 'High' : latestData.temperature < 15 ? 'Low' : 'Normal') : '--',
      color: latestData?.temperature > 30 ? THEME.warning : latestData?.temperature < 15 ? THEME.primary : THEME.success
    },
    {
      label: 'Humidity',
      value: `${latestData?.humidity?.toFixed(1) || '--'} %`,
      avg: `Avg: ${avgHumidity.toFixed(1)}%`,
      status: latestData?.humidity ? (latestData.humidity > 70 ? 'High' : latestData.humidity < 30 ? 'Low' : 'Normal') : '--',
      color: latestData?.humidity > 70 ? THEME.warning : latestData?.humidity < 30 ? THEME.primary : THEME.success
    },
    {
      label: 'Air Quality',
      value: latestData?.aqi || latestData?.gasAQI || '--',
      avg: `Avg: ${Math.round(avgAQI)}`,
      status: latestData?.gasStatus || '--',
      color: latestData?.gasStatus?.includes('POOR') || latestData?.gasStatus?.includes('SEVERE') ? THEME.danger :
             latestData?.gasStatus?.includes('MODERATE') ? THEME.warning : THEME.success
    },
    {
      label: 'Light Status',
      value: latestData?.lightStatus || '--',
      avg: latestData?.lightStatus === 'DAY' ? 'Daytime' : 'Nighttime',
      status: latestData?.lightStatus === 'DAY' ? 'Active' : 'Inactive',
      color: THEME.primary
    }
  ]

  yPos += 5
  doc.setFillColor(...THEME.bgGray)
  doc.roundedRect(margin, yPos - 5, contentWidth, 45, 3, 3, 'FD')

  doc.setFillColor(...THEME.primary)
  doc.circle(margin + 5, yPos, 3, 'F')

  doc.setTextColor(...THEME.text)
  doc.setFontSize(11)
  doc.setFont('helvetica', 'bold')
  doc.text('Current Status Summary', margin + 12, yPos)

  // Summary cards in grid
  yPos += 8
  const cardWidth = (contentWidth - 15) / 2
  const cardHeight = 16

  summaryData.forEach((item, i) => {
    const x = margin + (i % 2 === 0 ? 0 : cardWidth + 5)
    const y = yPos + Math.floor(i / 2) * (cardHeight + 4)

    // Card background
    doc.setFillColor(...THEME.bgLight)
    doc.roundedRect(x, y, cardWidth, cardHeight, 2, 2, 'FD')

    // Value label
    doc.setFontSize(8)
    doc.setTextColor(...THEME.textLight)
    doc.setFont('helvetica', 'normal')
    doc.text(item.label, x + 3, y + 5)

    // Value
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.setTextColor(...item.color)
    doc.text(item.value, x + 3, y + 10)

    // Status and avg
    doc.setFontSize(7)
    doc.setTextColor(...THEME.textLight)
    doc.text(`${item.status} | ${item.avg}`, x + 3, y + 14)
  })

  yPos += 55

  // --- DATA TABLE SECTION ---
  doc.setFillColor(...THEME.primary)
  doc.roundedRect(margin, yPos - 5, contentWidth, 7, 2, 2, 'FD')

  doc.setTextColor(...THEME.bgLight)
  doc.setFontSize(11)
  doc.setFont('helvetica', 'bold')
  doc.text('Historical Data Records', margin + 7, yPos + 1)

  // Prepare table data
  const tableData = data.slice(-50).map((entry, index) => {
    const timestamp = entry.timestamp ? new Date(entry.timestamp) : new Date()
    return [
      index + 1,
      timestamp.toLocaleDateString('en-US'),
      timestamp.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
      `${entry.temperature?.toFixed(1) || '--'} °C`,
      `${entry.humidity?.toFixed(1) || '--'} %`,
      entry.lightStatus || '--',
      entry.aqi || entry.gasAQI || entry.gasLevel || '--',
      entry.gasStatus || '--'
    ]
  })

  // Create table
  autoTable(doc, {
    startY: yPos + 5,
    head: [['#', 'Date', 'Time', 'Temperature', 'Humidity', 'Light', 'AQI', 'Air Quality']],
    body: tableData,
    theme: 'grid',
    styles: {
      fontSize: 8,
      cellPadding: 3,
      lineColor: [200, 200, 200],
      lineWidth: 0.1
    },
    headStyles: {
      fillColor: [...THEME.primary],
      textColor: [...THEME.bgLight],
      fontStyle: 'bold',
      fontSize: 9
    },
    columnStyles: {
      0: { cellWidth: 10 },  // #
      1: { cellWidth: 35 },  // Date
      2: { cellWidth: 28 },  // Time
      3: { cellWidth: 30 },  // Temperature
      4: { cellWidth: 25 },  // Humidity
      5: { cellWidth: 20 },  // Light
      6: { cellWidth: 18 },  // AQI
      7: { cellWidth: 32 }   // Air Quality
    },
    alternateRowStyles: {
      fillColor: [249, 250, 251]
    },
    didDrawPage: (data) => {
      doc.setPageNumber(data.pageNumber)
      doc.setFontSize(8)
      doc.setTextColor(...THEME.textLight)
      doc.text(
        `Page ${data.pageNumber} of ${doc.internal.getNumberOfPages()}`,
        pageWidth / 2 - 20,
        pageHeight - 10,
        { align: 'center' }
      )
    }
  })

  // --- FOOTER ---
  const finalY = (doc as any).lastAutoTable.finalY || 250

  doc.setFillColor(...THEME.bgGray)
  doc.rect(0, pageHeight - 20, pageWidth, 20, 'F')

  doc.setDrawColor(...THEME.primary)
  doc.setLineWidth(0.5)
  doc.line(margin, pageHeight - 20, pageWidth - margin, pageHeight - 20)

  doc.setFontSize(8)
  doc.setTextColor(...THEME.textLight)

  // Footer information
  doc.text(`Report generated: ${updateDateTime}`, margin, pageHeight - 15)
  doc.text('Smart Garden Pro • IoT Monitoring System', margin, pageHeight - 11)
  doc.text('© 2025 All rights reserved', margin, pageHeight - 7)
  doc.text(reportId, pageWidth - margin - 30, pageHeight - 7, { align: 'right' })

  // --- ADD SECOND PAGE IF NEEDED FOR MULTI-DEVICE ---
  if (includeDeviceInfo && deviceInfo) {
    doc.addPage()

    // Device detailed information
    doc.setFillColor(...THEME.primary)
    doc.rect(0, 0, pageWidth, 40, 'F')

    doc.setTextColor(...THEME.bgLight)
    doc.setFontSize(18)
    doc.setFont('helvetica', 'bold')
    doc.text('Device Details', margin, 15)

    doc.setFontSize(10)
    doc.text(`Report ID: ${reportId}`, margin, 22)
    doc.text(`Last Updated: ${updateDateTime}`, margin, 28)

    // Device information table
    const deviceTableData = [
      ['Device ID', deviceInfo.deviceId],
      ['Device Name', deviceInfo.deviceName],
      ['Location', deviceInfo.location],
      ['Sensor Type', deviceInfo.sensorType],
      ['Last Seen', deviceInfo.lastSeen],
      ['Data Points', data.length.toString()],
      ['Temperature Range', `${Math.min(...data.map(d => d.temperature || 0)).toFixed(1)}°C - ${Math.max(...data.map(d => d.temperature || 0)).toFixed(1)}°C`],
      ['Humidity Range', `${Math.min(...data.map(d => d.humidity || 0)).toFixed(1)}% - ${Math.max(...data.map(d => d.humidity || 0)).toFixed(1)}%`],
      ['AQI Range', `${Math.min(...data.map(d => d.aqi || d.gasAQI || d.gasLevel || 0))} - ${Math.max(...data.map(d => d.aqi || d.gasAQI || d.gasLevel || 0))}`]
    ]

    autoTable(doc, {
      startY: 50,
      head: [['Parameter', 'Value']],
      body: deviceTableData,
      theme: 'striped',
      styles: {
        fontSize: 9,
        cellPadding: 4,
        lineColor: [200, 200, 200]
      },
      headStyles: {
        fillColor: [...THEME.secondary],
        textColor: [...THEME.bgLight],
        fontStyle: 'bold'
      },
      columnStyles: {
        0: { cellWidth: 50, fontStyle: 'bold' },
        1: { cellWidth: contentWidth - 50 }
      }
    })
  }

  // --- GENERATE FILENAME AND DOWNLOAD ---
  const filename = `smart-garden-report-${liveTime.toISOString().split('T')[0]}.pdf`

  doc.save(filename)
  console.log(`PDF exported successfully: ${filename}`)
}

/**
 * Export current single data point to PDF
 * @param data - Single garden data entry
 * @param deviceInfo - Device information
 * @param options - PDF export options
 */
export function exportCurrentToPDF(
  data: GardenData | null,
  deviceInfo?: DeviceInfo,
  options?: PDFExportOptions
): void {
  if (!data) {
    console.warn('No data to export')
    return
  }

  exportToPDF([data], deviceInfo, {
    ...options,
    title: 'Smart Garden - Current Reading'
  })
}

/**
 * Generate mock device info for multi-device demo
 */
export function generateMockDeviceInfo(): DeviceInfo {
  const deviceId = `DEV-${Math.random().toString(36).substr(2, 6).toUpperCase()}`
  const locations = ['Garden Zone A', 'Greenhouse', 'Outdoor Sensors', 'Indoor Plants', 'Balcony Garden']

  return {
    deviceId,
    deviceName: `Smart Sensor ${deviceId}`,
    location: locations[Math.floor(Math.random() * locations.length)],
    sensorType: 'ESP8266 Multi-Sensor',
    lastSeen: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })
  }
}
