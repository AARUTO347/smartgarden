'use client'

import { useEffect, useState, useRef } from 'react'
import { ref, onValue, off, DatabaseReference } from 'firebase/database'

export interface GardenData {
  temperature?: number
  humidity?: number
  gasLevel?: number
  gasAQI?: number
  aqi?: number
  gasStatus?: string
  lightStatus?: string
  gardenLight?: 'ON' | 'OFF'
  device_id?: string        // NEW: Device ID from Firebase
  timestamp?: number
}

type DataCallback = (data: GardenData | null) => void

let currentListener: DatabaseReference | null = null

/**
 * Subscribe to realtime garden data updates
 * @param callback - Function to call when data updates
 */
export function subscribeToGardenData(dataRef: DatabaseReference, callback: DataCallback): () => void {
  // Unsubscribe from any existing listener
  unsubscribeFromGardenData()

  // Check if dataRef is valid
  if (!dataRef) {
    console.warn('⚠️ Firebase dataRef is null, skipping subscription')
    callback(null)
    return () => {}
  }

  currentListener = dataRef

  console.log('📡 Subscribing to Firebase path:', dataRef.toString())
  console.log('📡 Reference:', dataRef.toString())
  console.log('📡 Using device-specific Firebase path: /garden/live/{DEVICE_ID}/')

  onValue(
    dataRef,
    (snapshot) => {
      const data = snapshot.val()
      console.log('📡 Firebase data received:', data)
      console.log('📡 Snapshot exists:', snapshot.exists())
      console.log('📡 Snapshot key:', snapshot.key)
      console.log('📡 Data keys:', data ? Object.keys(data) : 'null')
      console.log('📡 Device ID:', data?.device_id || 'Not connected')

      if (!snapshot.exists()) {
        console.warn('⚠️ Firebase path is empty - showing demo data')
      } else if (data && typeof data === 'object') {
        console.log('✅ Valid data received from Firebase')
      }

      callback(data)
    },
    (error) => {
      console.error('❌ Firebase data error:', error)
      console.error('❌ Error code:', error.code)
      console.error('❌ Error message:', error.message)
      console.error('❌ Error details:', error.details)
      callback(null)
    }
  )
  // Return unsubscribe function
  return () => {
    console.log('🧹 Unsubscribing from Firebase')
    off(dataRef)
    currentListener = null
  }
}

/**
 * Unsubscribe from current data listener
 */
export function unsubscribeFromGardenData(): void {
  if (currentListener) {
    off(currentListener)
    currentListener = null
  }
}

/**
 * Get gas status color for UI
 * @param status - Gas status (Indian AQI Standard: GOOD, SATISFACTORY, MODERATE, POOR, VERY_POOR, SEVERE)
 * @returns CSS color class
 */
export function getGasStatusColor(status: string): string {
  switch (status) {
    case 'GOOD':
    case 'SAFE':
      return 'text-green-500'
    case 'SATISFACTORY':
    case 'WARNING':
    case 'MODERATE':
      return 'text-yellow-500'
    case 'POOR':
    case 'UNHEALTHY':
      return 'text-orange-500'
    case 'VERY_POOR':
    case 'VERY_UNHEALTHY':
      return 'text-red-400'
    case 'SEVERE':
    case 'DANGER':
    case 'DANGEROUS':
    case 'HAZARDOUS':
      return 'text-red-600'
    default:
      return 'text-gray-500'
  }
}

/**
 * Get gas status background color
 * @param status - Gas status (Indian AQI Standard: GOOD, SATISFACTORY, MODERATE, POOR, VERY_POOR, SEVERE)
 * @returns CSS background color class
 */
export function getGasStatusBgColor(status: string): string {
  switch (status) {
    case 'GOOD':
    case 'SAFE':
      return 'bg-green-500/20 border-green-500/30'
    case 'SATISFACTORY':
    case 'WARNING':
    case 'MODERATE':
      return 'bg-yellow-500/20 border-yellow-500/30'
    case 'POOR':
    case 'UNHEALTHY':
      return 'bg-orange-500/20 border-orange-500/30'
    case 'VERY_POOR':
    case 'VERY_UNHEALTHY':
      return 'bg-red-400/20 border-red-400/30'
    case 'SEVERE':
    case 'DANGER':
    case 'DANGEROUS':
    case 'HAZARDOUS':
      return 'bg-red-600/20 border-red-600/30'
    default:
      return 'bg-gray-500/20 border-gray-500/30'
  }
}

/**
 * Get light status icon color
 * @param status - Light status (DAY, NIGHT)
 * @returns CSS color class
 */
export function getLightStatusColor(status: string): string {
  switch (status) {
    case 'DAY':
      return 'text-yellow-500'
    case 'NIGHT':
      return 'text-blue-400'
    default:
      return 'text-gray-500'
  }
}

/**
 * Get garden light status color
 * @param status - Garden light status (ON, OFF)
 * @returns CSS color class
 */
export function getGardenLightColor(status: string): string {
  switch (status) {
    case 'ON':
      return 'text-green-500'
    case 'OFF':
      return 'text-gray-500'
    default:
      return 'text-gray-500'
  }
}

/**
 * Get garden light background color
 * @param status - Garden light status (ON, OFF)
 * @ @returns CSS background color class
 */
export function getGardenLightBgColor(status: string): string {
  switch (status) {
    case 'ON':
      return 'bg-green-500/20 border-green-500/30'
    case 'OFF':
      return 'bg-gray-500/20 border-gray-500/30'
    default:
      return 'bg-gray-500/20 border-gray-500/30'
  }
}

/**
 * Automatically determine garden light status based on light status
 * @param lightStatus - Light status (DAY, NIGHT)
 * @returns Garden light status (ON, OFF)
 *
 * Logic: NIGHT → Garden Light ON, DAY → Garden Light OFF
 */
export function determineGardenLight(lightStatus: string | undefined): 'ON' | 'OFF' {
  if (!lightStatus) return 'OFF'
  return lightStatus === 'NIGHT' ? 'ON' : 'OFF'
}

/**
 * Hook to subscribe to garden data on client side
 */
export function useGardenData(dataRef: DatabaseReference | null) {
  const [gardenData, setGardenData] = useState<GardenData | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const isMounted = useRef(true)

  useEffect(() => {
    isMounted.current = true

    console.log('🔌 useGardenData effect triggered')
    console.log('🔌 dataRef:', dataRef)
    console.log('🔌 isMounted:', isMounted.current)

    if (!dataRef) {
      console.warn('⚠️ dataRef is null, not subscribing')
      setIsConnected(false)
      return
    }

    console.log('📡 Subscribing to Firebase data...')
    console.log('📡 Device-specific Firebase path: /garden/live/{DEVICE_ID}/')

    const unsubscribe = subscribeToGardenData(dataRef, (data) => {
      console.log('📡 Callback received data:', data)
      console.log('📡 isMounted:', isMounted.current)

      if (isMounted.current) {
        setGardenData(data)
        setIsConnected(true)
        console.log('✅ Data updated in state, connected:', true)
      }
    })

    return () => {
      console.log('🧹 Cleanup: Unsubscribing from Firebase')
      isMounted.current = false
      unsubscribe()
      setIsConnected(false)
    }
  }, [dataRef])

  return { gardenData, isConnected }
}
