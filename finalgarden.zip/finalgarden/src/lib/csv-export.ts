import { GardenData } from './app-logic'

/**
 * Export garden data to CSV format
 * @param data - Array of garden data entries
 * @param filename - Name of the CSV file to download
 */
export function exportToCSV(data: GardenData[], filename: string = 'garden-data.csv'): void {
  if (data.length === 0) {
    console.warn('No data to export')
    return
  }

  // Define CSV headers
  const headers = [
    'Timestamp',
    'Date',
    'Time',
    'Temperature (°C)',
    'Humidity (%)',
    'Light Status',
    'AQI',
    'Air Quality Status'
  ]

  // Convert data to CSV format
  const csvRows = [
    headers.join(','),
    ...data.map(entry => {
      const date = entry.timestamp ? new Date(entry.timestamp) : new Date()
      return [
        entry.timestamp || '',
        date.toLocaleDateString(),
        date.toLocaleTimeString(),
        entry.temperature !== undefined ? entry.temperature : '',
        entry.humidity !== undefined ? entry.humidity : '',
        entry.lightStatus || '',
        entry.aqi !== undefined ? entry.aqi : entry.gasAQI !== undefined ? entry.gasAQI : entry.gasLevel !== undefined ? entry.gasLevel : '',
        entry.gasStatus || ''
      ].join(',')
    })
  ]

  // Create CSV blob
  const csvContent = csvRows.join('\n')
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })

  // Create download link
  const link = document.createElement('a')
  const url = URL.createObjectURL(blob)

  link.setAttribute('href', url)
  link.setAttribute('download', filename)
  link.style.visibility = 'hidden'

  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

/**
 * Export current single data point to CSV
 * @param data - Single garden data entry
 * @param filename - Name of the CSV file
 */
export function exportCurrentToCSV(data: GardenData | null, filename?: string): void {
  if (!data) {
    console.warn('No data to export')
    return
  }

  const defaultFilename = data.timestamp
    ? `garden-data-${new Date(data.timestamp).toISOString().split('T')[0]}.csv`
    : 'garden-data.csv'

  exportToCSV([data], filename || defaultFilename)
}

/**
 * Generate CSV content without downloading (for preview or other uses)
 * @param data - Array of garden data entries
 * @returns CSV string
 */
export function generateCSVContent(data: GardenData[]): string {
  if (data.length === 0) return ''

  const headers = [
    'Timestamp',
    'Date',
    'Time',
    'Temperature (°C)',
    'Humidity (%)',
    'Light Status',
    'AQI',
    'Air Quality Status'
  ]

  const csvRows = [
    headers.join(','),
    ...data.map(entry => {
      const date = entry.timestamp ? new Date(entry.timestamp) : new Date()
      return [
        entry.timestamp || '',
        date.toLocaleDateString(),
        date.toLocaleTimeString(),
        entry.temperature !== undefined ? entry.temperature : '',
        entry.humidity !== undefined ? entry.humidity : '',
        entry.lightStatus || '',
        entry.aqi !== undefined ? entry.aqi : entry.gasAQI !== undefined ? entry.gasAQI : entry.gasLevel !== undefined ? entry.gasLevel : '',
        entry.gasStatus || ''
      ].join(',')
    })
  ]

  return csvRows.join('\n')
}
