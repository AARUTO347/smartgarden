import { initializeApp, getApps, FirebaseApp, getApps as getFirebaseApps } from 'firebase/app'
import { getDatabase, ref, DatabaseReference } from 'firebase/database'

// Firebase Configuration
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "AIzaSyClHyEygOT1Qh87x01vnG4LxtFCXLSP1FA",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "rfid-aaruto.firebaseapp.com",
  databaseURL: process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL || "https://rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "rfid-aaruto",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "rfid-aaruto.appspot.com",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "346182773188",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "1:346182773188:web:e9e32b36840930944ddc91",
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID || "G-VGJYYT6ZTZ"
}

let appInstance: FirebaseApp | null = null

// Initialize Firebase (client-side only)
export function getFirebaseApp(): FirebaseApp {
  if (typeof window === 'undefined') {
    throw new Error('Firebase can only be initialized on the client side')
  }

  if (!appInstance) {
    const existingApps = getFirebaseApps()
    if (existingApps.length > 0) {
      appInstance = existingApps[0]
    } else {
      appInstance = initializeApp(firebaseConfig)
    }
  }

  return appInstance
}

// Get Database Reference (client-side only) - Device-specific path
export function getGardenDataRef(deviceId?: string): DatabaseReference {
  if (typeof window === 'undefined') {
    throw new Error('Firebase database can only be accessed on the client side')
  }

  const app = getFirebaseApp()
  const database = getDatabase(app)

  // Use device-specific path: /garden/live/{DEVICE_ID}/
  const path = deviceId ? `garden/live/${deviceId}` : 'garden/live'
  const dbRef = ref(database, path)

  console.log('🔥 Firebase initialized')
  console.log('🔥 Database URL:', firebaseConfig.databaseURL)
  console.log('🔥 Data Path: /' + path)
  console.log('🔥 Full Reference:', dbRef.toString())
  console.log('🔥 Device ID:', deviceId || 'Not specified - using default path')

  return dbRef
}

export { appInstance as app, firebaseConfig }
