'use client'

export interface User {
  id: string
  username: string  // This will be the deviceId
  password: string  // Password can be same as deviceId
  email: string
  deviceId: string  // Device ID (same as username)
  location: string  // Device location
  createdAt: number
  isAdmin?: boolean  // Flag for admin account
}

const USERS_STORAGE_KEY = 'garden_users'
const CURRENT_USER_KEY = 'garden_current_user'

/**
 * Get all users from localStorage
 */
export function getAllUsers(): User[] {
  if (typeof window === 'undefined') return []
  try {
    const data = localStorage.getItem(USERS_STORAGE_KEY)
    return data ? JSON.parse(data) : []
  } catch (error) {
    console.error('Error reading users:', error)
    return []
  }
}

/**
 * Save users to localStorage
 */
export function saveUsers(users: User[]): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users))
  } catch (error) {
    console.error('Error saving users:', error)
  }
}

/**
 * Create a new user (device registration)
 * @param deviceId - Device ID (acts as username)
 * @param password - Password (can be same as deviceId)
 * @param location - Device location
 * @param email - Email address (optional)
 * @returns success message or error
 */
export function createUser(
  deviceId: string,
  password: string,
  location: string,
  email: string = ''
): { success: boolean; message: string } {
  // Validate inputs
  if (!deviceId || deviceId.trim().length < 3) {
    return { success: false, message: 'Device ID must be at least 3 characters' }
  }

  if (!password || password.length < 6) {
    return { success: false, message: 'Password must be at least 6 characters' }
  }

  if (!location || location.trim().length < 2) {
    return { success: false, message: 'Please enter a valid location' }
  }

  if (!email || !email.includes('@')) {
    return { success: false, message: 'Please enter a valid email' }
  }

  // Check if deviceId already exists
  const users = getAllUsers()
  if (users.some(user => user && user.deviceId && user.deviceId.toLowerCase() === deviceId.toLowerCase())) {
    return { success: false, message: 'Device ID already registered' }
  }

  // Check if email already exists
  if (email && users.some(user => user && user.email && user.email.toLowerCase() === email.toLowerCase())) {
    return { success: false, message: 'Email already registered' }
  }

  // Create new user (deviceId is used as username)
  const newUser: User = {
    id: Date.now().toString(),
    username: deviceId.trim(),  // deviceId is the username
    password,
    email: email.trim(),
    deviceId: deviceId.trim(),
    location: location.trim(),
    createdAt: Date.now(),
    isAdmin: false
  }

  users.push(newUser)
  saveUsers(users)

  return { success: true, message: 'Device registered successfully!' }
}

/**
 * Authenticate user (login by deviceId)
 * @param deviceId - Device ID (username)
 * @param password - Password
 * @returns user object if authenticated, null otherwise
 */
export function authenticateUser(deviceId: string, password: string): User | null {
  if (!deviceId || !password) {
    console.log('❌ authenticateUser: Missing deviceId or password')
    return null
  }

  const users = getAllUsers()
  console.log('🔍 authenticateUser: All users:', users)
  console.log('🔍 authenticateUser: Looking for deviceId:', deviceId, 'password:', password)
  
  // Find user with matching deviceId and password
  const user = users.find(
    u => u && u.deviceId && u.deviceId.toLowerCase() === deviceId.toLowerCase() && u.password === password
  )
  
  console.log('✅ authenticateUser: Found user:', user)
  return user || null
}

/**
 * Reset all user accounts except admin
 * @returns success message
 */
export function resetAllUsers(): { success: boolean; message: string } {
  const users = getAllUsers()

  // Keep only admin users (with proper validation)
  const adminUsers = users.filter(user => user && user.isAdmin === true)

  if (adminUsers.length === 0) {
    return { success: false, message: 'No admin account found. Cannot reset.' }
  }

  saveUsers(adminUsers)

  return { success: true, message: `Reset successful! ${users.length - adminUsers.length} device(s) removed. Admin accounts preserved.` }
}

/**
 * Delete a specific user account (except admin)
 * @param userId - User ID to delete
 * @returns success message
 */
export function deleteUser(userId: string): { success: boolean; message: string } {
  const users = getAllUsers()
  const userToDelete = users.find(u => u && u.id === userId)

  // Cannot delete admin users or non-existent users
  if (!userToDelete) {
    return { success: false, message: 'Device not found' }
  }

  if (userToDelete.isAdmin) {
    return { success: false, message: 'Cannot delete admin account' }
  }

  // Remove user
  const updatedUsers = users.filter(u => u && u.id !== userId)
  saveUsers(updatedUsers)

  return { success: true, message: 'Device account deleted successfully' }
}

/**
 * Get current logged-in user
 * @returns user object or null
 */
export function getCurrentUser(): User | null {
  if (typeof window === 'undefined') return null
  try {
    const data = sessionStorage.getItem(CURRENT_USER_KEY)
    if (!data) return null
    const parsed = JSON.parse(data)
    console.log('📋 getCurrentUser: User found:', parsed)
    return parsed
  } catch (error) {
    console.error('Error reading current user:', error)
    return null
  }
}

/**
 * Set current logged-in user
 */
export function setCurrentUser(user: User | null): void {
  if (typeof window === 'undefined') return
  try {
    if (user) {
      sessionStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user))
    } else {
      sessionStorage.removeItem(CURRENT_USER_KEY)
    }
  } catch (error) {
    console.error('Error setting current user:', error)
  }
}

/**
 * Check if user is authenticated
 */
export function isAuthenticated(): boolean {
  return getCurrentUser() !== null
}

/**
 * Reset and reinitialize the admin user
 * @returns success message
 */
export function resetAdminUser(): { success: boolean; message: string } {
  try {
    console.log('🔄 Resetting admin user...')
    
    // Remove all users including admin
    localStorage.removeItem(USERS_STORAGE_KEY)
    
    console.log('🗑️ Cleared localStorage')
    
    // Clear session
    sessionStorage.removeItem(CURRENT_USER_KEY)
    
    console.log('🗑️ Cleared session')
    
    // Initialize the admin user
    initializeDefaultUsers()
    
    const users = getAllUsers()
    const adminUser = users.find(user => user && user.isAdmin)
    
    console.log('✅ After reset, users:', users)
    console.log('✅ Admin user:', adminUser)
    
    if (adminUser) {
      return { success: true, message: 'Admin user reset successfully! Username: AARUTO, Password: AARUTO100108112' }
    } else {
      return { success: false, message: 'Failed to reset admin user - admin not found in users list' }
    }
  } catch (error) {
    console.error('❌ Error resetting admin user:', error)
    return { success: false, message: `Error: ${error}` }
  }
}

/**
 * Logout user
 */
export function logout(): void {
  setCurrentUser(null)
}

/**
 * Initialize with default admin user if no users exist
 * Admin: AARUTO / AARUTO100108112
 */
export function initializeDefaultUsers(): void {
  if (typeof window === 'undefined') return

  const users = getAllUsers()
  console.log('🔧 initializeDefaultUsers: Current users:', users)

  // Check if admin user already exists
  const adminExists = users.some(user => user && user.username === 'AARUTO')

  if (!adminExists) {
    const adminUser: User = {
      id: 'admin-aaruto-001',
      username: 'AARUTO',  // Admin username
      password: 'AARUTO100108112',  // Admin password
      email: 'aaruto@admin.smartgarden',
      deviceId: 'AARUTO',  // Device ID is same as username
      location: 'Admin Console',
      createdAt: Date.now(),
      isAdmin: true  // Mark as admin
    }
    users.push(adminUser)
    saveUsers(users)
    console.log('✅ Default AARUTO admin user created:', adminUser)
  } else {
    console.log('ℹ️ Admin user already exists')
  }
}

// Initialize on load
try {
  if (typeof window !== 'undefined') {
    console.log('🔧 user-store: Initializing default users...')
    initializeDefaultUsers()
  }
} catch (error) {
  console.error('❌ user-store: Error during initialization:', error)
}
