'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import {
  Server, Plus, Edit, Trash2, Shield, LogOut, RefreshCw, Wifi, Clock, MapPin,
  User, Database, AlertTriangle, CheckCircle, XCircle
} from 'lucide-react'
import { getAllUsers, saveUsers, resetAllUsers, deleteUser, User as UserType } from '@/lib/user-store'
import { useToast } from '@/hooks/use-toast'
import { useRouter } from 'next/navigation'

// Admin Credentials
const ADMIN_USERNAME = 'AARUTO'
const ADMIN_PASSWORD = 'AARUTO100108112'

export default function AdminPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')

  // Device management state
  const [devices, setDevices] = useState<UserType[]>([])
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editingDevice, setEditingDevice] = useState<UserType | null>(null)

  // New device form state
  const [newDevice, setNewDevice] = useState({
    deviceId: '',
    password: '',
    location: '',
    email: ''
  })

  // Check if admin is logged in
  useEffect(() => {
    const users = getAllUsers()
    const adminUser = users.find(u => u.isAdmin === true)

    // Auto-login if admin exists
    if (adminUser) {
      setIsAuthenticated(true)
      loadDevices()
    }
  }, [])

  // Load devices (all users except admin)
  const loadDevices = () => {
    const users = getAllUsers()
    const deviceUsers = users.filter(u => !u.isAdmin)
    setDevices(deviceUsers)
  }

  // Handle admin login
  const handleAdminLogin = () => {
    if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
      toast({
        title: "Authentication Failed",
        description: "Invalid admin credentials",
        variant: "destructive",
      })
      return
    }

    // Check if admin user exists, create if not
    let users = getAllUsers()
    let adminUser = users.find(u => u.username === ADMIN_USERNAME)

    if (!adminUser) {
      adminUser = {
        id: 'admin-aaruto-001',
        username: ADMIN_USERNAME,
        password: ADMIN_PASSWORD,
        email: 'aaruto@admin.smartgarden',
        deviceId: ADMIN_USERNAME,
        location: 'Admin Console',
        createdAt: Date.now(),
        isAdmin: true
      }
      users.push(adminUser)
      saveUsers(users)
    }

    setIsAuthenticated(true)
    loadDevices()
    toast({
      title: "Welcome Admin",
      description: "Admin dashboard loaded successfully",
      variant: "default",
    })
  }

  // Handle logout
  const handleLogout = () => {
    setIsAuthenticated(false)
    setUsername('')
    setPassword('')
    toast({
      title: "Logged Out",
      description: "Admin session ended",
      variant: "default",
    })
  }

  // Handle add device
  const handleAddDevice = () => {
    if (!newDevice.deviceId || !newDevice.password || !newDevice.location) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    if (newDevice.deviceId === ADMIN_USERNAME) {
      toast({
        title: "Reserved Device ID",
        description: "AARUTO is reserved for admin account",
        variant: "destructive",
      })
      return
    }

    // Check if device ID already exists
    const users = getAllUsers()
    if (users.some(u => u.deviceId.toLowerCase() === newDevice.deviceId.toLowerCase())) {
      toast({
        title: "Device Already Exists",
        description: "This device ID is already registered",
        variant: "destructive",
      })
      return
    }

    // Create new device user
    const newDeviceUser: UserType = {
      id: Date.now().toString(),
      username: newDevice.deviceId.trim(),
      password: newDevice.password.trim(),
      email: newDevice.email.trim() || `${newDevice.deviceId}@device.smartgarden`,
      deviceId: newDevice.deviceId.trim(),
      location: newDevice.location.trim(),
      createdAt: Date.now(),
      isAdmin: false
    }

    users.push(newDeviceUser)
    saveUsers(users)

    // Refresh device list
    loadDevices()

    // Reset form
    setNewDevice({ deviceId: '', password: '', location: '', email: '' })
    setShowAddModal(false)

    toast({
      title: "Device Added",
      description: `Device "${newDevice.deviceId}" has been created successfully`,
      variant: "default",
    })
  }

  // Handle edit device
  const handleEditDevice = () => {
    if (!editingDevice || !newDevice.deviceId || !newDevice.password || !newDevice.location) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    if (newDevice.deviceId === ADMIN_USERNAME) {
      toast({
        title: "Cannot Edit",
        description: "AARUTO admin account cannot be modified",
        variant: "destructive",
      })
      return
    }

    // Update device
    const users = getAllUsers()
    const updatedUsers = users.map(u => {
      if (u.id === editingDevice.id) {
        return {
          ...u,
          username: newDevice.deviceId.trim(),
          password: newDevice.password.trim(),
          email: newDevice.email.trim() || `${newDevice.deviceId}@device.smartgarden`,
          deviceId: newDevice.deviceId.trim(),
          location: newDevice.location.trim()
        }
      }
      return u
    })

    saveUsers(updatedUsers)

    // Refresh
    loadDevices()

    // Reset
    setEditingDevice(null)
    setNewDevice({ deviceId: '', password: '', location: '', email: '' })
    setShowEditModal(false)

    toast({
      title: "Device Updated",
      description: `Device "${newDevice.deviceId}" has been updated successfully`,
      variant: "default",
    })
  }

  // Handle delete device
  const handleDeleteDevice = (deviceId: string) => {
    const users = getAllUsers()
    const deviceToDelete = users.find(u => u.deviceId === deviceId)

    if (!deviceToDelete) {
      toast({
        title: "Device Not Found",
        description: "Device not found",
        variant: "destructive",
      })
      return
    }

    if (deviceToDelete.isAdmin) {
      toast({
        title: "Cannot Delete",
        description: "Admin account cannot be deleted",
        variant: "destructive",
      })
      return
    }

    if (!confirm(`Are you sure you want to delete device "${deviceId}"?`)) {
      return
    }

    deleteUser(deviceToDelete.id)

    // Refresh
    loadDevices()

    toast({
      title: "Device Deleted",
      description: `Device "${deviceId}" has been deleted`,
      variant: "default",
    })
  }

  // Open edit modal with device data
  const openEditModal = (device: UserType) => {
    setEditingDevice(device)
    setNewDevice({
      deviceId: device.deviceId,
      password: device.password,
      location: device.location,
      email: device.email
    })
    setShowEditModal(true)
  }

  // Handle reset all devices
  const handleResetAll = () => {
    if (!confirm('Are you sure you want to reset ALL devices? This will delete all user accounts except admin.')) {
      return
    }

    resetAllUsers()
    loadDevices()

    toast({
      title: "Reset Complete",
      description: "All devices have been reset. Admin account preserved.",
      variant: "default",
    })
  }

  // Admin Login Screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-900 via-green-800 to-emerald-900 flex items-center justify-center p-4">
        <div className="max-w-md w-full">
          {/* Animated Background */}
          <div className="fixed inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 left-20 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-20 right-20 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
          </div>

          <Card className="backdrop-blur-xl bg-white/10 border-white/20 relative z-10">
            <CardHeader className="space-y-2 pb-6">
              <div className="flex items-center justify-center gap-3">
                <div className="relative">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center shadow-xl shadow-green-500/30">
                    <Shield className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute inset-0 bg-green-400/40 blur-xl rounded-full animate-pulse" />
                </div>
              </div>
              <CardTitle className="text-white text-center text-2xl">
                Admin Console
              </CardTitle>
              <p className="text-green-200/70 text-center text-sm">
                Secure administrator access only
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="admin-username" className="text-green-200">
                    Admin Username
                  </Label>
                  <Input
                    id="admin-username"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder={ADMIN_USERNAME}
                    className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="admin-password" className="text-green-200">
                    Admin Password
                  </Label>
                  <Input
                    id="admin-password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••••"
                    className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                  />
                </div>
              </div>

              <Button
                onClick={handleAdminLogin}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg shadow-green-500/30 hover:scale-105 transition-all duration-300"
              >
                <Shield className="w-4 h-4 mr-2" />
                Access Admin Console
              </Button>

              <div className="text-center">
                <Button
                  variant="ghost"
                  onClick={() => router.push('/')}
                  className="text-green-200/70 hover:text-green-200 hover:bg-white/10"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Admin Dashboard
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-green-800 to-emerald-900 flex flex-col relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-green-400/5 rounded-full blur-3xl animate-pulse delay-500" />
      </div>

      {/* Header */}
      <header className="bg-black/30 backdrop-blur-lg border-b border-white/10 sticky top-0 z-30">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center shadow-xl shadow-green-500/30">
                  <Shield className="w-6 h-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">
                  Admin Console
                </h1>
                <p className="text-xs text-green-200/60">AARUTO • Secure Management</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Badge className="bg-green-500/30 text-green-300 border-green-500/40">
                <div className="w-1.5 h-1.5 bg-green-400 rounded-full mr-1 animate-pulse" />
                Admin Mode
              </Badge>

              <Button
                onClick={() => router.push('/')}
                variant="ghost"
                className="text-green-200 hover:text-white hover:bg-white/10"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Exit
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6 space-y-6 relative z-10">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 animate-in fade-in slide-in-from-top-4 duration-500">
          <Card className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-green-200/60">Total Devices</p>
                  <p className="text-3xl font-bold text-white">{devices.length}</p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                  <Server className="w-6 h-6 text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-green-200/60">Active Devices</p>
                  <p className="text-3xl font-bold text-white">{devices.length}</p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                  <Wifi className="w-6 h-6 text-green-400 animate-pulse" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-green-200/60">Admin Status</p>
                  <p className="text-2xl font-bold text-green-400">Active</p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                  <Shield className="w-6 h-6 text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/15 transition-all duration-300">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-green-200/60">System Status</p>
                  <p className="text-2xl font-bold text-green-400">Online</p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-500 delay-100">
          <Button
            onClick={() => {
              setShowAddModal(true)
              setNewDevice({ deviceId: '', password: '', location: '', email: '' })
            }}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg shadow-green-500/30 hover:scale-105 transition-all duration-300"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add New Device
          </Button>

          <Button
            onClick={() => loadDevices()}
            variant="outline"
            className="text-green-200 border-green-500/30 hover:bg-green-500/10 hover:text-white hover:scale-105 transition-all duration-300"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>

          <Button
            onClick={handleResetAll}
            variant="outline"
            className="text-red-300 border-red-500/30 hover:bg-red-500/10 hover:text-red-200 hover:scale-105 transition-all duration-300"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Reset All Devices
          </Button>
        </div>

        {/* Devices List */}
        <Card className="backdrop-blur-xl bg-white/10 border-white/20 animate-in fade-in slide-in-from-bottom-6 duration-500 delay-200">
          <CardHeader>
            <CardTitle className="text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-green-400" />
                Registered Devices
              </div>
              <Badge className="bg-green-500/30 text-green-300 border-green-500/40">
                {devices.length} Devices
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {devices.length === 0 ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
                  <Server className="w-10 h-10 text-green-400" />
                </div>
                <p className="text-lg font-semibold text-white">No Devices Registered</p>
                <p className="text-sm text-green-200/70">
                  Add your first device to get started
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[600px] overflow-y-auto">
                {devices.map((device) => (
                  <div
                    key={device.id}
                    className="p-4 bg-black/20 rounded-xl border border-white/10 hover:border-green-500/30 transition-all duration-300 hover:bg-black/30"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-lg flex items-center justify-center">
                            <Server className="w-5 h-5 text-cyan-400" />
                          </div>
                          <div>
                            <p className="text-base font-bold text-white">{device.deviceId}</p>
                            <p className="text-xs text-green-200/60">Device ID</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="space-y-1">
                            <p className="text-xs text-green-200/60">Location</p>
                            <p className="text-sm text-white flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-green-400" />
                              {device.location}
                            </p>
                          </div>

                          <div className="space-y-1">
                            <p className="text-xs text-green-200/60">Email</p>
                            <p className="text-sm text-white flex items-center gap-1">
                              <User className="w-3 h-3 text-green-400" />
                              {device.email}
                            </p>
                          </div>

                          <div className="space-y-1">
                            <p className="text-xs text-green-200/60">Created</p>
                            <p className="text-sm text-white flex items-center gap-1">
                              <Clock className="w-3 h-3 text-green-400" />
                              {new Date(device.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          onClick={() => openEditModal(device)}
                          variant="outline"
                          size="sm"
                          className="text-green-200 border-green-500/30 hover:bg-green-500/10 hover:text-white"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>

                        <Button
                          onClick={() => handleDeleteDevice(device.deviceId)}
                          variant="outline"
                          size="sm"
                          className="text-red-300 border-red-500/30 hover:bg-red-500/10 hover:text-red-200"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Add Device Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in">
          <Card className="max-w-md w-full backdrop-blur-xl bg-white/10 border-white/20 relative z-50">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Plus className="w-5 h-5 text-green-400" />
                  Add New Device
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowAddModal(false)}
                  className="text-green-200 hover:text-white hover:bg-white/10"
                >
                  <XCircle className="w-5 h-5" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="device-id" className="text-green-200">
                  Device ID *
                </Label>
                <Input
                  id="device-id"
                  type="text"
                  value={newDevice.deviceId}
                  onChange={(e) => setNewDevice({ ...newDevice, deviceId: e.target.value })}
                  placeholder="Enter unique device ID"
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="device-password" className="text-green-200">
                  Password *
                </Label>
                <Input
                  id="device-password"
                  type="text"
                  value={newDevice.password}
                  onChange={(e) => setNewDevice({ ...newDevice, password: e.target.value })}
                  placeholder="Enter device password"
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="device-location" className="text-green-200">
                  Location *
                </Label>
                <Input
                  id="device-location"
                  type="text"
                  value={newDevice.location}
                  onChange={(e) => setNewDevice({ ...newDevice, location: e.target.value })}
                  placeholder="e.g., Garden Zone A"
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="device-email" className="text-green-200">
                  Email (Optional)
                </Label>
                <Input
                  id="device-email"
                  type="email"
                  value={newDevice.email}
                  onChange={(e) => setNewDevice({ ...newDevice, email: e.target.value })}
                  placeholder="device@example.com"
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <Button
                  onClick={() => setShowAddModal(false)}
                  variant="outline"
                  className="flex-1 text-green-200 border-green-500/30 hover:bg-green-500/10"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleAddDevice}
                  className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Device
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Edit Device Modal */}
      {showEditModal && editingDevice && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in">
          <Card className="max-w-md w-full backdrop-blur-xl bg-white/10 border-white/20 relative z-50">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Edit className="w-5 h-5 text-green-400" />
                  Edit Device
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setShowEditModal(false)
                    setEditingDevice(null)
                  }}
                  className="text-green-200 hover:text-white hover:bg-white/10"
                >
                  <XCircle className="w-5 h-5" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-3 bg-green-500/10 rounded-lg border border-green-500/20 mb-4">
                <p className="text-sm text-green-200">
                  <strong>Editing:</strong> {editingDevice.deviceId}
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-device-id" className="text-green-200">
                  Device ID *
                </Label>
                <Input
                  id="edit-device-id"
                  type="text"
                  value={newDevice.deviceId}
                  onChange={(e) => setNewDevice({ ...newDevice, deviceId: e.target.value })}
                  placeholder="Enter unique device ID"
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-device-password" className="text-green-200">
                  Password *
                </Label>
                <Input
                  id="edit-device-password"
                  type="text"
                  value={newDevice.password}
                  onChange={(e) => setNewDevice({ ...newDevice, password: e.target.value })}
                  placeholder="Enter device password"
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-device-location" className="text-green-200">
                  Location *
                </Label>
                <Input
                  id="edit-device-location"
                  type="text"
                  value={newDevice.location}
                  onChange={(e) => setNewDevice({ ...newDevice, location: e.target.value })}
                  placeholder="e.g., Garden Zone A"
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-device-email" className="text-green-200">
                  Email (Optional)
                </Label>
                <Input
                  id="edit-device-email"
                  type="email"
                  value={newDevice.email}
                  onChange={(e) => setNewDevice({ ...newDevice, email: e.target.value })}
                  placeholder="device@example.com"
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-green-200/50 focus:border-green-500"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <Button
                  onClick={() => {
                    setShowEditModal(false)
                    setEditingDevice(null)
                  }}
                  variant="outline"
                  className="flex-1 text-green-200 border-green-500/30 hover:bg-green-500/10"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleEditDevice}
                  className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
