import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Smart Garden - MADE BY AARUTO | POWERED BY CHRONOBOTICS",
  description: "Smart Garden Lighting & Environment Automation Dashboard. Real-time monitoring of temperature, humidity, light status, and gas levels for your garden.",
  keywords: ["Smart Garden", "IoT", "Environment Automation", "AARUTO", "CHRONOBOTICS", "Garden Monitoring", "Firebase Realtime"],
  authors: [{ name: "AARUTO" }],
  icons: {
    icon: "/logo.png",
    apple: "/logo.png",
  },
  openGraph: {
    title: "Smart Garden - MADE BY AARUTO | POWERED BY CHRONOBOTICS",
    description: "Smart Garden Lighting & Environment Automation Dashboard with real-time monitoring",
    siteName: "Smart Garden",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Smart Garden",
    description: "Real-time garden monitoring and automation system",
  },
};

// Root layout with Toaster component for notifications

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
