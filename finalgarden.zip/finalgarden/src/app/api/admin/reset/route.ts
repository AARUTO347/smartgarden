import { NextResponse } from 'next/server'

export async function POST() {
  // This endpoint cannot directly access localStorage as it's server-side
  // However, we can provide information about what should be created
  
  const adminUser = {
    id: 'admin-aaruto-001',
    username: 'AARUTO',
    password: 'AARUTO100108112',
    email: 'aaruto@admin.smartgarden',
    deviceId: 'AARUTO',
    location: 'Admin Console',
    createdAt: Date.now(),
    isAdmin: true
  }

  return NextResponse.json({
    success: true,
    message: 'Admin user information retrieved',
    admin: adminUser,
    instructions: 'Use the Reset Admin button on the login page to create this user'
  })
}
