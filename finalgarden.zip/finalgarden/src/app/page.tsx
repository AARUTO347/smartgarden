'use client'

import { useState } from 'react'
import { useSession } from '@/hooks/use-session'
import Login from '@/components/login'
import Signup from '@/components/signup'
import Dashboard from '@/components/dashboard'
import { Toaster } from '@/components/ui/toaster'

type AuthView = 'login' | 'signup'

export default function Home() {
  const { isAuthenticated, username, deviceId, isAdmin, isLoading, login, logout } = useSession()
  const [authView, setAuthView] = useState<AuthView>('login')

  const handleSignupSuccess = (username: string, password: string) => {
    // Auto-login after signup
    login(username, password)
  }

  const handleBackToLogin = () => {
    setAuthView('login')
  }

  const handleShowSignup = () => {
    setAuthView('signup')
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-900 via-green-800 to-emerald-900">
        <div className="text-center space-y-4">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-green-500/30 border-t-green-500 rounded-full animate-spin" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-12 h-12 bg-green-500/20 rounded-full backdrop-blur-sm" />
            </div>
          </div>
          <p className="text-green-100 font-medium">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <>
      {isAuthenticated ? (
        <Dashboard username={username || 'User'} deviceId={deviceId || undefined} isAdmin={isAdmin} onLogout={logout} />
      ) : authView === 'login' ? (
        <Login onLogin={login} onShowSignup={handleShowSignup} />
      ) : (
        <Signup onSignupSuccess={handleSignupSuccess} onBackToLogin={handleBackToLogin} />
      )}
      <Toaster />
    </>
  )
}
