# ✅ Your ESP8266 Code Saved

## 📁 File Created

**`ESP8266_Garden_Final.ino`** - Your exact code has been saved!

---

## 🔌 Important: Custom Library Required

Your code includes `#include "MQ135.h"` which is a **custom library** you created.

### You Need to Create `MQ135.h`

Since your code calls:
```cpp
#include "MQ135.h"

// In your code:
mq135_sensor.getPPM();  // This is from your custom library
```

You need to create `MQ135.h` with the `getPPM()` function.

---

## 📝 MQ135.h Library Structure

### Required Functions:

```cpp
// MQ135.h
#ifndef MQ135_H
#define MQ135_H

class MQ135 {
  public:
    MQ135(int analogPin);
    float getPPM();
};

#endif
```

---

## 🔧 Create MQ135.h Library

### Option 1: Simple Version (Recommended)

Create file: `MQ135.h`

```cpp
#ifndef MQ135_H
#define MQ135_H

#include <Arduino.h>

class MQ135 {
  private:
    int _pin;
    float _r0;
    int _adc;

  public:
    MQ135(int analogPin);
    float getPPM();
    void calibrate();
};

MQ135::MQ135(int analogPin) : _pin(analogPin) {
  _r0 = 10.0;  // Calibrated R0 - YOU NEED TO SET THIS!
  _adc = 0;
}

void MQ135::calibrate() {
  // Measure clean air R0
  Serial.println("Calibrating MQ135...");
  float sum = 0;
  const int samples = 100;
  
  for (int i = 0; i < samples; i++) {
    _adc = analogRead(_pin);
    sum += _adc;
    delay(10);
  }
  
  _r0 = sum / samples;
  Serial.print("R0 calibrated to: ");
  Serial.println(_r0);
}

float MQ135::getPPM() {
  _adc = analogRead(_pin);
  
  // MQ135 calculation: PPM = (Rs/Ro-1) * (Vc/10)
  // Vc = 5V, Ro is your R0, Rs varies based on gas
  
  // Simplified PPM calculation
  // Adjust R0 based on your calibration
  float rs_r0_ratio = (_r0 / 10.0); // Assuming Ro=10KΩ
  float ppm = (rs_r0_ratio - 1.0) * _adc * 100;
  
  return max(0, ppm);
}

#endif
```

### Option 2: Direct Read (Simplest)

```cpp
#ifndef MQ135_H
#define MQ135_H

#include <Arduino.h>

class MQ135 {
  private:
    int _pin;

  public:
    MQ135(int analogPin);
    float getPPM();
};

MQ135::MQ135(int analogPin) : _pin(analogPin) {
}

float MQ135::getPPM() {
  int adc = analogRead(_pin);
  
  // Simple PPM mapping (0-1000 range)
  // Calibrate with your sensor's specs
  float ppm = (adc / 1023.0) * 1000;
  
  return ppm;
}

#endif
```

---

## 📱 Arduino IDE Setup

### Step 1: Create Library File

1. Open Arduino IDE
2. Go to: `Sketch → Show Sketch Folder`
3. Create new file: `MQ135.h` in your sketch folder
4. Paste one of the code options above
5. Save the file

### Step 2: Upload Your Main Code

1. Open: `ESP8266_Garden_Final.ino`
2. Select Board: ESP8266
3. Select Port: COMx
4. Click: Upload (→)

### Step 3: Check Serial Monitor

1. Click: Serial Monitor icon
2. Set baud rate: 115200
3. You should see:

```
========================================
  SMART GARDEN IoT ESP8266
========================================

Could not find AHT sensor!
[repeats until sensor found]

Connecting to WiFi....
WiFi connected!
IP address: 192.168.1.100

Initializing Firebase...
Firebase initialized!
Firebase Host: rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app
Database Path: garden/live
========================================

Reading Sensors...
  Temperature: 24.50 °C
  Humidity: 65.00 %
  Gas PPM: 120.00
  Gas AQI: 60
  Gas Status: GOOD
  Light Status: DAY
  Garden Light: OFF
  Timestamp: 1704148800000
----------------------------------------

Sending to Firebase...
Data sent successfully!
HTTP response code: 200
----------------------------------------
```

---

## 🔧 Calibration Notes

### MQ135 PPM Calibration

**Important**: You need to calibrate `R0` for accurate PPM readings.

### Calibration Steps:

1. Place MQ135 in clean air
2. Upload code
3. After 30 minutes, note the clean air value from Serial Monitor
4. Update this in `MQ135.h`:
   ```cpp
   _r0 = 120.0;  // Your calibrated value
   ```
5. Re-upload code

### Light Sensor (A0 Pin)

Your code currently uses A0 for light detection:
```cpp
int lightValue = analogRead(A0);
sensorData.lightStatus = (lightValue > 512) ? "DAY" : "NIGHT";
```

**Adjust threshold if needed:**
```cpp
// In readSensors():
#define LIGHT_THRESHOLD 512  // Change this value

// Or use conditional:
if (lightValue > 400) {
  sensorData.lightStatus = "DAY";
} else {
  sensorData.lightStatus = "NIGHT";
}
```

---

## 🔥 Firebase Configuration

Your code uses:
- **Host**: `rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app`
- **Path**: `/garden/live`
- **Auth Token**: `9gPXcUYJty4rjU05k1mBDEUUnXEyt9SQKB1nQTRz`

**Dashboard Configuration**:
- Database URL: Same as above
- Path: `/garden/live`
- ✅ All paths match!

---

## 📊 Data Format Sent to Firebase

Your code sends:

```json
{
  "temperature": 24.50,      // °C (float)
  "humidity": 65.00,        // % (float)
  "gasPPM": 120.00,          // PPM (float)
  "gasLevel": 120,            // PPM (int)
  "gasAQI": 60,              // AQI 0-500 (int)
  "gasStatus": "GOOD",         // String
  "lightStatus": "DAY",        // String
  "gardenLight": "OFF",         // String
  "timestamp": 1704148800000   // milliseconds (long)
}
```

### Dashboard Expected Format:

**Note**: Your code sends `gasPPM`, `gasLevel`, and `gasAQI` but dashboard expects only `gasLevel` and `gasStatus`.

Your code is sending MORE fields than required, which is fine!

---

## 🎯 Next Steps

### 1. Create MQ135.h Library
- Use one of the options above
- Save in your sketch folder
- Include in your main code

### 2. Configure Sensors

**AHT Sensor**: Already handled in code
- Connect to D2 pin (I2C)
- Add 10KΩ pull-up resistor on DATA line

**MQ135 Gas Sensor**: Needs library
- Connect to A0 pin
- Power to 3.3V or 5V (check datasheet)
- Create MQ135.h library

**Light Sensor**: Currently A0
- Connect LDR or light sensor to A0
- Adjust threshold if needed

### 3. Upload and Test

1. Upload `MQ135.h` to Arduino libraries folder first
2. Upload `ESP8266_Garden_Final.ino` to ESP8266
3. Open Serial Monitor (115200 baud)
4. Verify all sensors initialize
5. Check Firebase updates

### 4. Verify Dashboard

1. Open: http://localhost:3000
2. Login: VIPIN / @@@@@@@@@@
3. Check if data appears
4. Verify Firebase Console has data at `/garden/live`

---

## 🔍 Troubleshooting

### AHT Sensor Not Found

**Symptom**: Serial shows "Could not find AHT sensor!"

**Solutions**:
1. Check D2 pin wiring
2. Verify 10KΩ resistor is on DATA line
3. Try different AHT sensor
4. Check power supply

### Firebase Connection Failed

**Symptom**: Serial shows Firebase errors

**Solutions**:
1. Verify auth token is correct
2. Check internet connection
3. Verify Firebase host URL
4. Check Firebase database rules

### Compilation Errors

**Symptom**: Arduino IDE shows errors

**Solutions**:
1. Create `MQ135.h` first
2. Save in correct location (sketch folder)
3. Restart Arduino IDE
4. Try again

---

## ✅ Files Summary

| File | Status | Description |
|------|--------|-------------|
| `ESP8266_Garden_Final.ino` | ✅ Saved | Your main code |
| `MQ135.h` | ⚠️  Needed | Custom library (create it) |
| `FINAL_PIN_CONFIG_GUIDE.md` | ✅ Existing | Reference guide |

---

## 🎉 Ready to Use!

Your ESP8266 code is saved and ready. Just create the `MQ135.h` library and upload!

---

**Summary**:
- ✅ Main code: `ESP8266_Garden_Final.ino` (your exact code)
- ✅ Firebase config: Correct and ready
- ✅ Sensor support: AHT, MQ135, Light
- ⚠️  Library needed: Create `MQ135.h`
- ✅ Documentation: Complete guide provided

**Create MQ135.h and your smart garden is ready!** 🚀
