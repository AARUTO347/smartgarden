# Smart Garden Dashboard - Quick Start Guide

## ✅ Dashboard is Now Live!

Your Smart Garden Dashboard is **running successfully** and displaying data!

## 🎯 Current Status

**Mode**: Demo Mode (showing sample data)
**Status**: ✅ Online and Ready
**Port**: 3000

The dashboard is currently showing **demo data** because it's waiting for live data from your ESP8266.

## 📊 What You Can See Now

### 1. Dashboard View
Click the **"Dashboard"** button to see:
- ✅ **Temperature**: 24.5 °C
- ✅ **Humidity**: 68 %
- ✅ **Gas Status**: SAFE (120 PPM)
- ✅ **Light Status**: DAY (Sun icon)
- ✅ **Garden Light**: ON

A yellow banner will show **"Showing Demo Data"** at the top.

### 2. Charts View
Click the **"Charts"** button to see:
- ✅ **Temperature & Humidity Trend** - Area chart showing 10 data points
- ✅ **AQI History** - Bar chart showing gas levels over time

### 3. Raw Data View
Click the **"Raw Data"** button to see:
- ✅ Complete JSON structure with all 7 fields
- ✅ Individual data fields (Temperature, Humidity, Gas Level)
- ✅ Status fields with color-coded badges
- ✅ Formatted timestamp

## 🔥 How to Get LIVE Data

### Option 1: Send Data from ESP8266 (Recommended)

1. **Prepare Your ESP8266**:
   ```cpp
   // Send all 7 required fields to Firebase
   FirebaseJson json;
   json.add("temperature", 24.5);
   json.add("humidity", 68);
   json.add("gasLevel", 120);
   json.add("gasStatus", "SAFE");
   json.add("lightStatus", "DAY");
   json.add("gardenLight", "ON");
   json.add("timestamp", 1704148800000);

   Firebase.setJSON(firebaseData, "/garden/live", json);
   ```

2. **Update Every 5 Seconds**:
   ```cpp
   delay(5000); // Wait 5 seconds between updates
   ```

3. **Use Correct Firebase Path**:
   - Database URL: `rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app`
   - Path: `/garden/live`

### Option 2: Add Test Data Manually

1. Go to Firebase Console: https://console.firebase.google.com/
2. Select project: `rfid-aaruto`
3. Navigate to **Realtime Database**
4. Find the path: `garden/live`
5. Paste this JSON:

   ```json
   {
     "temperature": 26.8,
     "humidity": 72,
     "gasLevel": 135,
     "gasStatus": "SAFE",
     "lightStatus": "DAY",
     "gardenLight": "ON",
     "timestamp": 1704148800000
   }
   ```

6. Click **Save**

### Option 3: Use the Provided Example Data

The file `firebase-data-examples.json` contains 5 example data sets. You can:
- Copy any example and paste it into Firebase Console
- Use it as a reference for your ESP8266 code

## 📡 When ESP8266 Sends Data

Once your ESP8266 starts sending data, the dashboard will:

1. ✅ **Automatically switch** from demo data to live data
2. ✅ **Remove yellow banner** showing "Demo Mode"
3. ✅ **Update in real-time** every time ESP8266 sends data
4. ✅ **Show "Firebase Realtime Database"** as data source
5. ✅ **Display actual sensor readings** from your garden

## 🎨 Features

### Real-time Updates
- Dashboard updates instantly when Firebase receives new data
- Charts automatically refresh with new readings
- No page refresh needed!

### Historical Data
- Keeps last 50 readings for charts
- Shows trends over time
- Temperature, humidity, and gas level history

### Visual Indicators
- **Gas Status**: Green (SAFE), Yellow (WARNING), Red (DANGER)
- **Light Status**: Yellow sun (DAY), Blue moon (NIGHT)
- **Garden Light**: Green (ON), Gray (OFF)

### CSV Export
1. Go to Dashboard view
2. Click **"Export CSV"** button
3. File downloads with current sensor data

## 🔍 Troubleshooting

### Still Seeing Demo Data?

**Check 1**: Firebase Connection
- Open browser console (F12)
- Look for Firebase connection errors
- Verify Firebase URL is correct

**Check 2**: ESP8266 Sending Data
- Check ESP8266 Serial Monitor
- Look for "Data sent successfully" message
- Verify WiFi connection

**Check 3**: Firebase Database Rules
- Go to Firebase Console → Realtime Database
- Check rules allow read/write access
- Default rule for testing:
  ```json
  {
    "rules": {
      ".read": true,
      ".write": true
    }
  }
  ```

### Charts Not Showing?

- Try refreshing the page
- Wait for a few seconds for data to load
- Check browser console for errors

### Data Not Updating?

- Verify ESP8266 is sending data every 5 seconds
- Check Firebase Console to see if data is updating
- Clear browser cache and refresh

## 📱 Using the Dashboard

### Login
- **Username**: `VIPIN`
- **Password**: `VIPIN123`

### Navigation
- **Dashboard**: View current sensor readings
- **Charts**: View historical trends
- **Raw Data**: View complete JSON structure

### Logout
- Click the logout icon (🚪) in the top right

## 📋 Required Data Format

Your ESP8266 **must send all 7 fields**:

| Field | Type | Example |
|-------|------|---------|
| temperature | float | 24.5 |
| humidity | float | 68 |
| gasLevel | integer | 120 |
| gasStatus | string | "SAFE" |
| lightStatus | string | "DAY" |
| gardenLight | string | "ON" |
| timestamp | number | 1704148800000 |

### Status Values

**Gas Status**:
- `"SAFE"` - Gas level < 200 PPM
- `"WARNING"` - 200 ≤ Gas level < 400 PPM
- `"DANGER"` - Gas level ≥ 400 PPM

**Light Status**:
- `"DAY"` - Light sensor reading > 512
- `"NIGHT"` - Light sensor reading ≤ 512

**Garden Light**:
- `"ON"` - Garden light is ON
- `"OFF"` - Garden light is OFF

## 🚀 Next Steps

1. **Set up your ESP8266** with the provided code
2. **Connect to WiFi** with your credentials
3. **Configure Firebase** with the project details
4. **Upload and run** the ESP8266 code
5. **Watch the dashboard** update in real-time!

## 📚 Complete Documentation

- **Setup Guide**: `COMPLETE_ESP8266_GUIDE.md`
- **Data Structure**: `ESP8266_DATA_STRUCTURE.md`
- **ESP8266 Code**: `ESP8266_Firebase_Sender/ESP8266_SmartGarden.ino`
- **Example Data**: `firebase-data-examples.json`

## 🎉 You're All Set!

Your Smart Garden Dashboard is ready to receive live data from your ESP8266!
Start sending data and watch your garden come to life!

---

**Need Help?**
- Check Firebase Console for database status
- Review ESP8266 Serial Monitor for errors
- Look at browser console for client-side issues
- Verify all 7 data fields are being sent

**Status**: ✅ **Dashboard Live and Ready for ESP8266 Data!**
