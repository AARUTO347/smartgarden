/*
 * ESP8266 Firebase Realtime Database Connection
 * Sends sensor data to Firebase at garden/live path
 */

#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>

// ===== WiFi Credentials =====
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

// ===== Firebase Credentials =====
#define FIREBASE_HOST "rfid-aaruto-default-rtdb.asia-southeast1.firebasedatabase.app"
#define FIREBASE_AUTH "YOUR_FIREBASE_SECRET"  // Get from Firebase Console → Project Settings → Service Accounts

// ===== Sensor Configuration =====
#define SENSOR_UPDATE_INTERVAL 5000  // Update every 5 seconds

// ===== Objects =====
Adafruit_AHTX0 aht;
WiFiClient wifiClient;
FirebaseData firebaseData;

// ===== Sensor Data Structure =====
struct SensorData {
  float temperature;
  float humidity;
  int gasLevel;
  String gasStatus;
  String lightStatus;
  String gardenLight;
  unsigned long timestamp;
};

SensorData sensorData;

void setup() {
  // Initialize Serial
  Serial.begin(115200);
  Serial.println("\n\n=== Smart Garden IoT ESP8266 ===\n");

  // Initialize I2C for AHT sensor
  Wire.begin();
  
  // Initialize AHT sensor
  if (!aht.begin()) {
    Serial.println("Could not find AHT sensor!");
    while (1) delay(10);
  }

  // Initialize WiFi
  Serial.println("Connecting to WiFi...");
  WiFi.begin(ssid, password);
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  Serial.println("\nWiFi connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());

  // Initialize Firebase
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
  Serial.println("Firebase initialized!");
  
  // Set connection timeout
  firebaseData.setConnectionTimeout(5000);

  Serial.println("System ready!\n");
}

void loop() {
  // Read all sensors
  readSensors();
  
  // Determine status based on sensor values
  determineStatus();
  
  // Send to Firebase
  sendToFirebase();
  
  // Wait before next reading
  delay(SENSOR_UPDATE_INTERVAL);
}

void readSensors() {
  // Read temperature and humidity from AHT sensor
  sensorData.temperature = aht.getTemperature();
  sensorData.humidity = aht.getHumidity();
  
  // Read gas sensor (analog pin)
  sensorData.gasLevel = analogRead(A0);  // Assuming gas sensor on A0
  
  // Read light sensor (analog or digital)
  int lightValue = analogRead(A1);  // Assuming light sensor on A1
  
  // Determine day/night
  sensorData.lightStatus = (lightValue > 512) ? "DAY" : "NIGHT";
  
  // Determine garden light status (for example, based on time or light level)
  // This could be controlled by ESP8266 via relay
  sensorData.gardenLight = "ON";  // Or "OFF" based on your logic
  
  // Get current timestamp
  sensorData.timestamp = millis();
  
  // Debug output
  Serial.println("\n=== Sensor Readings ===");
  Serial.print("Temperature: ");
  Serial.print(sensorData.temperature);
  Serial.println(" °C");
  Serial.print("Humidity: ");
  Serial.print(sensorData.humidity);
  Serial.println(" %");
  Serial.print("Gas Level: ");
  Serial.println(sensorData.gasLevel);
  Serial.print("Light Status: ");
  Serial.println(sensorData.lightStatus);
  Serial.print("Garden Light: ");
  Serial.println(sensorData.gardenLight);
  Serial.print("Timestamp: ");
  Serial.println(sensorData.timestamp);
}

void determineStatus() {
  // Determine gas status based on level
  if (sensorData.gasLevel < 200) {
    sensorData.gasStatus = "SAFE";
  } else if (sensorData.gasLevel < 400) {
    sensorData.gasStatus = "WARNING";
  } else {
    sensorData.gasStatus = "DANGER";
  }
  
  Serial.print("Gas Status: ");
  Serial.println(sensorData.gasStatus);
}

void sendToFirebase() {
  Serial.println("\n=== Sending to Firebase ===");
  
  // Send temperature
  if (Firebase.setFloat(firebaseData, "/garden/live/temperature", sensorData.temperature)) {
    Serial.println("Temperature sent successfully");
  } else {
    Serial.println("Temperature failed to send");
  }
  
  // Send humidity
  if (Firebase.setFloat(firebaseData, "/garden/live/humidity", sensorData.humidity)) {
    Serial.println("Humidity sent successfully");
  } else {
    Serial.println("Humidity failed to send");
  }
  
  // Send gas level
  if (Firebase.setInt(firebaseData, "/garden/live/gasLevel", sensorData.gasLevel)) {
    Serial.println("Gas level sent successfully");
  } else {
    Serial.println("Gas level failed to send");
  }
  
  // Send gas status
  if (Firebase.setString(firebaseData, "/garden/live/gasStatus", sensorData.gasStatus)) {
    Serial.println("Gas status sent successfully");
  } else {
    Serial.println("Gas status failed to send");
  }
  
  // Send light status
  if (Firebase.setString(firebaseData, "/garden/live/lightStatus", sensorData.lightStatus)) {
    Serial.println("Light status sent successfully");
  } else {
    Serial.println("Light status failed to send");
  }
  
  // Send garden light status
  if (Firebase.setString(firebaseData, "/garden/live/gardenLight", sensorData.gardenLight)) {
    Serial.println("Garden light status sent successfully");
  } else {
    Serial.println("Garden light status failed to send");
  }
  
  // Send timestamp
  if (Firebase.setLong(firebaseData, "/garden/live/timestamp", sensorData.timestamp)) {
    Serial.println("Timestamp sent successfully");
  } else {
    Serial.println("Timestamp failed to send");
  }
  
  Serial.println("=== Firebase update complete ===\n");
}
